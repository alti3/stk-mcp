STK Python API
==============

Overview
--------

agi.stk12 is an API library for interacting with the STK object model.  
Please visit http://help.agi.com/stkdevkit/index.htm or your local STK  
installation directory for full documentation on the STK API and its use.  
To get started please visit the help for more details!  


Requirements
------------

This library requires a licensed installation of STK 12.10.0 in addition  
to Python 3.6 or higher.

