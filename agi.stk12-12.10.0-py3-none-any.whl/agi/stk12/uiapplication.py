################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgEAppConstants", "AgEAppErrorCodes", "AgEOpenLogFileMode", "AgEUiLogMsgType", "AgMRUCollection", "AgUiApplication", 
"AgUiFileOpenExt", "AgUiFileOpenExtCollection", "IAgMRUCollection", "IAgUiApplication", "IAgUiApplicationPartnerAccess", 
"IAgUiFileOpenExt", "IAgUiFileOpenExtCollection"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from .internal  import comutil          as agcom
from .internal  import coclassutil      as agcls
from .internal  import marshall         as agmarshall
from .internal  import dataanalysisutil as agdata
from .utilities import colors           as agcolor
from .internal.comutil     import IUnknown, IDispatch, IPictureDisp
from .internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from .internal.eventutil   import *
from .utilities.exceptions import *

from .uicore import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEOpenLogFileMode(IntEnum):
    """Log file open modes."""
   
    eOpenLogFileForWriting = 2
    """Open log file in write file mode."""
    eOpenLogFileForAppending = 8
    """Open log file in append file mode."""

AgEOpenLogFileMode.eOpenLogFileForWriting.__doc__ = "Open log file in write file mode."
AgEOpenLogFileMode.eOpenLogFileForAppending.__doc__ = "Open log file in append file mode."

agcls.AgTypeNameMap["AgEOpenLogFileMode"] = AgEOpenLogFileMode

class AgEUiLogMsgType(IntEnum):
    """Log message types."""
   
    eUiLogMsgDebug = 0
    """Log messages that provide Debug text."""
    eUiLogMsgInfo = 1
    """Log messages that provide information text."""
    eUiLogMsgForceInfo = 2
    """Log messages that provide forceful information text."""
    eUiLogMsgWarning = 3
    """Log messages that provide warning text."""
    eUiLogMsgAlarm = 4
    """Log messages that provide alarm text."""

AgEUiLogMsgType.eUiLogMsgDebug.__doc__ = "Log messages that provide Debug text."
AgEUiLogMsgType.eUiLogMsgInfo.__doc__ = "Log messages that provide information text."
AgEUiLogMsgType.eUiLogMsgForceInfo.__doc__ = "Log messages that provide forceful information text."
AgEUiLogMsgType.eUiLogMsgWarning.__doc__ = "Log messages that provide warning text."
AgEUiLogMsgType.eUiLogMsgAlarm.__doc__ = "Log messages that provide alarm text."

agcls.AgTypeNameMap["AgEUiLogMsgType"] = AgEUiLogMsgType

class AgEAppConstants(IntEnum):
    """AgEAppConstants contains base IDs for various structures."""
   
    eAppErrorBase = 0x200
    """Error base."""

AgEAppConstants.eAppErrorBase.__doc__ = "Error base."

agcls.AgTypeNameMap["AgEAppConstants"] = AgEAppConstants

class AgEAppErrorCodes(IntEnum):
    """App error codes."""
   
    eAppErrorPersLoadFail = (((1 << 31) | (4 << 16)) | (AgEAppConstants.eAppErrorBase + 1))
    """Failed to load personality."""
    eAppErrorAlreadyLoadFail = (((1 << 31) | (4 << 16)) | (AgEAppConstants.eAppErrorBase + 2))
    """Personality already loaded."""
    eAppErrorPersLoadFirst = (((1 << 31) | (4 << 16)) | (AgEAppConstants.eAppErrorBase + 3))
    """No personality is loaded."""
    eAppErrorPersLicenseError = (((1 << 31) | (4 << 16)) | (AgEAppConstants.eAppErrorBase + 4))
    """You do not have the required license to connect externally to the application."""
    eAppErrorNoLicenseError = (((1 << 31) | (4 << 16)) | (AgEAppConstants.eAppErrorBase + 5))
    """No license could be found."""

AgEAppErrorCodes.eAppErrorPersLoadFail.__doc__ = "Failed to load personality."
AgEAppErrorCodes.eAppErrorAlreadyLoadFail.__doc__ = "Personality already loaded."
AgEAppErrorCodes.eAppErrorPersLoadFirst.__doc__ = "No personality is loaded."
AgEAppErrorCodes.eAppErrorPersLicenseError.__doc__ = "You do not have the required license to connect externally to the application."
AgEAppErrorCodes.eAppErrorNoLicenseError.__doc__ = "No license could be found."

agcls.AgTypeNameMap["AgEAppErrorCodes"] = AgEAppErrorCodes


class IAgMRUCollection(object):
    """Provides information about most recently used (MRU) list."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get_Count_method_offset = 2
    _get__NewEnum_method_offset = 3
    _metadata = {
        "iid_data" : (5511485448271886598, 17798322995058890112),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgMRUCollection."""
        initialize_from_source_object(self, sourceObject, IAgMRUCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgMRUCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgMRUCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgMRUCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> str:
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.VARIANT, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.BSTR_arg,) }
    def Item(self, index:typing.Any) -> str:
        """Gets the MRU at the specified index."""
        return self._intf.invoke(IAgMRUCollection._metadata, IAgMRUCollection._Item_metadata, index, OutArg())

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Gets the total count of MRUs in the collection."""
        return self._intf.get_property(IAgMRUCollection._metadata, IAgMRUCollection._get_Count_metadata)

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Enumerates through the MRU collection."""
        return self._intf.get_property(IAgMRUCollection._metadata, IAgMRUCollection._get__NewEnum_metadata)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5511485448271886598, 17798322995058890112), IAgMRUCollection)
agcls.AgTypeNameMap["IAgMRUCollection"] = IAgMRUCollection

class IAgUiFileOpenExt(object):
    """Access to file open dialog that allows multiple file specifications."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_FileName_method_offset = 1
    _set_FileName_method_offset = 2
    _get_FilterDescription_method_offset = 3
    _set_FilterDescription_method_offset = 4
    _get_FilterPattern_method_offset = 5
    _set_FilterPattern_method_offset = 6
    _metadata = {
        "iid_data" : (5740546309910143078, 16304364896762750623),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiFileOpenExt."""
        initialize_from_source_object(self, sourceObject, IAgUiFileOpenExt)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiFileOpenExt)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiFileOpenExt, None)
    
    _get_FileName_metadata = { "offset" : _get_FileName_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def FileName(self) -> "IAgUiFileOpenExtCollection":
        """Gets/sets the multiple file open collection."""
        return self._intf.get_property(IAgUiFileOpenExt._metadata, IAgUiFileOpenExt._get_FileName_metadata)

    _set_FileName_metadata = { "offset" : _set_FileName_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgUiFileOpenExtCollection"),) }
    @FileName.setter
    def FileName(self, newVal:"IAgUiFileOpenExtCollection") -> None:
        """Gets/sets the multiple file open collection."""
        return self._intf.set_property(IAgUiFileOpenExt._metadata, IAgUiFileOpenExt._set_FileName_metadata, newVal)

    _get_FilterDescription_metadata = { "offset" : _get_FilterDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FilterDescription(self) -> str:
        """Gets/sets the file open dialog filter description."""
        return self._intf.get_property(IAgUiFileOpenExt._metadata, IAgUiFileOpenExt._get_FilterDescription_metadata)

    _set_FilterDescription_metadata = { "offset" : _set_FilterDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FilterDescription.setter
    def FilterDescription(self, newVal:str) -> None:
        """Gets/sets the file open dialog filter description."""
        return self._intf.set_property(IAgUiFileOpenExt._metadata, IAgUiFileOpenExt._set_FilterDescription_metadata, newVal)

    _get_FilterPattern_metadata = { "offset" : _get_FilterPattern_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FilterPattern(self) -> str:
        """Gets/sets the file open dialog filter pattern."""
        return self._intf.get_property(IAgUiFileOpenExt._metadata, IAgUiFileOpenExt._get_FilterPattern_metadata)

    _set_FilterPattern_metadata = { "offset" : _set_FilterPattern_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FilterPattern.setter
    def FilterPattern(self, newVal:str) -> None:
        """Gets/sets the file open dialog filter pattern."""
        return self._intf.set_property(IAgUiFileOpenExt._metadata, IAgUiFileOpenExt._set_FilterPattern_metadata, newVal)

    _property_names[FileName] = "FileName"
    _property_names[FilterDescription] = "FilterDescription"
    _property_names[FilterPattern] = "FilterPattern"


agcls.AgClassCatalog.add_catalog_entry((5740546309910143078, 16304364896762750623), IAgUiFileOpenExt)
agcls.AgTypeNameMap["IAgUiFileOpenExt"] = IAgUiFileOpenExt

class IAgUiApplication(object):
    """IAgUiApplication represents a root of the Application Model."""

    _num_methods = 37
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _LoadPersonality_method_offset = 1
    _get_Personality_method_offset = 2
    _get_Visible_method_offset = 3
    _set_Visible_method_offset = 4
    _get_UserControl_method_offset = 5
    _set_UserControl_method_offset = 6
    _get_Windows_method_offset = 7
    _get_Height_method_offset = 8
    _set_Height_method_offset = 9
    _get_Width_method_offset = 10
    _set_Width_method_offset = 11
    _get_Left_method_offset = 12
    _set_Left_method_offset = 13
    _get_Top_method_offset = 14
    _set_Top_method_offset = 15
    _get_WindowState_method_offset = 16
    _set_WindowState_method_offset = 17
    _Activate_method_offset = 18
    _get_MRUList_method_offset = 19
    _FileOpenDialog_method_offset = 20
    _get_Path_method_offset = 21
    _CreateObject_method_offset = 22
    _FileSaveAsDialog_method_offset = 23
    _Quit_method_offset = 24
    _FileOpenDialogExt_method_offset = 25
    _get_HWND_method_offset = 26
    _DirectoryPickerDialog_method_offset = 27
    _get_MessagePendingDelay_method_offset = 28
    _set_MessagePendingDelay_method_offset = 29
    _get_Personality2_method_offset = 30
    _OpenLogFile_method_offset = 31
    _LogMsg_method_offset = 32
    _get_LogFile_method_offset = 33
    _get_DisplayAlerts_method_offset = 34
    _set_DisplayAlerts_method_offset = 35
    _CreateApplication_method_offset = 36
    _get_ProcessID_method_offset = 37
    _metadata = {
        "iid_data" : (5152548327130061473, 179254138349634492),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiApplication."""
        initialize_from_source_object(self, sourceObject, IAgUiApplication)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiApplication)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiApplication, None)
    
    _LoadPersonality_metadata = { "offset" : _LoadPersonality_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def LoadPersonality(self, persName:str) -> None:
        """Loads a personality by its name."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._LoadPersonality_metadata, persName)

    _get_Personality_metadata = { "offset" : _get_Personality_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Personality(self) -> typing.Any:
        """Returns a reference to the currently loaded personality."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Personality_metadata)

    _get_Visible_metadata = { "offset" : _get_Visible_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def Visible(self) -> bool:
        """Gets/sets whether the main window is visible."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Visible_metadata)

    _set_Visible_metadata = { "offset" : _set_Visible_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @Visible.setter
    def Visible(self, newVal:bool) -> None:
        """Gets/sets whether the main window is visible."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_Visible_metadata, newVal)

    _get_UserControl_metadata = { "offset" : _get_UserControl_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UserControl(self) -> bool:
        """Gets/sets whether the application is user controlled."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_UserControl_metadata)

    _set_UserControl_metadata = { "offset" : _set_UserControl_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UserControl.setter
    def UserControl(self, newVal:bool) -> None:
        """Gets/sets whether the application is user controlled."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_UserControl_metadata, newVal)

    _get_Windows_metadata = { "offset" : _get_Windows_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Windows(self) -> "IAgUiWindowsCollection":
        """Returns a collection of windows."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Windows_metadata)

    _get_Height_metadata = { "offset" : _get_Height_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Height(self) -> int:
        """Gets/sets a height of the main window."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Height_metadata)

    _set_Height_metadata = { "offset" : _set_Height_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Height.setter
    def Height(self, newVal:int) -> None:
        """Gets/sets a height of the main window."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_Height_metadata, newVal)

    _get_Width_metadata = { "offset" : _get_Width_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Width(self) -> int:
        """Gets/sets a width of the main window."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Width_metadata)

    _set_Width_metadata = { "offset" : _set_Width_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Width.setter
    def Width(self, newVal:int) -> None:
        """Gets/sets a width of the main window."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_Width_metadata, newVal)

    _get_Left_metadata = { "offset" : _get_Left_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Left(self) -> int:
        """Gets/sets a vertical coordinate of the main window."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Left_metadata)

    _set_Left_metadata = { "offset" : _set_Left_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Left.setter
    def Left(self, newVal:int) -> None:
        """Gets/sets a vertical coordinate of the main window."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_Left_metadata, newVal)

    _get_Top_metadata = { "offset" : _get_Top_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Top(self) -> int:
        """Gets/sets a horizontal coordinate of the main window."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Top_metadata)

    _set_Top_metadata = { "offset" : _set_Top_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Top.setter
    def Top(self, newVal:int) -> None:
        """Gets/sets a horizontal coordinate of the main window."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_Top_metadata, newVal)

    _get_WindowState_metadata = { "offset" : _get_WindowState_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEWindowState),) }
    @property
    def WindowState(self) -> "AgEWindowState":
        """Gets/sets the state of the main window."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_WindowState_metadata)

    _set_WindowState_metadata = { "offset" : _set_WindowState_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEWindowState),) }
    @WindowState.setter
    def WindowState(self, newVal:"AgEWindowState") -> None:
        """Gets/sets the state of the main window."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_WindowState_metadata, newVal)

    _Activate_metadata = { "offset" : _Activate_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Activate(self) -> None:
        """Activates the application's main window."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._Activate_metadata, )

    _get_MRUList_metadata = { "offset" : _get_MRUList_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def MRUList(self) -> "IAgMRUCollection":
        """Returns a collection most recently used files."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_MRUList_metadata)

    _FileOpenDialog_metadata = { "offset" : _FileOpenDialog_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def FileOpenDialog(self, defaultExt:str, filter:str, initialDir:str) -> str:
        """Brings up a common File Open dialog and returns the file name selected by the user. If the user canceled, returns an empty file name."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._FileOpenDialog_metadata, defaultExt, filter, initialDir, OutArg())

    _get_Path_metadata = { "offset" : _get_Path_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Path(self) -> str:
        """Returns the complete path to the application, excluding the final separator and name of the application. Read-only String."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Path_metadata)

    _CreateObject_metadata = { "offset" : _CreateObject_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def CreateObject(self, progID:str, remoteServer:str) -> typing.Any:
        """Only works from local HTML pages and scripts."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._CreateObject_metadata, progID, remoteServer, OutArg())

    _FileSaveAsDialog_metadata = { "offset" : _FileSaveAsDialog_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def FileSaveAsDialog(self, defaultExt:str, filter:str, initialDir:str) -> str:
        """Brings up a common File SaveAs dialog and returns the file name selected by the user. If the user canceled, returns an empty file name."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._FileSaveAsDialog_metadata, defaultExt, filter, initialDir, OutArg())

    _Quit_metadata = { "offset" : _Quit_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Quit(self) -> None:
        """Shuts down the application."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._Quit_metadata, )

    _FileOpenDialogExt_metadata = { "offset" : _FileOpenDialogExt_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def FileOpenDialogExt(self, allowMultiSelect:bool, defaultExt:str, filter:str, initialDir:str) -> "IAgUiFileOpenExt":
        """Brings up a standard File Open Dialog and returns an object representing the selected file."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._FileOpenDialogExt_metadata, allowMultiSelect, defaultExt, filter, initialDir, OutArg())

    _get_HWND_metadata = { "offset" : _get_HWND_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def HWND(self) -> int:
        """Returns an HWND handle associated with the application main window."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_HWND_metadata)

    _DirectoryPickerDialog_metadata = { "offset" : _DirectoryPickerDialog_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DirectoryPickerDialog(self, title:str, initialDir:str) -> str:
        """Brings up the Directory Picker Dialog and returns a selected directory name."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._DirectoryPickerDialog_metadata, title, initialDir, OutArg())

    _get_MessagePendingDelay_metadata = { "offset" : _get_MessagePendingDelay_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def MessagePendingDelay(self) -> int:
        """Gets/Sets message-pending delay for server busy dialog (in milliseconds)."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_MessagePendingDelay_metadata)

    _set_MessagePendingDelay_metadata = { "offset" : _set_MessagePendingDelay_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @MessagePendingDelay.setter
    def MessagePendingDelay(self, newVal:int) -> None:
        """Gets/Sets message-pending delay for server busy dialog (in milliseconds)."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_MessagePendingDelay_metadata, newVal)

    _get_Personality2_metadata = { "offset" : _get_Personality2_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Personality2(self) -> typing.Any:
        """Returns an new instance of the root object of the STK Object Model."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_Personality2_metadata)

    _OpenLogFile_metadata = { "offset" : _OpenLogFile_method_offset,
            "arg_types" : (agcom.BSTR, agcom.LONG, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgEnum_arg(AgEOpenLogFileMode), agmarshall.VARIANT_BOOL_arg,) }
    def OpenLogFile(self, logFileName:str, logFileMode:"AgEOpenLogFileMode") -> bool:
        """Specifies the current log file to be written to."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._OpenLogFile_metadata, logFileName, logFileMode, OutArg())

    _LogMsg_metadata = { "offset" : _LogMsg_method_offset,
            "arg_types" : (agcom.LONG, agcom.BSTR,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUiLogMsgType), agmarshall.BSTR_arg,) }
    def LogMsg(self, msgType:"AgEUiLogMsgType", msg:str) -> None:
        """Logs the Message specified."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._LogMsg_metadata, msgType, msg)

    _get_LogFile_metadata = { "offset" : _get_LogFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LogFile(self) -> str:
        """Gets the current log files full path."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_LogFile_metadata)

    _get_DisplayAlerts_metadata = { "offset" : _get_DisplayAlerts_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DisplayAlerts(self) -> bool:
        """Set to true to display certain alerts and messages. Otherwise false. The default value is True."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_DisplayAlerts_metadata)

    _set_DisplayAlerts_metadata = { "offset" : _set_DisplayAlerts_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DisplayAlerts.setter
    def DisplayAlerts(self, displayAlerts:bool) -> None:
        """Set to true to display certain alerts and messages. Otherwise false. The default value is True."""
        return self._intf.set_property(IAgUiApplication._metadata, IAgUiApplication._set_DisplayAlerts_metadata, displayAlerts)

    _CreateApplication_metadata = { "offset" : _CreateApplication_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def CreateApplication(self) -> "IAgUiApplication":
        """Create a new instance of the application model root object."""
        return self._intf.invoke(IAgUiApplication._metadata, IAgUiApplication._CreateApplication_metadata, OutArg())

    _get_ProcessID_metadata = { "offset" : _get_ProcessID_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ProcessID(self) -> int:
        """Gets process id for the current instance."""
        return self._intf.get_property(IAgUiApplication._metadata, IAgUiApplication._get_ProcessID_metadata)

    _property_names[Personality] = "Personality"
    _property_names[Visible] = "Visible"
    _property_names[UserControl] = "UserControl"
    _property_names[Windows] = "Windows"
    _property_names[Height] = "Height"
    _property_names[Width] = "Width"
    _property_names[Left] = "Left"
    _property_names[Top] = "Top"
    _property_names[WindowState] = "WindowState"
    _property_names[MRUList] = "MRUList"
    _property_names[Path] = "Path"
    _property_names[HWND] = "HWND"
    _property_names[MessagePendingDelay] = "MessagePendingDelay"
    _property_names[Personality2] = "Personality2"
    _property_names[LogFile] = "LogFile"
    _property_names[DisplayAlerts] = "DisplayAlerts"
    _property_names[ProcessID] = "ProcessID"


agcls.AgClassCatalog.add_catalog_entry((5152548327130061473, 179254138349634492), IAgUiApplication)
agcls.AgTypeNameMap["IAgUiApplication"] = IAgUiApplication

class IAgUiApplicationPartnerAccess(object):
    """Access to the application object model for business partners."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _GrantPartnerAccess_method_offset = 1
    _metadata = {
        "iid_data" : (5167873979092294442, 1106320289392679061),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiApplicationPartnerAccess."""
        initialize_from_source_object(self, sourceObject, IAgUiApplicationPartnerAccess)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiApplicationPartnerAccess)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiApplicationPartnerAccess, None)
    
    _GrantPartnerAccess_metadata = { "offset" : _GrantPartnerAccess_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GrantPartnerAccess(self, vendor:str, product:str, key:str) -> typing.Any:
        """Provide object model root for authorized business partners."""
        return self._intf.invoke(IAgUiApplicationPartnerAccess._metadata, IAgUiApplicationPartnerAccess._GrantPartnerAccess_metadata, vendor, product, key, OutArg())



agcls.AgClassCatalog.add_catalog_entry((5167873979092294442, 1106320289392679061), IAgUiApplicationPartnerAccess)
agcls.AgTypeNameMap["IAgUiApplicationPartnerAccess"] = IAgUiApplicationPartnerAccess

class IAgUiFileOpenExtCollection(object):
    """Multiple file open collection."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _get__NewEnum_method_offset = 2
    _Item_method_offset = 3
    _metadata = {
        "iid_data" : (5663541480808773789, 6468980721787839653),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiFileOpenExtCollection."""
        initialize_from_source_object(self, sourceObject, IAgUiFileOpenExtCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiFileOpenExtCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiFileOpenExtCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgUiFileOpenExtCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> str:
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Gets the total count of files in the collection."""
        return self._intf.get_property(IAgUiFileOpenExtCollection._metadata, IAgUiFileOpenExtCollection._get_Count_metadata)

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Enumerates through the file collection."""
        return self._intf.get_property(IAgUiFileOpenExtCollection._metadata, IAgUiFileOpenExtCollection._get__NewEnum_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.BSTR_arg,) }
    def Item(self, nIndex:int) -> str:
        """Gets the file at the specified index."""
        return self._intf.invoke(IAgUiFileOpenExtCollection._metadata, IAgUiFileOpenExtCollection._Item_metadata, nIndex, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5663541480808773789, 6468980721787839653), IAgUiFileOpenExtCollection)
agcls.AgTypeNameMap["IAgUiFileOpenExtCollection"] = IAgUiFileOpenExtCollection



class AgUiApplication(IAgUiApplication, IAgUiApplicationPartnerAccess, SupportsDeleteCallback):
    """A root object of the Application Model."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiApplication."""
        SupportsDeleteCallback.__init__(self)
        IAgUiApplication.__init__(self, sourceObject)
        IAgUiApplicationPartnerAccess.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiApplication._private_init(self, intf)
        IAgUiApplicationPartnerAccess._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiApplication, [IAgUiApplication, IAgUiApplicationPartnerAccess])

agcls.AgClassCatalog.add_catalog_entry((5006026089128684578, 1580294365369460875), AgUiApplication)
agcls.AgTypeNameMap["AgUiApplication"] = AgUiApplication

class AgMRUCollection(IAgMRUCollection, SupportsDeleteCallback):
    """Provides information about most recently used (MRU) list."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgMRUCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgMRUCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgMRUCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgMRUCollection, [IAgMRUCollection])

agcls.AgClassCatalog.add_catalog_entry((4906190746948977919, 5654723336100906907), AgMRUCollection)
agcls.AgTypeNameMap["AgMRUCollection"] = AgMRUCollection

class AgUiFileOpenExtCollection(IAgUiFileOpenExtCollection, SupportsDeleteCallback):
    """Multiple file open collection."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiFileOpenExtCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgUiFileOpenExtCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiFileOpenExtCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiFileOpenExtCollection, [IAgUiFileOpenExtCollection])

agcls.AgClassCatalog.add_catalog_entry((4816855088544067481, 231753964531063469), AgUiFileOpenExtCollection)
agcls.AgTypeNameMap["AgUiFileOpenExtCollection"] = AgUiFileOpenExtCollection

class AgUiFileOpenExt(IAgUiFileOpenExt, SupportsDeleteCallback):
    """Access to file open dialog that allows multiple file specifications."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiFileOpenExt."""
        SupportsDeleteCallback.__init__(self)
        IAgUiFileOpenExt.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiFileOpenExt._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiFileOpenExt, [IAgUiFileOpenExt])

agcls.AgClassCatalog.add_catalog_entry((4850055024671377715, 12513386433369472389), AgUiFileOpenExt)
agcls.AgTypeNameMap["AgUiFileOpenExt"] = AgUiFileOpenExt


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
