################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgERfcmAnalysisConfigurationComputeStepMode", "AgERfcmAnalysisConfigurationModelType", "AgERfcmAnalysisResultsFileMode", 
"AgERfcmAnalysisSolverBoundingBoxMode", "AgERfcmChannelResponseType", "AgERfcmImageWindowType", "AgERfcmPolarizationType", 
"AgERfcmTransceiverMode", "AgERfcmTransceiverModelType", "AgStkRFChannelModeler", "AgStkRfcmAnalysis", "AgStkRfcmAnalysisConfiguration", 
"AgStkRfcmAnalysisConfigurationCollection", "AgStkRfcmAnalysisLink", "AgStkRfcmAnalysisLinkCollection", "AgStkRfcmCommunicationsAnalysisConfigurationModel", 
"AgStkRfcmCommunicationsTransceiverConfiguration", "AgStkRfcmCommunicationsTransceiverConfigurationCollection", "AgStkRfcmCommunicationsTransceiverModel", 
"AgStkRfcmCommunicationsWaveform", "AgStkRfcmComputeOptions", "AgStkRfcmElementExportPatternAntenna", "AgStkRfcmExtent", 
"AgStkRfcmFacetTileset", "AgStkRfcmFacetTilesetCollection", "AgStkRfcmFarFieldDataPatternAntenna", "AgStkRfcmFrequencyPulseResponse", 
"AgStkRfcmGpuProperties", "AgStkRfcmMaterial", "AgStkRfcmParametricBeamAntenna", "AgStkRfcmRadarISarAnalysisConfigurationModel", 
"AgStkRfcmRadarISarAnalysisLink", "AgStkRfcmRadarImagingDataProduct", "AgStkRfcmRadarImagingDataProductCollection", "AgStkRfcmRadarSarAnalysisConfigurationModel", 
"AgStkRfcmRadarSarAnalysisLink", "AgStkRfcmRadarSarImageLocation", "AgStkRfcmRadarSarImageLocationCollection", "AgStkRfcmRadarTargetCollection", 
"AgStkRfcmRadarTransceiverConfiguration", "AgStkRfcmRadarTransceiverConfigurationCollection", "AgStkRfcmRadarTransceiverModel", 
"AgStkRfcmRadarWaveform", "AgStkRfcmRangeDopplerResponse", "AgStkRfcmSceneContributor", "AgStkRfcmSceneContributorCollection", 
"AgStkRfcmTransceiver", "AgStkRfcmTransceiverCollection", "AgStkRfcmValidationResponse", "IAgStkRFChannelModeler", "IAgStkRfcmAnalysis", 
"IAgStkRfcmAnalysisConfiguration", "IAgStkRfcmAnalysisConfigurationCollection", "IAgStkRfcmAnalysisConfigurationModel", 
"IAgStkRfcmAnalysisLink", "IAgStkRfcmAnalysisLinkCollection", "IAgStkRfcmAntenna", "IAgStkRfcmCommunicationsAnalysisConfigurationModel", 
"IAgStkRfcmCommunicationsTransceiverConfiguration", "IAgStkRfcmCommunicationsTransceiverConfigurationCollection", "IAgStkRfcmCommunicationsTransceiverModel", 
"IAgStkRfcmCommunicationsWaveform", "IAgStkRfcmComputeOptions", "IAgStkRfcmElementExportPatternAntenna", "IAgStkRfcmExtent", 
"IAgStkRfcmFacetTileset", "IAgStkRfcmFacetTilesetCollection", "IAgStkRfcmFarFieldDataPatternAntenna", "IAgStkRfcmFrequencyPulseResponse", 
"IAgStkRfcmGpuProperties", "IAgStkRfcmMaterial", "IAgStkRfcmParametricBeamAntenna", "IAgStkRfcmProgressTrackCancel", "IAgStkRfcmRadarAnalysisConfigurationModel", 
"IAgStkRfcmRadarISarAnalysisConfigurationModel", "IAgStkRfcmRadarISarAnalysisLink", "IAgStkRfcmRadarImagingDataProduct", 
"IAgStkRfcmRadarImagingDataProductCollection", "IAgStkRfcmRadarSarAnalysisConfigurationModel", "IAgStkRfcmRadarSarAnalysisLink", 
"IAgStkRfcmRadarSarImageLocation", "IAgStkRfcmRadarSarImageLocationCollection", "IAgStkRfcmRadarTransceiverConfiguration", 
"IAgStkRfcmRadarTransceiverConfigurationCollection", "IAgStkRfcmRadarTransceiverModel", "IAgStkRfcmRadarWaveform", "IAgStkRfcmRangeDopplerResponse", 
"IAgStkRfcmResponse", "IAgStkRfcmSceneContributor", "IAgStkRfcmSceneContributorCollection", "IAgStkRfcmTransceiver", "IAgStkRfcmTransceiverCollection", 
"IAgStkRfcmTransceiverModel", "IAgStkRfcmValidationResponse"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgERfcmChannelResponseType(IntEnum):
    """Channel Response Type"""
   
    eRfcmChannelResponseTypeFrequencyPulse = 0
    """Frequency-Pulse"""
    eRfcmChannelResponseTypeRangeDoppler = 1
    """Range-Doppler"""

AgERfcmChannelResponseType.eRfcmChannelResponseTypeFrequencyPulse.__doc__ = "Frequency-Pulse"
AgERfcmChannelResponseType.eRfcmChannelResponseTypeRangeDoppler.__doc__ = "Range-Doppler"

agcls.AgTypeNameMap["AgERfcmChannelResponseType"] = AgERfcmChannelResponseType

class AgERfcmAnalysisConfigurationModelType(IntEnum):
    """Analysis Configuration Model Type"""
   
    eRfcmAnalysisConfigurationModelTypeCommunications = 0
    """Communications"""
    eRfcmAnalysisConfigurationModelTypeRadarISar = 1
    """Radar ISAR"""
    eRfcmAnalysisConfigurationModelTypeRadarSar = 2
    """Radar SAR"""

AgERfcmAnalysisConfigurationModelType.eRfcmAnalysisConfigurationModelTypeCommunications.__doc__ = "Communications"
AgERfcmAnalysisConfigurationModelType.eRfcmAnalysisConfigurationModelTypeRadarISar.__doc__ = "Radar ISAR"
AgERfcmAnalysisConfigurationModelType.eRfcmAnalysisConfigurationModelTypeRadarSar.__doc__ = "Radar SAR"

agcls.AgTypeNameMap["AgERfcmAnalysisConfigurationModelType"] = AgERfcmAnalysisConfigurationModelType

class AgERfcmTransceiverMode(IntEnum):
    """Transceiver Mode"""
   
    eRfcmTransceiverModeTransceive = 0
    """Transceive"""
    eRfcmTransceiverModeTransmitOnly = 1
    """Transmit Only"""
    eRfcmTransceiverModeReceiveOnly = 2
    """Receive Only"""

AgERfcmTransceiverMode.eRfcmTransceiverModeTransceive.__doc__ = "Transceive"
AgERfcmTransceiverMode.eRfcmTransceiverModeTransmitOnly.__doc__ = "Transmit Only"
AgERfcmTransceiverMode.eRfcmTransceiverModeReceiveOnly.__doc__ = "Receive Only"

agcls.AgTypeNameMap["AgERfcmTransceiverMode"] = AgERfcmTransceiverMode

class AgERfcmAnalysisConfigurationComputeStepMode(IntEnum):
    """Analysis configuration compute step mode."""
   
    eRfcmAnalysisConfigurationComputeStepModeFixedStepSize = 0
    """Fixed Step size"""
    eRfcmAnalysisConfigurationComputeStepModeFixedStepCount = 1
    """Fixed Step count"""
    eRfcmAnalysisConfigurationComputeStepModeContinuousChannelSoundings = 0
    """Continuous channel soundings"""

AgERfcmAnalysisConfigurationComputeStepMode.eRfcmAnalysisConfigurationComputeStepModeFixedStepSize.__doc__ = "Fixed Step size"
AgERfcmAnalysisConfigurationComputeStepMode.eRfcmAnalysisConfigurationComputeStepModeFixedStepCount.__doc__ = "Fixed Step count"
AgERfcmAnalysisConfigurationComputeStepMode.eRfcmAnalysisConfigurationComputeStepModeContinuousChannelSoundings.__doc__ = "Continuous channel soundings"

agcls.AgTypeNameMap["AgERfcmAnalysisConfigurationComputeStepMode"] = AgERfcmAnalysisConfigurationComputeStepMode

class AgERfcmAnalysisResultsFileMode(IntEnum):
    """Analysis results file mode."""
   
    eRfcmAnalysisResultsFileModeSingleFile = 0
    """Single file"""
    eRfcmAnalysisResultsFileModeOneFilePerLink = 1
    """One file per link"""

AgERfcmAnalysisResultsFileMode.eRfcmAnalysisResultsFileModeSingleFile.__doc__ = "Single file"
AgERfcmAnalysisResultsFileMode.eRfcmAnalysisResultsFileModeOneFilePerLink.__doc__ = "One file per link"

agcls.AgTypeNameMap["AgERfcmAnalysisResultsFileMode"] = AgERfcmAnalysisResultsFileMode

class AgERfcmAnalysisSolverBoundingBoxMode(IntEnum):
    """Analysis solver bounding box mode."""
   
    eRfcmAnalysisSolverBoundingBoxModeDefault = 0
    """Default"""
    eRfcmAnalysisSolverBoundingBoxModeFullScene = 1
    """Full Scene"""
    eRfcmAnalysisSolverBoundingBoxModeCustom = 2
    """Custom"""

AgERfcmAnalysisSolverBoundingBoxMode.eRfcmAnalysisSolverBoundingBoxModeDefault.__doc__ = "Default"
AgERfcmAnalysisSolverBoundingBoxMode.eRfcmAnalysisSolverBoundingBoxModeFullScene.__doc__ = "Full Scene"
AgERfcmAnalysisSolverBoundingBoxMode.eRfcmAnalysisSolverBoundingBoxModeCustom.__doc__ = "Custom"

agcls.AgTypeNameMap["AgERfcmAnalysisSolverBoundingBoxMode"] = AgERfcmAnalysisSolverBoundingBoxMode

class AgERfcmTransceiverModelType(IntEnum):
    """Transceiver Model Type"""
   
    eRfcmTransceiverModelTypeCommunications = 0
    """Communications"""
    eRfcmTransceiverModelTypeRadar = 1
    """Radar"""

AgERfcmTransceiverModelType.eRfcmTransceiverModelTypeCommunications.__doc__ = "Communications"
AgERfcmTransceiverModelType.eRfcmTransceiverModelTypeRadar.__doc__ = "Radar"

agcls.AgTypeNameMap["AgERfcmTransceiverModelType"] = AgERfcmTransceiverModelType

class AgERfcmPolarizationType(IntEnum):
    """Polarization Type"""
   
    eRfcmPolarizationTypeVertical = 0
    """Vertical"""
    eRfcmPolarizationTypeHorizontal = 1
    """Horizontal"""
    eRfcmPolarizationTypeRHCP = 2
    """RHCP"""
    eRfcmPolarizationTypeLHCP = 3
    """LHCP"""

AgERfcmPolarizationType.eRfcmPolarizationTypeVertical.__doc__ = "Vertical"
AgERfcmPolarizationType.eRfcmPolarizationTypeHorizontal.__doc__ = "Horizontal"
AgERfcmPolarizationType.eRfcmPolarizationTypeRHCP.__doc__ = "RHCP"
AgERfcmPolarizationType.eRfcmPolarizationTypeLHCP.__doc__ = "LHCP"

agcls.AgTypeNameMap["AgERfcmPolarizationType"] = AgERfcmPolarizationType

class AgERfcmImageWindowType(IntEnum):
    """Polarization Type"""
   
    eRfcmImageWindowTypeFlat = 0
    """Flat"""
    eRfcmImageWindowTypeHann = 1
    """Hann"""
    eRfcmImageWindowTypeHamming = 2
    """Hamming"""
    eRfcmImageWindowTypeTaylor = 3
    """Taylor"""

AgERfcmImageWindowType.eRfcmImageWindowTypeFlat.__doc__ = "Flat"
AgERfcmImageWindowType.eRfcmImageWindowTypeHann.__doc__ = "Hann"
AgERfcmImageWindowType.eRfcmImageWindowTypeHamming.__doc__ = "Hamming"
AgERfcmImageWindowType.eRfcmImageWindowTypeTaylor.__doc__ = "Taylor"

agcls.AgTypeNameMap["AgERfcmImageWindowType"] = AgERfcmImageWindowType


class IAgStkRfcmProgressTrackCancel(object):
    """Control for progress tracker."""

    _num_methods = 2
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_CancelRequested_method_offset = 1
    _UpdateProgress_method_offset = 2
    _metadata = {
        "iid_data" : (5390916084034846203, 17403183235954599586),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmProgressTrackCancel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmProgressTrackCancel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmProgressTrackCancel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmProgressTrackCancel, None)
    
    _get_CancelRequested_metadata = { "offset" : _get_CancelRequested_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def CancelRequested(self) -> bool:
        """Gets whether or not cancel was requested."""
        return self._intf.get_property(IAgStkRfcmProgressTrackCancel._metadata, IAgStkRfcmProgressTrackCancel._get_CancelRequested_metadata)

    _UpdateProgress_metadata = { "offset" : _UpdateProgress_method_offset,
            "arg_types" : (agcom.INT, agcom.BSTR,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.BSTR_arg,) }
    def UpdateProgress(self, progress:int, message:str) -> None:
        """Updates progress."""
        return self._intf.invoke(IAgStkRfcmProgressTrackCancel._metadata, IAgStkRfcmProgressTrackCancel._UpdateProgress_metadata, progress, message)

    _property_names[CancelRequested] = "CancelRequested"


agcls.AgClassCatalog.add_catalog_entry((5390916084034846203, 17403183235954599586), IAgStkRfcmProgressTrackCancel)
agcls.AgTypeNameMap["IAgStkRfcmProgressTrackCancel"] = IAgStkRfcmProgressTrackCancel

class IAgStkRfcmCommunicationsWaveform(object):
    """Properties for a communications waveform."""

    _num_methods = 13
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_FrequencySamplesPerSounding_method_offset = 1
    _set_FrequencySamplesPerSounding_method_offset = 2
    _get_ChannelBandwidth_method_offset = 3
    _set_ChannelBandwidth_method_offset = 4
    _get_RFChannelFrequency_method_offset = 5
    _set_RFChannelFrequency_method_offset = 6
    _get_SoundingInterval_method_offset = 7
    _set_SoundingInterval_method_offset = 8
    _get_SoundingsPerAnalysisTimeStep_method_offset = 9
    _set_SoundingsPerAnalysisTimeStep_method_offset = 10
    _get_CompleteSimulationInterval_method_offset = 11
    _get_UnambiguousChannelDelay_method_offset = 12
    _get_UnambiguousChannelDistance_method_offset = 13
    _metadata = {
        "iid_data" : (5073231083378675674, 13078442724957062319),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmCommunicationsWaveform."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmCommunicationsWaveform)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmCommunicationsWaveform)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmCommunicationsWaveform, None)
    
    _get_FrequencySamplesPerSounding_metadata = { "offset" : _get_FrequencySamplesPerSounding_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def FrequencySamplesPerSounding(self) -> int:
        """Gets or sets the waveform number of samples."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_FrequencySamplesPerSounding_metadata)

    _set_FrequencySamplesPerSounding_metadata = { "offset" : _set_FrequencySamplesPerSounding_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @FrequencySamplesPerSounding.setter
    def FrequencySamplesPerSounding(self, val:int) -> None:
        """Gets or sets the waveform number of samples."""
        return self._intf.set_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._set_FrequencySamplesPerSounding_metadata, val)

    _get_ChannelBandwidth_metadata = { "offset" : _get_ChannelBandwidth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ChannelBandwidth(self) -> float:
        """Gets or sets the waveform bandwidth."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_ChannelBandwidth_metadata)

    _set_ChannelBandwidth_metadata = { "offset" : _set_ChannelBandwidth_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @ChannelBandwidth.setter
    def ChannelBandwidth(self, val:float) -> None:
        """Gets or sets the waveform bandwidth."""
        return self._intf.set_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._set_ChannelBandwidth_metadata, val)

    _get_RFChannelFrequency_metadata = { "offset" : _get_RFChannelFrequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RFChannelFrequency(self) -> float:
        """Gets or sets the waveform frequency."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_RFChannelFrequency_metadata)

    _set_RFChannelFrequency_metadata = { "offset" : _set_RFChannelFrequency_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RFChannelFrequency.setter
    def RFChannelFrequency(self, val:float) -> None:
        """Gets or sets the waveform frequency."""
        return self._intf.set_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._set_RFChannelFrequency_metadata, val)

    _get_SoundingInterval_metadata = { "offset" : _get_SoundingInterval_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SoundingInterval(self) -> float:
        """Gets or sets the waveform pulse interval."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_SoundingInterval_metadata)

    _set_SoundingInterval_metadata = { "offset" : _set_SoundingInterval_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @SoundingInterval.setter
    def SoundingInterval(self, val:float) -> None:
        """Gets or sets the waveform pulse interval."""
        return self._intf.set_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._set_SoundingInterval_metadata, val)

    _get_SoundingsPerAnalysisTimeStep_metadata = { "offset" : _get_SoundingsPerAnalysisTimeStep_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def SoundingsPerAnalysisTimeStep(self) -> int:
        """Gets or sets the waveform number of pulses."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_SoundingsPerAnalysisTimeStep_metadata)

    _set_SoundingsPerAnalysisTimeStep_metadata = { "offset" : _set_SoundingsPerAnalysisTimeStep_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @SoundingsPerAnalysisTimeStep.setter
    def SoundingsPerAnalysisTimeStep(self, val:int) -> None:
        """Gets or sets the waveform number of pulses."""
        return self._intf.set_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._set_SoundingsPerAnalysisTimeStep_metadata, val)

    _get_CompleteSimulationInterval_metadata = { "offset" : _get_CompleteSimulationInterval_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CompleteSimulationInterval(self) -> float:
        """Gets the complete simulation interval."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_CompleteSimulationInterval_metadata)

    _get_UnambiguousChannelDelay_metadata = { "offset" : _get_UnambiguousChannelDelay_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def UnambiguousChannelDelay(self) -> float:
        """Gets the unambiguous channel delay."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_UnambiguousChannelDelay_metadata)

    _get_UnambiguousChannelDistance_metadata = { "offset" : _get_UnambiguousChannelDistance_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def UnambiguousChannelDistance(self) -> float:
        """Gets the unambiguous channel distance."""
        return self._intf.get_property(IAgStkRfcmCommunicationsWaveform._metadata, IAgStkRfcmCommunicationsWaveform._get_UnambiguousChannelDistance_metadata)

    _property_names[FrequencySamplesPerSounding] = "FrequencySamplesPerSounding"
    _property_names[ChannelBandwidth] = "ChannelBandwidth"
    _property_names[RFChannelFrequency] = "RFChannelFrequency"
    _property_names[SoundingInterval] = "SoundingInterval"
    _property_names[SoundingsPerAnalysisTimeStep] = "SoundingsPerAnalysisTimeStep"
    _property_names[CompleteSimulationInterval] = "CompleteSimulationInterval"
    _property_names[UnambiguousChannelDelay] = "UnambiguousChannelDelay"
    _property_names[UnambiguousChannelDistance] = "UnambiguousChannelDistance"


agcls.AgClassCatalog.add_catalog_entry((5073231083378675674, 13078442724957062319), IAgStkRfcmCommunicationsWaveform)
agcls.AgTypeNameMap["IAgStkRfcmCommunicationsWaveform"] = IAgStkRfcmCommunicationsWaveform

class IAgStkRfcmRadarWaveform(object):
    """Properties for a radar waveform."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_RFChannelFrequency_method_offset = 1
    _set_RFChannelFrequency_method_offset = 2
    _get_PulseRepetitionFrequency_method_offset = 3
    _set_PulseRepetitionFrequency_method_offset = 4
    _get_Bandwidth_method_offset = 5
    _set_Bandwidth_method_offset = 6
    _metadata = {
        "iid_data" : (5372724197743564578, 12276101041325134501),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarWaveform."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarWaveform)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarWaveform)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarWaveform, None)
    
    _get_RFChannelFrequency_metadata = { "offset" : _get_RFChannelFrequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RFChannelFrequency(self) -> float:
        """Gets or sets the waveform frequency."""
        return self._intf.get_property(IAgStkRfcmRadarWaveform._metadata, IAgStkRfcmRadarWaveform._get_RFChannelFrequency_metadata)

    _set_RFChannelFrequency_metadata = { "offset" : _set_RFChannelFrequency_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RFChannelFrequency.setter
    def RFChannelFrequency(self, val:float) -> None:
        """Gets or sets the waveform frequency."""
        return self._intf.set_property(IAgStkRfcmRadarWaveform._metadata, IAgStkRfcmRadarWaveform._set_RFChannelFrequency_metadata, val)

    _get_PulseRepetitionFrequency_metadata = { "offset" : _get_PulseRepetitionFrequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def PulseRepetitionFrequency(self) -> float:
        """Gets or set the pulse repetition frequency."""
        return self._intf.get_property(IAgStkRfcmRadarWaveform._metadata, IAgStkRfcmRadarWaveform._get_PulseRepetitionFrequency_metadata)

    _set_PulseRepetitionFrequency_metadata = { "offset" : _set_PulseRepetitionFrequency_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @PulseRepetitionFrequency.setter
    def PulseRepetitionFrequency(self, val:float) -> None:
        """Gets or set the pulse repetition frequency."""
        return self._intf.set_property(IAgStkRfcmRadarWaveform._metadata, IAgStkRfcmRadarWaveform._set_PulseRepetitionFrequency_metadata, val)

    _get_Bandwidth_metadata = { "offset" : _get_Bandwidth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Bandwidth(self) -> float:
        """Gets or sets the waveform bandwidth."""
        return self._intf.get_property(IAgStkRfcmRadarWaveform._metadata, IAgStkRfcmRadarWaveform._get_Bandwidth_metadata)

    _set_Bandwidth_metadata = { "offset" : _set_Bandwidth_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Bandwidth.setter
    def Bandwidth(self, val:float) -> None:
        """Gets or sets the waveform bandwidth."""
        return self._intf.set_property(IAgStkRfcmRadarWaveform._metadata, IAgStkRfcmRadarWaveform._set_Bandwidth_metadata, val)

    _property_names[RFChannelFrequency] = "RFChannelFrequency"
    _property_names[PulseRepetitionFrequency] = "PulseRepetitionFrequency"
    _property_names[Bandwidth] = "Bandwidth"


agcls.AgClassCatalog.add_catalog_entry((5372724197743564578, 12276101041325134501), IAgStkRfcmRadarWaveform)
agcls.AgTypeNameMap["IAgStkRfcmRadarWaveform"] = IAgStkRfcmRadarWaveform

class IAgStkRfcmAntenna(object):
    """Base interface for a transceiver antenna model."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Type_method_offset = 1
    _metadata = {
        "iid_data" : (5683541619882775739, 9487067282181233037),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmAntenna."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmAntenna)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmAntenna)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmAntenna, None)
    
    _get_Type_metadata = { "offset" : _get_Type_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Type(self) -> str:
        """Gets the antenna type."""
        return self._intf.get_property(IAgStkRfcmAntenna._metadata, IAgStkRfcmAntenna._get_Type_metadata)

    _property_names[Type] = "Type"


agcls.AgClassCatalog.add_catalog_entry((5683541619882775739, 9487067282181233037), IAgStkRfcmAntenna)
agcls.AgTypeNameMap["IAgStkRfcmAntenna"] = IAgStkRfcmAntenna

class IAgStkRfcmElementExportPatternAntenna(object):
    """Properties for an HFSS element export pattern (EEP) antenna model. This model accepts an EEP file which is exported from the Ansys HFSS software package."""

    _num_methods = 2
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_HfssElementExportPatternFile_method_offset = 1
    _set_HfssElementExportPatternFile_method_offset = 2
    _metadata = {
        "iid_data" : (4766319250734673987, 12312688800869503421),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmElementExportPatternAntenna."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmElementExportPatternAntenna)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmElementExportPatternAntenna)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmElementExportPatternAntenna, None)
    
    _get_HfssElementExportPatternFile_metadata = { "offset" : _get_HfssElementExportPatternFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def HfssElementExportPatternFile(self) -> str:
        """Gets or sets the HFSS element export pattern file."""
        return self._intf.get_property(IAgStkRfcmElementExportPatternAntenna._metadata, IAgStkRfcmElementExportPatternAntenna._get_HfssElementExportPatternFile_metadata)

    _set_HfssElementExportPatternFile_metadata = { "offset" : _set_HfssElementExportPatternFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @HfssElementExportPatternFile.setter
    def HfssElementExportPatternFile(self, val:str) -> None:
        """Gets or sets the HFSS element export pattern file."""
        return self._intf.set_property(IAgStkRfcmElementExportPatternAntenna._metadata, IAgStkRfcmElementExportPatternAntenna._set_HfssElementExportPatternFile_metadata, val)

    _property_names[HfssElementExportPatternFile] = "HfssElementExportPatternFile"


agcls.AgClassCatalog.add_catalog_entry((4766319250734673987, 12312688800869503421), IAgStkRfcmElementExportPatternAntenna)
agcls.AgTypeNameMap["IAgStkRfcmElementExportPatternAntenna"] = IAgStkRfcmElementExportPatternAntenna

class IAgStkRfcmFarFieldDataPatternAntenna(object):
    """Properties for an HFSS far field data (FFD) antenna model. This model accepts an FFD file which is exported from the Ansys HFSS software package."""

    _num_methods = 2
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_HfssFarFieldDataPatternFile_method_offset = 1
    _set_HfssFarFieldDataPatternFile_method_offset = 2
    _metadata = {
        "iid_data" : (5411664539639735101, 603918576028509367),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmFarFieldDataPatternAntenna."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmFarFieldDataPatternAntenna)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmFarFieldDataPatternAntenna)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmFarFieldDataPatternAntenna, None)
    
    _get_HfssFarFieldDataPatternFile_metadata = { "offset" : _get_HfssFarFieldDataPatternFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def HfssFarFieldDataPatternFile(self) -> str:
        """Gets or sets the HFSS far field data pattern file."""
        return self._intf.get_property(IAgStkRfcmFarFieldDataPatternAntenna._metadata, IAgStkRfcmFarFieldDataPatternAntenna._get_HfssFarFieldDataPatternFile_metadata)

    _set_HfssFarFieldDataPatternFile_metadata = { "offset" : _set_HfssFarFieldDataPatternFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @HfssFarFieldDataPatternFile.setter
    def HfssFarFieldDataPatternFile(self, val:str) -> None:
        """Gets or sets the HFSS far field data pattern file."""
        return self._intf.set_property(IAgStkRfcmFarFieldDataPatternAntenna._metadata, IAgStkRfcmFarFieldDataPatternAntenna._set_HfssFarFieldDataPatternFile_metadata, val)

    _property_names[HfssFarFieldDataPatternFile] = "HfssFarFieldDataPatternFile"


agcls.AgClassCatalog.add_catalog_entry((5411664539639735101, 603918576028509367), IAgStkRfcmFarFieldDataPatternAntenna)
agcls.AgTypeNameMap["IAgStkRfcmFarFieldDataPatternAntenna"] = IAgStkRfcmFarFieldDataPatternAntenna

class IAgStkRfcmParametricBeamAntenna(object):
    """Properties of an analytical parametric beam antenna."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_PolarizationType_method_offset = 1
    _set_PolarizationType_method_offset = 2
    _get_VerticalBeamwidth_method_offset = 3
    _set_VerticalBeamwidth_method_offset = 4
    _get_HorizontalBeamwidth_method_offset = 5
    _set_HorizontalBeamwidth_method_offset = 6
    _metadata = {
        "iid_data" : (5066231717385365390, 5698936586915315868),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmParametricBeamAntenna."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmParametricBeamAntenna)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmParametricBeamAntenna)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmParametricBeamAntenna, None)
    
    _get_PolarizationType_metadata = { "offset" : _get_PolarizationType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmPolarizationType),) }
    @property
    def PolarizationType(self) -> "AgERfcmPolarizationType":
        """Gets or sets the polarization type"""
        return self._intf.get_property(IAgStkRfcmParametricBeamAntenna._metadata, IAgStkRfcmParametricBeamAntenna._get_PolarizationType_metadata)

    _set_PolarizationType_metadata = { "offset" : _set_PolarizationType_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmPolarizationType),) }
    @PolarizationType.setter
    def PolarizationType(self, val:"AgERfcmPolarizationType") -> None:
        """Gets or sets the polarization type"""
        return self._intf.set_property(IAgStkRfcmParametricBeamAntenna._metadata, IAgStkRfcmParametricBeamAntenna._set_PolarizationType_metadata, val)

    _get_VerticalBeamwidth_metadata = { "offset" : _get_VerticalBeamwidth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def VerticalBeamwidth(self) -> float:
        """Gets or sets the vertical beamwidth"""
        return self._intf.get_property(IAgStkRfcmParametricBeamAntenna._metadata, IAgStkRfcmParametricBeamAntenna._get_VerticalBeamwidth_metadata)

    _set_VerticalBeamwidth_metadata = { "offset" : _set_VerticalBeamwidth_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @VerticalBeamwidth.setter
    def VerticalBeamwidth(self, val:float) -> None:
        """Gets or sets the vertical beamwidth"""
        return self._intf.set_property(IAgStkRfcmParametricBeamAntenna._metadata, IAgStkRfcmParametricBeamAntenna._set_VerticalBeamwidth_metadata, val)

    _get_HorizontalBeamwidth_metadata = { "offset" : _get_HorizontalBeamwidth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def HorizontalBeamwidth(self) -> float:
        """Gets or sets the horizontal beamwidth"""
        return self._intf.get_property(IAgStkRfcmParametricBeamAntenna._metadata, IAgStkRfcmParametricBeamAntenna._get_HorizontalBeamwidth_metadata)

    _set_HorizontalBeamwidth_metadata = { "offset" : _set_HorizontalBeamwidth_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @HorizontalBeamwidth.setter
    def HorizontalBeamwidth(self, val:float) -> None:
        """Gets or sets the horizontal beamwidth"""
        return self._intf.set_property(IAgStkRfcmParametricBeamAntenna._metadata, IAgStkRfcmParametricBeamAntenna._set_HorizontalBeamwidth_metadata, val)

    _property_names[PolarizationType] = "PolarizationType"
    _property_names[VerticalBeamwidth] = "VerticalBeamwidth"
    _property_names[HorizontalBeamwidth] = "HorizontalBeamwidth"


agcls.AgClassCatalog.add_catalog_entry((5066231717385365390, 5698936586915315868), IAgStkRfcmParametricBeamAntenna)
agcls.AgTypeNameMap["IAgStkRfcmParametricBeamAntenna"] = IAgStkRfcmParametricBeamAntenna

class IAgStkRfcmTransceiverModel(object):
    """Base interface which defines common properties for a transceiver model."""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Type_method_offset = 1
    _SetAntennaType_method_offset = 2
    _get_SupportedAntennaTypes_method_offset = 3
    _get_Antenna_method_offset = 4
    _metadata = {
        "iid_data" : (5260850364807721395, 1562001126796197285),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmTransceiverModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmTransceiverModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmTransceiverModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmTransceiverModel, None)
    
    _get_Type_metadata = { "offset" : _get_Type_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmTransceiverModelType),) }
    @property
    def Type(self) -> "AgERfcmTransceiverModelType":
        """Gets the transceiver unique identifier."""
        return self._intf.get_property(IAgStkRfcmTransceiverModel._metadata, IAgStkRfcmTransceiverModel._get_Type_metadata)

    _SetAntennaType_metadata = { "offset" : _SetAntennaType_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def SetAntennaType(self, antennaType:str) -> None:
        """Sets the transceiver's antenna type."""
        return self._intf.invoke(IAgStkRfcmTransceiverModel._metadata, IAgStkRfcmTransceiverModel._SetAntennaType_metadata, antennaType)

    _get_SupportedAntennaTypes_metadata = { "offset" : _get_SupportedAntennaTypes_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SupportedAntennaTypes(self) -> list:
        """Gets the supported antenna types."""
        return self._intf.get_property(IAgStkRfcmTransceiverModel._metadata, IAgStkRfcmTransceiverModel._get_SupportedAntennaTypes_metadata)

    _get_Antenna_metadata = { "offset" : _get_Antenna_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Antenna(self) -> "IAgStkRfcmAntenna":
        """Gets the transceiver's antenna settings."""
        return self._intf.get_property(IAgStkRfcmTransceiverModel._metadata, IAgStkRfcmTransceiverModel._get_Antenna_metadata)

    _property_names[Type] = "Type"
    _property_names[SupportedAntennaTypes] = "SupportedAntennaTypes"
    _property_names[Antenna] = "Antenna"


agcls.AgClassCatalog.add_catalog_entry((5260850364807721395, 1562001126796197285), IAgStkRfcmTransceiverModel)
agcls.AgTypeNameMap["IAgStkRfcmTransceiverModel"] = IAgStkRfcmTransceiverModel

class IAgStkRfcmCommunicationsTransceiverModel(object):
    """Properties for configuring a communications transceiver model."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Waveform_method_offset = 1
    _metadata = {
        "iid_data" : (5551616547060849613, 1549009027122701441),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmCommunicationsTransceiverModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmCommunicationsTransceiverModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmCommunicationsTransceiverModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmCommunicationsTransceiverModel, None)
    
    _get_Waveform_metadata = { "offset" : _get_Waveform_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Waveform(self) -> "IAgStkRfcmCommunicationsWaveform":
        """Gets the transceiver's waveform settings."""
        return self._intf.get_property(IAgStkRfcmCommunicationsTransceiverModel._metadata, IAgStkRfcmCommunicationsTransceiverModel._get_Waveform_metadata)

    _property_names[Waveform] = "Waveform"


agcls.AgClassCatalog.add_catalog_entry((5551616547060849613, 1549009027122701441), IAgStkRfcmCommunicationsTransceiverModel)
agcls.AgTypeNameMap["IAgStkRfcmCommunicationsTransceiverModel"] = IAgStkRfcmCommunicationsTransceiverModel

class IAgStkRfcmRadarTransceiverModel(object):
    """Properties for configuring a radar transceiver model."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Waveform_method_offset = 1
    _metadata = {
        "iid_data" : (5397355634120071946, 14881756830326487198),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarTransceiverModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarTransceiverModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarTransceiverModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarTransceiverModel, None)
    
    _get_Waveform_metadata = { "offset" : _get_Waveform_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Waveform(self) -> "IAgStkRfcmRadarWaveform":
        """Get the radar transceiver's waveform settings."""
        return self._intf.get_property(IAgStkRfcmRadarTransceiverModel._metadata, IAgStkRfcmRadarTransceiverModel._get_Waveform_metadata)

    _property_names[Waveform] = "Waveform"


agcls.AgClassCatalog.add_catalog_entry((5397355634120071946, 14881756830326487198), IAgStkRfcmRadarTransceiverModel)
agcls.AgTypeNameMap["IAgStkRfcmRadarTransceiverModel"] = IAgStkRfcmRadarTransceiverModel

class IAgStkRfcmTransceiver(object):
    """Properties for configuring a transceiver object."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Identifier_method_offset = 1
    _get_Name_method_offset = 2
    _set_Name_method_offset = 3
    _get_ParentObjectPath_method_offset = 4
    _set_ParentObjectPath_method_offset = 5
    _get_CentralBodyName_method_offset = 6
    _get_Model_method_offset = 7
    _metadata = {
        "iid_data" : (5558123964013987462, 4268831737052389557),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmTransceiver."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmTransceiver)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmTransceiver)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmTransceiver, None)
    
    _get_Identifier_metadata = { "offset" : _get_Identifier_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Identifier(self) -> str:
        """Gets the transceiver unique identifier."""
        return self._intf.get_property(IAgStkRfcmTransceiver._metadata, IAgStkRfcmTransceiver._get_Identifier_metadata)

    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Gets or sets the transceiver name."""
        return self._intf.get_property(IAgStkRfcmTransceiver._metadata, IAgStkRfcmTransceiver._get_Name_metadata)

    _set_Name_metadata = { "offset" : _set_Name_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Name.setter
    def Name(self, name:str) -> None:
        """Gets or sets the transceiver name."""
        return self._intf.set_property(IAgStkRfcmTransceiver._metadata, IAgStkRfcmTransceiver._set_Name_metadata, name)

    _get_ParentObjectPath_metadata = { "offset" : _get_ParentObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentObjectPath(self) -> str:
        """Gets or sets the transceiver's parent object path."""
        return self._intf.get_property(IAgStkRfcmTransceiver._metadata, IAgStkRfcmTransceiver._get_ParentObjectPath_metadata)

    _set_ParentObjectPath_metadata = { "offset" : _set_ParentObjectPath_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ParentObjectPath.setter
    def ParentObjectPath(self, parentObject:str) -> None:
        """Gets or sets the transceiver's parent object path."""
        return self._intf.set_property(IAgStkRfcmTransceiver._metadata, IAgStkRfcmTransceiver._set_ParentObjectPath_metadata, parentObject)

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """Gets the tileset central body name."""
        return self._intf.get_property(IAgStkRfcmTransceiver._metadata, IAgStkRfcmTransceiver._get_CentralBodyName_metadata)

    _get_Model_metadata = { "offset" : _get_Model_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Model(self) -> "IAgStkRfcmTransceiverModel":
        """Gets the transceiver model."""
        return self._intf.get_property(IAgStkRfcmTransceiver._metadata, IAgStkRfcmTransceiver._get_Model_metadata)

    _property_names[Identifier] = "Identifier"
    _property_names[Name] = "Name"
    _property_names[ParentObjectPath] = "ParentObjectPath"
    _property_names[CentralBodyName] = "CentralBodyName"
    _property_names[Model] = "Model"


agcls.AgClassCatalog.add_catalog_entry((5558123964013987462, 4268831737052389557), IAgStkRfcmTransceiver)
agcls.AgTypeNameMap["IAgStkRfcmTransceiver"] = IAgStkRfcmTransceiver

class IAgStkRfcmTransceiverCollection(object):
    """Collection of transceiver objects."""

    _num_methods = 9
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _RemoveAt_method_offset = 4
    _Remove_method_offset = 5
    _AddNew_method_offset = 6
    _Add_method_offset = 7
    _RemoveAll_method_offset = 8
    _FindByIdentifier_method_offset = 9
    _metadata = {
        "iid_data" : (5453563073797309057, 6941833189803444112),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmTransceiverCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmTransceiverCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmTransceiverCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmTransceiverCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmTransceiverCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmTransceiver":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmTransceiver":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._get__NewEnum_metadata)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Removes the transceiver with the supplied index."""
        return self._intf.invoke(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._RemoveAt_metadata, index)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"),) }
    def Remove(self, pTransceiver:"IAgStkRfcmTransceiver") -> None:
        """Removes the supplied transceiver from the collection."""
        return self._intf.invoke(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._Remove_metadata, pTransceiver)

    _AddNew_metadata = { "offset" : _AddNew_method_offset,
            "arg_types" : (agcom.LONG, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmTransceiverModelType), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def AddNew(self, type:"AgERfcmTransceiverModelType", name:str, parentObjectPath:str) -> "IAgStkRfcmTransceiver":
        """Adds and returns a new transceiver."""
        return self._intf.invoke(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._AddNew_metadata, type, name, parentObjectPath, OutArg())

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"),) }
    def Add(self, pVal:"IAgStkRfcmTransceiver") -> None:
        """Adds the supplied transceiver to the collection."""
        return self._intf.invoke(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._Add_metadata, pVal)

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Removes all transceivers from the collection."""
        return self._intf.invoke(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._RemoveAll_metadata, )

    _FindByIdentifier_metadata = { "offset" : _FindByIdentifier_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def FindByIdentifier(self, identifier:str) -> "IAgStkRfcmTransceiver":
        """Returns the transceiver in the collection with the supplied identifier or Null if not found or invalid."""
        return self._intf.invoke(IAgStkRfcmTransceiverCollection._metadata, IAgStkRfcmTransceiverCollection._FindByIdentifier_metadata, identifier, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5453563073797309057, 6941833189803444112), IAgStkRfcmTransceiverCollection)
agcls.AgTypeNameMap["IAgStkRfcmTransceiverCollection"] = IAgStkRfcmTransceiverCollection

class IAgStkRfcmCommunicationsTransceiverConfiguration(object):
    """Properties for a communication transceiver configuration. A transceiver configuration allows for changing the transceiver mode to one of three options, Transmit Only, Receive Only, or Transceive."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_SupportedTransceivers_method_offset = 1
    _get_Transceiver_method_offset = 2
    _set_Transceiver_method_offset = 3
    _get_Mode_method_offset = 4
    _set_Mode_method_offset = 5
    _get_IncludeParentObjectFacets_method_offset = 6
    _set_IncludeParentObjectFacets_method_offset = 7
    _metadata = {
        "iid_data" : (5172902671839407480, 8994840099133695906),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmCommunicationsTransceiverConfiguration."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmCommunicationsTransceiverConfiguration)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmCommunicationsTransceiverConfiguration)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmCommunicationsTransceiverConfiguration, None)
    
    _get_SupportedTransceivers_metadata = { "offset" : _get_SupportedTransceivers_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SupportedTransceivers(self) -> list:
        """Gets an array of available transceiver instances."""
        return self._intf.get_property(IAgStkRfcmCommunicationsTransceiverConfiguration._metadata, IAgStkRfcmCommunicationsTransceiverConfiguration._get_SupportedTransceivers_metadata)

    _get_Transceiver_metadata = { "offset" : _get_Transceiver_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Transceiver(self) -> "IAgStkRfcmTransceiver":
        """Gets or sets the transceiver."""
        return self._intf.get_property(IAgStkRfcmCommunicationsTransceiverConfiguration._metadata, IAgStkRfcmCommunicationsTransceiverConfiguration._get_Transceiver_metadata)

    _set_Transceiver_metadata = { "offset" : _set_Transceiver_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"),) }
    @Transceiver.setter
    def Transceiver(self, transceiver:"IAgStkRfcmTransceiver") -> None:
        """Gets or sets the transceiver."""
        return self._intf.set_property(IAgStkRfcmCommunicationsTransceiverConfiguration._metadata, IAgStkRfcmCommunicationsTransceiverConfiguration._set_Transceiver_metadata, transceiver)

    _get_Mode_metadata = { "offset" : _get_Mode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmTransceiverMode),) }
    @property
    def Mode(self) -> "AgERfcmTransceiverMode":
        """Gets or sets the transceiver mode."""
        return self._intf.get_property(IAgStkRfcmCommunicationsTransceiverConfiguration._metadata, IAgStkRfcmCommunicationsTransceiverConfiguration._get_Mode_metadata)

    _set_Mode_metadata = { "offset" : _set_Mode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmTransceiverMode),) }
    @Mode.setter
    def Mode(self, val:"AgERfcmTransceiverMode") -> None:
        """Gets or sets the transceiver mode."""
        return self._intf.set_property(IAgStkRfcmCommunicationsTransceiverConfiguration._metadata, IAgStkRfcmCommunicationsTransceiverConfiguration._set_Mode_metadata, val)

    _get_IncludeParentObjectFacets_metadata = { "offset" : _get_IncludeParentObjectFacets_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IncludeParentObjectFacets(self) -> bool:
        """Gets or sets an indicator of whether or not to include the parent object facets."""
        return self._intf.get_property(IAgStkRfcmCommunicationsTransceiverConfiguration._metadata, IAgStkRfcmCommunicationsTransceiverConfiguration._get_IncludeParentObjectFacets_metadata)

    _set_IncludeParentObjectFacets_metadata = { "offset" : _set_IncludeParentObjectFacets_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @IncludeParentObjectFacets.setter
    def IncludeParentObjectFacets(self, val:bool) -> None:
        """Gets or sets an indicator of whether or not to include the parent object facets."""
        return self._intf.set_property(IAgStkRfcmCommunicationsTransceiverConfiguration._metadata, IAgStkRfcmCommunicationsTransceiverConfiguration._set_IncludeParentObjectFacets_metadata, val)

    _property_names[SupportedTransceivers] = "SupportedTransceivers"
    _property_names[Transceiver] = "Transceiver"
    _property_names[Mode] = "Mode"
    _property_names[IncludeParentObjectFacets] = "IncludeParentObjectFacets"


agcls.AgClassCatalog.add_catalog_entry((5172902671839407480, 8994840099133695906), IAgStkRfcmCommunicationsTransceiverConfiguration)
agcls.AgTypeNameMap["IAgStkRfcmCommunicationsTransceiverConfiguration"] = IAgStkRfcmCommunicationsTransceiverConfiguration

class IAgStkRfcmCommunicationsTransceiverConfigurationCollection(object):
    """Represents a collection of communication transceiver configurations."""

    _num_methods = 8
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _RemoveAt_method_offset = 4
    _Remove_method_offset = 5
    _AddNew_method_offset = 6
    _RemoveAll_method_offset = 7
    _Contains_method_offset = 8
    _metadata = {
        "iid_data" : (5571394370622903367, 10058552235130119822),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmCommunicationsTransceiverConfigurationCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmCommunicationsTransceiverConfigurationCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmCommunicationsTransceiverConfigurationCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmCommunicationsTransceiverConfigurationCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmCommunicationsTransceiverConfigurationCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmCommunicationsTransceiverConfiguration":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmCommunicationsTransceiverConfiguration":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._get__NewEnum_metadata)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Removes the configuration with the supplied index."""
        return self._intf.invoke(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._RemoveAt_metadata, index)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"),) }
    def Remove(self, pTransceiver:"IAgStkRfcmTransceiver") -> None:
        """Removes the supplied configuration from the collection."""
        return self._intf.invoke(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._Remove_metadata, pTransceiver)

    _AddNew_metadata = { "offset" : _AddNew_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def AddNew(self) -> "IAgStkRfcmCommunicationsTransceiverConfiguration":
        """Adds and returns a new configuration."""
        return self._intf.invoke(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._AddNew_metadata, OutArg())

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Clears all configurations from the collection."""
        return self._intf.invoke(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._RemoveAll_metadata, )

    _Contains_metadata = { "offset" : _Contains_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"), agmarshall.VARIANT_BOOL_arg,) }
    def Contains(self, pTransceiver:"IAgStkRfcmTransceiver") -> bool:
        """Checks to see if a given configuration exists in the collection."""
        return self._intf.invoke(IAgStkRfcmCommunicationsTransceiverConfigurationCollection._metadata, IAgStkRfcmCommunicationsTransceiverConfigurationCollection._Contains_metadata, pTransceiver, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5571394370622903367, 10058552235130119822), IAgStkRfcmCommunicationsTransceiverConfigurationCollection)
agcls.AgTypeNameMap["IAgStkRfcmCommunicationsTransceiverConfigurationCollection"] = IAgStkRfcmCommunicationsTransceiverConfigurationCollection

class IAgStkRfcmRadarTransceiverConfiguration(object):
    """Properties for a radar transceiver configuration. A transceiver configuration allows for changing the transceiver mode to one of three options, Transmit Only, Receive Only, or Transceive."""

    _num_methods = 5
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_SupportedTransceivers_method_offset = 1
    _get_Transceiver_method_offset = 2
    _set_Transceiver_method_offset = 3
    _get_Mode_method_offset = 4
    _set_Mode_method_offset = 5
    _metadata = {
        "iid_data" : (4659302401260160265, 11650713832413966732),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarTransceiverConfiguration."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarTransceiverConfiguration)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarTransceiverConfiguration)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarTransceiverConfiguration, None)
    
    _get_SupportedTransceivers_metadata = { "offset" : _get_SupportedTransceivers_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SupportedTransceivers(self) -> list:
        """Gets an array of available transceiver instances."""
        return self._intf.get_property(IAgStkRfcmRadarTransceiverConfiguration._metadata, IAgStkRfcmRadarTransceiverConfiguration._get_SupportedTransceivers_metadata)

    _get_Transceiver_metadata = { "offset" : _get_Transceiver_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Transceiver(self) -> "IAgStkRfcmTransceiver":
        """Gets or sets the transceiver."""
        return self._intf.get_property(IAgStkRfcmRadarTransceiverConfiguration._metadata, IAgStkRfcmRadarTransceiverConfiguration._get_Transceiver_metadata)

    _set_Transceiver_metadata = { "offset" : _set_Transceiver_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"),) }
    @Transceiver.setter
    def Transceiver(self, transceiver:"IAgStkRfcmTransceiver") -> None:
        """Gets or sets the transceiver."""
        return self._intf.set_property(IAgStkRfcmRadarTransceiverConfiguration._metadata, IAgStkRfcmRadarTransceiverConfiguration._set_Transceiver_metadata, transceiver)

    _get_Mode_metadata = { "offset" : _get_Mode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmTransceiverMode),) }
    @property
    def Mode(self) -> "AgERfcmTransceiverMode":
        """Gets or sets the transceiver mode."""
        return self._intf.get_property(IAgStkRfcmRadarTransceiverConfiguration._metadata, IAgStkRfcmRadarTransceiverConfiguration._get_Mode_metadata)

    _set_Mode_metadata = { "offset" : _set_Mode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmTransceiverMode),) }
    @Mode.setter
    def Mode(self, val:"AgERfcmTransceiverMode") -> None:
        """Gets or sets the transceiver mode."""
        return self._intf.set_property(IAgStkRfcmRadarTransceiverConfiguration._metadata, IAgStkRfcmRadarTransceiverConfiguration._set_Mode_metadata, val)

    _property_names[SupportedTransceivers] = "SupportedTransceivers"
    _property_names[Transceiver] = "Transceiver"
    _property_names[Mode] = "Mode"


agcls.AgClassCatalog.add_catalog_entry((4659302401260160265, 11650713832413966732), IAgStkRfcmRadarTransceiverConfiguration)
agcls.AgTypeNameMap["IAgStkRfcmRadarTransceiverConfiguration"] = IAgStkRfcmRadarTransceiverConfiguration

class IAgStkRfcmRadarTransceiverConfigurationCollection(object):
    """Represents a collection of radar transceiver configurations."""

    _num_methods = 8
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _RemoveAt_method_offset = 4
    _Remove_method_offset = 5
    _AddNew_method_offset = 6
    _RemoveAll_method_offset = 7
    _Contains_method_offset = 8
    _metadata = {
        "iid_data" : (4807842543420809634, 14097660371338695355),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarTransceiverConfigurationCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarTransceiverConfigurationCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarTransceiverConfigurationCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarTransceiverConfigurationCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmRadarTransceiverConfigurationCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmRadarTransceiverConfiguration":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmRadarTransceiverConfiguration":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._get__NewEnum_metadata)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Removes the configuration with the supplied index."""
        return self._intf.invoke(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._RemoveAt_metadata, index)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"),) }
    def Remove(self, pTransceiver:"IAgStkRfcmTransceiver") -> None:
        """Removes the supplied transceiver from the collection."""
        return self._intf.invoke(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._Remove_metadata, pTransceiver)

    _AddNew_metadata = { "offset" : _AddNew_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def AddNew(self) -> "IAgStkRfcmRadarTransceiverConfiguration":
        """Adds and returns a new configuration."""
        return self._intf.invoke(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._AddNew_metadata, OutArg())

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Clears all configurations from the collection."""
        return self._intf.invoke(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._RemoveAll_metadata, )

    _Contains_metadata = { "offset" : _Contains_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"), agmarshall.VARIANT_BOOL_arg,) }
    def Contains(self, pTransceiver:"IAgStkRfcmTransceiver") -> bool:
        """Checks to see if a given configuration exists in the collection."""
        return self._intf.invoke(IAgStkRfcmRadarTransceiverConfigurationCollection._metadata, IAgStkRfcmRadarTransceiverConfigurationCollection._Contains_metadata, pTransceiver, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((4807842543420809634, 14097660371338695355), IAgStkRfcmRadarTransceiverConfigurationCollection)
agcls.AgTypeNameMap["IAgStkRfcmRadarTransceiverConfigurationCollection"] = IAgStkRfcmRadarTransceiverConfigurationCollection

class IAgStkRfcmSceneContributor(object):
    """Properties for a scene contributor object."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_StkObjectPath_method_offset = 1
    _set_StkObjectPath_method_offset = 2
    _get_Material_method_offset = 3
    _set_Material_method_offset = 4
    _get_CentralBodyName_method_offset = 5
    _get_FocusedRayDensity_method_offset = 6
    _set_FocusedRayDensity_method_offset = 7
    _metadata = {
        "iid_data" : (5289282663936466784, 6187411627788191675),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmSceneContributor."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmSceneContributor)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmSceneContributor)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmSceneContributor, None)
    
    _get_StkObjectPath_metadata = { "offset" : _get_StkObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def StkObjectPath(self) -> str:
        """Gets or sets the scene contributor path."""
        return self._intf.get_property(IAgStkRfcmSceneContributor._metadata, IAgStkRfcmSceneContributor._get_StkObjectPath_metadata)

    _set_StkObjectPath_metadata = { "offset" : _set_StkObjectPath_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @StkObjectPath.setter
    def StkObjectPath(self, stkObjectPath:str) -> None:
        """Gets or sets the scene contributor path."""
        return self._intf.set_property(IAgStkRfcmSceneContributor._metadata, IAgStkRfcmSceneContributor._set_StkObjectPath_metadata, stkObjectPath)

    _get_Material_metadata = { "offset" : _get_Material_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Material(self) -> str:
        """Gets or sets the scene contributor material."""
        return self._intf.get_property(IAgStkRfcmSceneContributor._metadata, IAgStkRfcmSceneContributor._get_Material_metadata)

    _set_Material_metadata = { "offset" : _set_Material_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Material.setter
    def Material(self, val:str) -> None:
        """Gets or sets the scene contributor material."""
        return self._intf.set_property(IAgStkRfcmSceneContributor._metadata, IAgStkRfcmSceneContributor._set_Material_metadata, val)

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """Gets the tileset central body name."""
        return self._intf.get_property(IAgStkRfcmSceneContributor._metadata, IAgStkRfcmSceneContributor._get_CentralBodyName_metadata)

    _get_FocusedRayDensity_metadata = { "offset" : _get_FocusedRayDensity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FocusedRayDensity(self) -> float:
        """Gets or sets the target focused ray density."""
        return self._intf.get_property(IAgStkRfcmSceneContributor._metadata, IAgStkRfcmSceneContributor._get_FocusedRayDensity_metadata)

    _set_FocusedRayDensity_metadata = { "offset" : _set_FocusedRayDensity_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @FocusedRayDensity.setter
    def FocusedRayDensity(self, val:float) -> None:
        """Gets or sets the target focused ray density."""
        return self._intf.set_property(IAgStkRfcmSceneContributor._metadata, IAgStkRfcmSceneContributor._set_FocusedRayDensity_metadata, val)

    _property_names[StkObjectPath] = "StkObjectPath"
    _property_names[Material] = "Material"
    _property_names[CentralBodyName] = "CentralBodyName"
    _property_names[FocusedRayDensity] = "FocusedRayDensity"


agcls.AgClassCatalog.add_catalog_entry((5289282663936466784, 6187411627788191675), IAgStkRfcmSceneContributor)
agcls.AgTypeNameMap["IAgStkRfcmSceneContributor"] = IAgStkRfcmSceneContributor

class IAgStkRfcmSceneContributorCollection(object):
    """Represents a collection of scene contributors."""

    _num_methods = 8
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _RemoveAt_method_offset = 4
    _Remove_method_offset = 5
    _AddNew_method_offset = 6
    _RemoveAll_method_offset = 7
    _Contains_method_offset = 8
    _metadata = {
        "iid_data" : (4727679194678330883, 10823296216059869100),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmSceneContributorCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmSceneContributorCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmSceneContributorCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmSceneContributorCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmSceneContributorCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmSceneContributor":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmSceneContributor":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._get__NewEnum_metadata)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Removes the scene contributor with the supplied index."""
        return self._intf.invoke(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._RemoveAt_metadata, index)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def Remove(self, stkObjectPath:str) -> None:
        """Removes the supplied scene contributor from the collection."""
        return self._intf.invoke(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._Remove_metadata, stkObjectPath)

    _AddNew_metadata = { "offset" : _AddNew_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def AddNew(self, stkObjectPath:str) -> "IAgStkRfcmSceneContributor":
        """Adds and returns a new scene contributor."""
        return self._intf.invoke(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._AddNew_metadata, stkObjectPath, OutArg())

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Clears all scene contributors from the collection."""
        return self._intf.invoke(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._RemoveAll_metadata, )

    _Contains_metadata = { "offset" : _Contains_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def Contains(self, stkObjectPath:str) -> bool:
        """Checks to see if a given scene contributor exists in the collection."""
        return self._intf.invoke(IAgStkRfcmSceneContributorCollection._metadata, IAgStkRfcmSceneContributorCollection._Contains_metadata, stkObjectPath, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((4727679194678330883, 10823296216059869100), IAgStkRfcmSceneContributorCollection)
agcls.AgTypeNameMap["IAgStkRfcmSceneContributorCollection"] = IAgStkRfcmSceneContributorCollection

class IAgStkRfcmValidationResponse(object):
    """Properties of the response from validating an analysis configuration."""

    _num_methods = 2
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Value_method_offset = 1
    _get_Message_method_offset = 2
    _metadata = {
        "iid_data" : (4994438691132779782, 1415141693988703135),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmValidationResponse."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmValidationResponse)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmValidationResponse)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmValidationResponse, None)
    
    _get_Value_metadata = { "offset" : _get_Value_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def Value(self) -> bool:
        """Gets the validation indicator."""
        return self._intf.get_property(IAgStkRfcmValidationResponse._metadata, IAgStkRfcmValidationResponse._get_Value_metadata)

    _get_Message_metadata = { "offset" : _get_Message_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Message(self) -> str:
        """Gets the validation message."""
        return self._intf.get_property(IAgStkRfcmValidationResponse._metadata, IAgStkRfcmValidationResponse._get_Message_metadata)

    _property_names[Value] = "Value"
    _property_names[Message] = "Message"


agcls.AgClassCatalog.add_catalog_entry((4994438691132779782, 1415141693988703135), IAgStkRfcmValidationResponse)
agcls.AgTypeNameMap["IAgStkRfcmValidationResponse"] = IAgStkRfcmValidationResponse

class IAgStkRfcmExtent(object):
    """Properties for a cartographic extent definition. One use of this interface is for defining the facet tile set analysis extent."""

    _num_methods = 8
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_NorthLatitude_method_offset = 1
    _set_NorthLatitude_method_offset = 2
    _get_SouthLatitude_method_offset = 3
    _set_SouthLatitude_method_offset = 4
    _get_EastLongitude_method_offset = 5
    _set_EastLongitude_method_offset = 6
    _get_WestLongitude_method_offset = 7
    _set_WestLongitude_method_offset = 8
    _metadata = {
        "iid_data" : (4919157609295249505, 12211194950299458230),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmExtent."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmExtent)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmExtent)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmExtent, None)
    
    _get_NorthLatitude_metadata = { "offset" : _get_NorthLatitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def NorthLatitude(self) -> float:
        """Gets or sets the north latitude."""
        return self._intf.get_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._get_NorthLatitude_metadata)

    _set_NorthLatitude_metadata = { "offset" : _set_NorthLatitude_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @NorthLatitude.setter
    def NorthLatitude(self, val:float) -> None:
        """Gets or sets the north latitude."""
        return self._intf.set_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._set_NorthLatitude_metadata, val)

    _get_SouthLatitude_metadata = { "offset" : _get_SouthLatitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SouthLatitude(self) -> float:
        """Gets or sets the south latitude."""
        return self._intf.get_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._get_SouthLatitude_metadata)

    _set_SouthLatitude_metadata = { "offset" : _set_SouthLatitude_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @SouthLatitude.setter
    def SouthLatitude(self, val:float) -> None:
        """Gets or sets the south latitude."""
        return self._intf.set_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._set_SouthLatitude_metadata, val)

    _get_EastLongitude_metadata = { "offset" : _get_EastLongitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def EastLongitude(self) -> float:
        """Gets or sets the east longitude."""
        return self._intf.get_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._get_EastLongitude_metadata)

    _set_EastLongitude_metadata = { "offset" : _set_EastLongitude_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @EastLongitude.setter
    def EastLongitude(self, val:float) -> None:
        """Gets or sets the east longitude."""
        return self._intf.set_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._set_EastLongitude_metadata, val)

    _get_WestLongitude_metadata = { "offset" : _get_WestLongitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def WestLongitude(self) -> float:
        """Gets or sets the west longitude."""
        return self._intf.get_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._get_WestLongitude_metadata)

    _set_WestLongitude_metadata = { "offset" : _set_WestLongitude_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @WestLongitude.setter
    def WestLongitude(self, val:float) -> None:
        """Gets or sets the west longitude."""
        return self._intf.set_property(IAgStkRfcmExtent._metadata, IAgStkRfcmExtent._set_WestLongitude_metadata, val)

    _property_names[NorthLatitude] = "NorthLatitude"
    _property_names[SouthLatitude] = "SouthLatitude"
    _property_names[EastLongitude] = "EastLongitude"
    _property_names[WestLongitude] = "WestLongitude"


agcls.AgClassCatalog.add_catalog_entry((4919157609295249505, 12211194950299458230), IAgStkRfcmExtent)
agcls.AgTypeNameMap["IAgStkRfcmExtent"] = IAgStkRfcmExtent

class IAgStkRfcmMaterial(object):
    """Properties for a material."""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Type_method_offset = 1
    _set_Type_method_offset = 2
    _get_Properties_method_offset = 3
    _set_Properties_method_offset = 4
    _metadata = {
        "iid_data" : (5106970972732140092, 12345568409569237644),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmMaterial."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmMaterial)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmMaterial)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmMaterial, None)
    
    _get_Type_metadata = { "offset" : _get_Type_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Type(self) -> str:
        """Gets material type."""
        return self._intf.get_property(IAgStkRfcmMaterial._metadata, IAgStkRfcmMaterial._get_Type_metadata)

    _set_Type_metadata = { "offset" : _set_Type_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Type.setter
    def Type(self, val:str) -> None:
        """Sets material type."""
        return self._intf.set_property(IAgStkRfcmMaterial._metadata, IAgStkRfcmMaterial._set_Type_metadata, val)

    _get_Properties_metadata = { "offset" : _get_Properties_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Properties(self) -> str:
        """Gets material properties."""
        return self._intf.get_property(IAgStkRfcmMaterial._metadata, IAgStkRfcmMaterial._get_Properties_metadata)

    _set_Properties_metadata = { "offset" : _set_Properties_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Properties.setter
    def Properties(self, val:str) -> None:
        """Sets material properties."""
        return self._intf.set_property(IAgStkRfcmMaterial._metadata, IAgStkRfcmMaterial._set_Properties_metadata, val)

    _property_names[Type] = "Type"
    _property_names[Properties] = "Properties"


agcls.AgClassCatalog.add_catalog_entry((5106970972732140092, 12345568409569237644), IAgStkRfcmMaterial)
agcls.AgTypeNameMap["IAgStkRfcmMaterial"] = IAgStkRfcmMaterial

class IAgStkRfcmFacetTileset(object):
    """Properties of a facet tile set."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Name_method_offset = 1
    _get_Uri_method_offset = 2
    _get_Material_method_offset = 3
    _set_Material_method_offset = 4
    _get_ReferenceFrame_method_offset = 5
    _get_CentralBodyName_method_offset = 6
    _metadata = {
        "iid_data" : (4789527447108154914, 637873324861092488),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmFacetTileset."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmFacetTileset)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmFacetTileset)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmFacetTileset, None)
    
    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Gets the facet tileset name."""
        return self._intf.get_property(IAgStkRfcmFacetTileset._metadata, IAgStkRfcmFacetTileset._get_Name_metadata)

    _get_Uri_metadata = { "offset" : _get_Uri_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Uri(self) -> str:
        """Gets the facet tileset uri."""
        return self._intf.get_property(IAgStkRfcmFacetTileset._metadata, IAgStkRfcmFacetTileset._get_Uri_metadata)

    _get_Material_metadata = { "offset" : _get_Material_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Material(self) -> str:
        """Gets or sets the tileset material."""
        return self._intf.get_property(IAgStkRfcmFacetTileset._metadata, IAgStkRfcmFacetTileset._get_Material_metadata)

    _set_Material_metadata = { "offset" : _set_Material_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Material.setter
    def Material(self, val:str) -> None:
        """Gets or sets the tileset material."""
        return self._intf.set_property(IAgStkRfcmFacetTileset._metadata, IAgStkRfcmFacetTileset._set_Material_metadata, val)

    _get_ReferenceFrame_metadata = { "offset" : _get_ReferenceFrame_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ReferenceFrame(self) -> str:
        """Gets the tileset reference frame."""
        return self._intf.get_property(IAgStkRfcmFacetTileset._metadata, IAgStkRfcmFacetTileset._get_ReferenceFrame_metadata)

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """Gets the tileset central body name."""
        return self._intf.get_property(IAgStkRfcmFacetTileset._metadata, IAgStkRfcmFacetTileset._get_CentralBodyName_metadata)

    _property_names[Name] = "Name"
    _property_names[Uri] = "Uri"
    _property_names[Material] = "Material"
    _property_names[ReferenceFrame] = "ReferenceFrame"
    _property_names[CentralBodyName] = "CentralBodyName"


agcls.AgClassCatalog.add_catalog_entry((4789527447108154914, 637873324861092488), IAgStkRfcmFacetTileset)
agcls.AgTypeNameMap["IAgStkRfcmFacetTileset"] = IAgStkRfcmFacetTileset

class IAgStkRfcmFacetTilesetCollection(object):
    """Represents a collection of facet tile sets."""

    _num_methods = 7
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Remove_method_offset = 4
    _RemoveAt_method_offset = 5
    _RemoveAll_method_offset = 6
    _Add_method_offset = 7
    _metadata = {
        "iid_data" : (5753655749563624094, 7998985330621454980),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmFacetTilesetCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmFacetTilesetCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmFacetTilesetCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmFacetTilesetCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmFacetTilesetCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmFacetTileset":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmFacetTilesetCollection._metadata, IAgStkRfcmFacetTilesetCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmFacetTileset":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmFacetTilesetCollection._metadata, IAgStkRfcmFacetTilesetCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmFacetTilesetCollection._metadata, IAgStkRfcmFacetTilesetCollection._get__NewEnum_metadata)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmFacetTileset"),) }
    def Remove(self, pVal:"IAgStkRfcmFacetTileset") -> None:
        """Removes the supplied facet tileset from the collection."""
        return self._intf.invoke(IAgStkRfcmFacetTilesetCollection._metadata, IAgStkRfcmFacetTilesetCollection._Remove_metadata, pVal)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Removes the facet tileset with the supplied index."""
        return self._intf.invoke(IAgStkRfcmFacetTilesetCollection._metadata, IAgStkRfcmFacetTilesetCollection._RemoveAt_metadata, index)

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Clears all facet tilesets from the collection."""
        return self._intf.invoke(IAgStkRfcmFacetTilesetCollection._metadata, IAgStkRfcmFacetTilesetCollection._RemoveAll_metadata, )

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmFacetTileset"),) }
    def Add(self, pVal:"IAgStkRfcmFacetTileset") -> None:
        """Adds a facet tile set to the collection."""
        return self._intf.invoke(IAgStkRfcmFacetTilesetCollection._metadata, IAgStkRfcmFacetTilesetCollection._Add_metadata, pVal)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5753655749563624094, 7998985330621454980), IAgStkRfcmFacetTilesetCollection)
agcls.AgTypeNameMap["IAgStkRfcmFacetTilesetCollection"] = IAgStkRfcmFacetTilesetCollection

class IAgStkRfcmRadarSarImageLocation(object):
    """Properties for an image location used by a range doppler Sar analysis."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Name_method_offset = 1
    _set_Name_method_offset = 2
    _get_Latitude_method_offset = 3
    _set_Latitude_method_offset = 4
    _get_Longitude_method_offset = 5
    _set_Longitude_method_offset = 6
    _metadata = {
        "iid_data" : (4928415407610984061, 7191108097270096522),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarSarImageLocation."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarSarImageLocation)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarSarImageLocation)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarSarImageLocation, None)
    
    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Gets or sets the image location name."""
        return self._intf.get_property(IAgStkRfcmRadarSarImageLocation._metadata, IAgStkRfcmRadarSarImageLocation._get_Name_metadata)

    _set_Name_metadata = { "offset" : _set_Name_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Name.setter
    def Name(self, val:str) -> None:
        """Gets or sets the image location name."""
        return self._intf.set_property(IAgStkRfcmRadarSarImageLocation._metadata, IAgStkRfcmRadarSarImageLocation._set_Name_metadata, val)

    _get_Latitude_metadata = { "offset" : _get_Latitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Latitude(self) -> float:
        """Gets or sets the location latitude."""
        return self._intf.get_property(IAgStkRfcmRadarSarImageLocation._metadata, IAgStkRfcmRadarSarImageLocation._get_Latitude_metadata)

    _set_Latitude_metadata = { "offset" : _set_Latitude_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Latitude.setter
    def Latitude(self, val:float) -> None:
        """Gets or sets the location latitude."""
        return self._intf.set_property(IAgStkRfcmRadarSarImageLocation._metadata, IAgStkRfcmRadarSarImageLocation._set_Latitude_metadata, val)

    _get_Longitude_metadata = { "offset" : _get_Longitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Longitude(self) -> float:
        """Gets or sets the location longitude."""
        return self._intf.get_property(IAgStkRfcmRadarSarImageLocation._metadata, IAgStkRfcmRadarSarImageLocation._get_Longitude_metadata)

    _set_Longitude_metadata = { "offset" : _set_Longitude_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Longitude.setter
    def Longitude(self, val:float) -> None:
        """Gets or sets the location longitude."""
        return self._intf.set_property(IAgStkRfcmRadarSarImageLocation._metadata, IAgStkRfcmRadarSarImageLocation._set_Longitude_metadata, val)

    _property_names[Name] = "Name"
    _property_names[Latitude] = "Latitude"
    _property_names[Longitude] = "Longitude"


agcls.AgClassCatalog.add_catalog_entry((4928415407610984061, 7191108097270096522), IAgStkRfcmRadarSarImageLocation)
agcls.AgTypeNameMap["IAgStkRfcmRadarSarImageLocation"] = IAgStkRfcmRadarSarImageLocation

class IAgStkRfcmRadarSarImageLocationCollection(object):
    """Represents a collection of Sar image locations."""

    _num_methods = 9
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _RemoveAt_method_offset = 4
    _Remove_method_offset = 5
    _AddNew_method_offset = 6
    _RemoveAll_method_offset = 7
    _Contains_method_offset = 8
    _Find_method_offset = 9
    _metadata = {
        "iid_data" : (5715838980280879821, 3014522816578550712),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarSarImageLocationCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarSarImageLocationCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarSarImageLocationCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarSarImageLocationCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmRadarSarImageLocationCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmRadarSarImageLocation":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmRadarSarImageLocation":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._get__NewEnum_metadata)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Remove the SAR image location with the supplied index."""
        return self._intf.invoke(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._RemoveAt_metadata, index)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def Remove(self, nameStr:str) -> None:
        """Removes the supplied SAR image location from the collection."""
        return self._intf.invoke(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._Remove_metadata, nameStr)

    _AddNew_metadata = { "offset" : _AddNew_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def AddNew(self) -> "IAgStkRfcmRadarSarImageLocation":
        """Adds and returns a new SAR image location."""
        return self._intf.invoke(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._AddNew_metadata, OutArg())

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Clears all SAR image locations from the collection."""
        return self._intf.invoke(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._RemoveAll_metadata, )

    _Contains_metadata = { "offset" : _Contains_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def Contains(self, nameStr:str) -> bool:
        """Checks to see if a given SAR image location exists in the collection."""
        return self._intf.invoke(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._Contains_metadata, nameStr, OutArg())

    _Find_metadata = { "offset" : _Find_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def Find(self, nameStr:str) -> "IAgStkRfcmRadarSarImageLocation":
        """Finds a SAR image location by name. Returns Null if the image location name does not exist in the collection."""
        return self._intf.invoke(IAgStkRfcmRadarSarImageLocationCollection._metadata, IAgStkRfcmRadarSarImageLocationCollection._Find_metadata, nameStr, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5715838980280879821, 3014522816578550712), IAgStkRfcmRadarSarImageLocationCollection)
agcls.AgTypeNameMap["IAgStkRfcmRadarSarImageLocationCollection"] = IAgStkRfcmRadarSarImageLocationCollection

class IAgStkRfcmRangeDopplerResponse(object):
    """The properties for a range doppler channel characterization response."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_RangeValues_method_offset = 1
    _get_RangeCount_method_offset = 2
    _get_VelocityValues_method_offset = 3
    _get_VelocityCount_method_offset = 4
    _get_PulseCount_method_offset = 5
    _get_AngularVelocity_method_offset = 6
    _metadata = {
        "iid_data" : (4709129566781506392, 18419786988973210803),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRangeDopplerResponse."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRangeDopplerResponse)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRangeDopplerResponse)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRangeDopplerResponse, None)
    
    _get_RangeValues_metadata = { "offset" : _get_RangeValues_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def RangeValues(self) -> list:
        """Gets the range values."""
        return self._intf.get_property(IAgStkRfcmRangeDopplerResponse._metadata, IAgStkRfcmRangeDopplerResponse._get_RangeValues_metadata)

    _get_RangeCount_metadata = { "offset" : _get_RangeCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def RangeCount(self) -> int:
        """Gets the range count."""
        return self._intf.get_property(IAgStkRfcmRangeDopplerResponse._metadata, IAgStkRfcmRangeDopplerResponse._get_RangeCount_metadata)

    _get_VelocityValues_metadata = { "offset" : _get_VelocityValues_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def VelocityValues(self) -> list:
        """Gets the velocity values."""
        return self._intf.get_property(IAgStkRfcmRangeDopplerResponse._metadata, IAgStkRfcmRangeDopplerResponse._get_VelocityValues_metadata)

    _get_VelocityCount_metadata = { "offset" : _get_VelocityCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def VelocityCount(self) -> int:
        """Gets the velocity count."""
        return self._intf.get_property(IAgStkRfcmRangeDopplerResponse._metadata, IAgStkRfcmRangeDopplerResponse._get_VelocityCount_metadata)

    _get_PulseCount_metadata = { "offset" : _get_PulseCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def PulseCount(self) -> int:
        """Gets the pulse count."""
        return self._intf.get_property(IAgStkRfcmRangeDopplerResponse._metadata, IAgStkRfcmRangeDopplerResponse._get_PulseCount_metadata)

    _get_AngularVelocity_metadata = { "offset" : _get_AngularVelocity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AngularVelocity(self) -> float:
        """Gets the angular velocity."""
        return self._intf.get_property(IAgStkRfcmRangeDopplerResponse._metadata, IAgStkRfcmRangeDopplerResponse._get_AngularVelocity_metadata)

    _property_names[RangeValues] = "RangeValues"
    _property_names[RangeCount] = "RangeCount"
    _property_names[VelocityValues] = "VelocityValues"
    _property_names[VelocityCount] = "VelocityCount"
    _property_names[PulseCount] = "PulseCount"
    _property_names[AngularVelocity] = "AngularVelocity"


agcls.AgClassCatalog.add_catalog_entry((4709129566781506392, 18419786988973210803), IAgStkRfcmRangeDopplerResponse)
agcls.AgTypeNameMap["IAgStkRfcmRangeDopplerResponse"] = IAgStkRfcmRangeDopplerResponse

class IAgStkRfcmFrequencyPulseResponse(object):
    """The properties for a frequency pulse channel characterization response."""

    _num_methods = 2
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_PulseCount_method_offset = 1
    _get_FrequencySampleCount_method_offset = 2
    _metadata = {
        "iid_data" : (5226211774985697343, 303850293307315840),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmFrequencyPulseResponse."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmFrequencyPulseResponse)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmFrequencyPulseResponse)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmFrequencyPulseResponse, None)
    
    _get_PulseCount_metadata = { "offset" : _get_PulseCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def PulseCount(self) -> int:
        """Gets the pulse count."""
        return self._intf.get_property(IAgStkRfcmFrequencyPulseResponse._metadata, IAgStkRfcmFrequencyPulseResponse._get_PulseCount_metadata)

    _get_FrequencySampleCount_metadata = { "offset" : _get_FrequencySampleCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def FrequencySampleCount(self) -> int:
        """Gets the frequency sample count."""
        return self._intf.get_property(IAgStkRfcmFrequencyPulseResponse._metadata, IAgStkRfcmFrequencyPulseResponse._get_FrequencySampleCount_metadata)

    _property_names[PulseCount] = "PulseCount"
    _property_names[FrequencySampleCount] = "FrequencySampleCount"


agcls.AgClassCatalog.add_catalog_entry((5226211774985697343, 303850293307315840), IAgStkRfcmFrequencyPulseResponse)
agcls.AgTypeNameMap["IAgStkRfcmFrequencyPulseResponse"] = IAgStkRfcmFrequencyPulseResponse

class IAgStkRfcmResponse(object):
    """Properties and data for a channel characaterization response."""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Type_method_offset = 1
    _get_Data_method_offset = 2
    _get_TransmitAntennaCount_method_offset = 3
    _get_ReceiveAntennaCount_method_offset = 4
    _metadata = {
        "iid_data" : (5273345876967495470, 8911670956953360542),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmResponse."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmResponse)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmResponse)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmResponse, None)
    
    _get_Type_metadata = { "offset" : _get_Type_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmChannelResponseType),) }
    @property
    def Type(self) -> "AgERfcmChannelResponseType":
        """Gets the response type."""
        return self._intf.get_property(IAgStkRfcmResponse._metadata, IAgStkRfcmResponse._get_Type_metadata)

    _get_Data_metadata = { "offset" : _get_Data_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def Data(self) -> list:
        """Gets the response data."""
        return self._intf.get_property(IAgStkRfcmResponse._metadata, IAgStkRfcmResponse._get_Data_metadata)

    _get_TransmitAntennaCount_metadata = { "offset" : _get_TransmitAntennaCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def TransmitAntennaCount(self) -> int:
        """Gets the transmit antenna count."""
        return self._intf.get_property(IAgStkRfcmResponse._metadata, IAgStkRfcmResponse._get_TransmitAntennaCount_metadata)

    _get_ReceiveAntennaCount_metadata = { "offset" : _get_ReceiveAntennaCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def ReceiveAntennaCount(self) -> int:
        """Gets the receive antenna count."""
        return self._intf.get_property(IAgStkRfcmResponse._metadata, IAgStkRfcmResponse._get_ReceiveAntennaCount_metadata)

    _property_names[Type] = "Type"
    _property_names[Data] = "Data"
    _property_names[TransmitAntennaCount] = "TransmitAntennaCount"
    _property_names[ReceiveAntennaCount] = "ReceiveAntennaCount"


agcls.AgClassCatalog.add_catalog_entry((5273345876967495470, 8911670956953360542), IAgStkRfcmResponse)
agcls.AgTypeNameMap["IAgStkRfcmResponse"] = IAgStkRfcmResponse

class IAgStkRfcmAnalysisLink(object):
    """Properties for a transceiver link for an analysis."""

    _num_methods = 9
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Name_method_offset = 1
    _get_TransmitTransceiverIdentifier_method_offset = 2
    _get_TransmitTransceiverName_method_offset = 3
    _get_ReceiveTransceiverIdentifier_method_offset = 4
    _get_ReceiveTransceiverName_method_offset = 5
    _get_TransmitAntennaCount_method_offset = 6
    _get_ReceiveAntennaCount_method_offset = 7
    _get_AnalysisIntervals_method_offset = 8
    _Compute_method_offset = 9
    _metadata = {
        "iid_data" : (5200039314651946484, 7207498084283752120),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmAnalysisLink."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmAnalysisLink)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmAnalysisLink)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmAnalysisLink, None)
    
    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Gets the analysis link name."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_Name_metadata)

    _get_TransmitTransceiverIdentifier_metadata = { "offset" : _get_TransmitTransceiverIdentifier_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def TransmitTransceiverIdentifier(self) -> str:
        """Gets the transmit transceiver identifier."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_TransmitTransceiverIdentifier_metadata)

    _get_TransmitTransceiverName_metadata = { "offset" : _get_TransmitTransceiverName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def TransmitTransceiverName(self) -> str:
        """Gets the transmit transceiver name."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_TransmitTransceiverName_metadata)

    _get_ReceiveTransceiverIdentifier_metadata = { "offset" : _get_ReceiveTransceiverIdentifier_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ReceiveTransceiverIdentifier(self) -> str:
        """Gets the receive transceiver identifier."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_ReceiveTransceiverIdentifier_metadata)

    _get_ReceiveTransceiverName_metadata = { "offset" : _get_ReceiveTransceiverName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ReceiveTransceiverName(self) -> str:
        """Gets the receive transceiver name."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_ReceiveTransceiverName_metadata)

    _get_TransmitAntennaCount_metadata = { "offset" : _get_TransmitAntennaCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def TransmitAntennaCount(self) -> int:
        """Gets the transmit antenna count."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_TransmitAntennaCount_metadata)

    _get_ReceiveAntennaCount_metadata = { "offset" : _get_ReceiveAntennaCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def ReceiveAntennaCount(self) -> int:
        """Gets the receive antenna count."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_ReceiveAntennaCount_metadata)

    _get_AnalysisIntervals_metadata = { "offset" : _get_AnalysisIntervals_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def AnalysisIntervals(self) -> list:
        """Gets the analysis intervals array."""
        return self._intf.get_property(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._get_AnalysisIntervals_metadata)

    _Compute_metadata = { "offset" : _Compute_method_offset,
            "arg_types" : (agcom.DOUBLE, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.AgInterface_out_arg,) }
    def Compute(self, time:float) -> "IAgStkRfcmResponse":
        """Computes the analysis link at the given time."""
        return self._intf.invoke(IAgStkRfcmAnalysisLink._metadata, IAgStkRfcmAnalysisLink._Compute_metadata, time, OutArg())

    _property_names[Name] = "Name"
    _property_names[TransmitTransceiverIdentifier] = "TransmitTransceiverIdentifier"
    _property_names[TransmitTransceiverName] = "TransmitTransceiverName"
    _property_names[ReceiveTransceiverIdentifier] = "ReceiveTransceiverIdentifier"
    _property_names[ReceiveTransceiverName] = "ReceiveTransceiverName"
    _property_names[TransmitAntennaCount] = "TransmitAntennaCount"
    _property_names[ReceiveAntennaCount] = "ReceiveAntennaCount"
    _property_names[AnalysisIntervals] = "AnalysisIntervals"


agcls.AgClassCatalog.add_catalog_entry((5200039314651946484, 7207498084283752120), IAgStkRfcmAnalysisLink)
agcls.AgTypeNameMap["IAgStkRfcmAnalysisLink"] = IAgStkRfcmAnalysisLink

class IAgStkRfcmRadarSarAnalysisLink(object):
    """Properties for a transceiver link for a Sar analysis."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ImageLocationName_method_offset = 1
    _metadata = {
        "iid_data" : (5684254587119606851, 6835131856690226323),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarSarAnalysisLink."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarSarAnalysisLink)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarSarAnalysisLink)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarSarAnalysisLink, None)
    
    _get_ImageLocationName_metadata = { "offset" : _get_ImageLocationName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ImageLocationName(self) -> str:
        """Gets the analysis link image location name."""
        return self._intf.get_property(IAgStkRfcmRadarSarAnalysisLink._metadata, IAgStkRfcmRadarSarAnalysisLink._get_ImageLocationName_metadata)

    _property_names[ImageLocationName] = "ImageLocationName"


agcls.AgClassCatalog.add_catalog_entry((5684254587119606851, 6835131856690226323), IAgStkRfcmRadarSarAnalysisLink)
agcls.AgTypeNameMap["IAgStkRfcmRadarSarAnalysisLink"] = IAgStkRfcmRadarSarAnalysisLink

class IAgStkRfcmRadarISarAnalysisLink(object):
    """Properties for a transceiver link for an ISar analysis."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_TargetObjectPath_method_offset = 1
    _metadata = {
        "iid_data" : (4668749688519013855, 7019281282042502068),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarISarAnalysisLink."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarISarAnalysisLink)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarISarAnalysisLink)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarISarAnalysisLink, None)
    
    _get_TargetObjectPath_metadata = { "offset" : _get_TargetObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def TargetObjectPath(self) -> str:
        """Gets the analysis link target object path."""
        return self._intf.get_property(IAgStkRfcmRadarISarAnalysisLink._metadata, IAgStkRfcmRadarISarAnalysisLink._get_TargetObjectPath_metadata)

    _property_names[TargetObjectPath] = "TargetObjectPath"


agcls.AgClassCatalog.add_catalog_entry((4668749688519013855, 7019281282042502068), IAgStkRfcmRadarISarAnalysisLink)
agcls.AgTypeNameMap["IAgStkRfcmRadarISarAnalysisLink"] = IAgStkRfcmRadarISarAnalysisLink

class IAgStkRfcmAnalysisLinkCollection(object):
    """Represents a collection of analysis links between transceivers objects."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _metadata = {
        "iid_data" : (5753809382164761882, 12578733845637557142),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmAnalysisLinkCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmAnalysisLinkCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmAnalysisLinkCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmAnalysisLinkCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmAnalysisLinkCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmAnalysisLink":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmAnalysisLinkCollection._metadata, IAgStkRfcmAnalysisLinkCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmAnalysisLink":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmAnalysisLinkCollection._metadata, IAgStkRfcmAnalysisLinkCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmAnalysisLinkCollection._metadata, IAgStkRfcmAnalysisLinkCollection._get__NewEnum_metadata)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5753809382164761882, 12578733845637557142), IAgStkRfcmAnalysisLinkCollection)
agcls.AgTypeNameMap["IAgStkRfcmAnalysisLinkCollection"] = IAgStkRfcmAnalysisLinkCollection

class IAgStkRfcmAnalysis(object):
    """Properties of an analysis."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_AnalysisLinkCollection_method_offset = 1
    _metadata = {
        "iid_data" : (5641135177332540089, 160659604875743665),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmAnalysis."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmAnalysis)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmAnalysis)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmAnalysis, None)
    
    _get_AnalysisLinkCollection_metadata = { "offset" : _get_AnalysisLinkCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def AnalysisLinkCollection(self) -> "IAgStkRfcmAnalysisLinkCollection":
        """Gets the analysis link collection."""
        return self._intf.get_property(IAgStkRfcmAnalysis._metadata, IAgStkRfcmAnalysis._get_AnalysisLinkCollection_metadata)

    _property_names[AnalysisLinkCollection] = "AnalysisLinkCollection"


agcls.AgClassCatalog.add_catalog_entry((5641135177332540089, 160659604875743665), IAgStkRfcmAnalysis)
agcls.AgTypeNameMap["IAgStkRfcmAnalysis"] = IAgStkRfcmAnalysis

class IAgStkRfcmAnalysisConfigurationModel(object):
    """Base interface for all analysis configuration models."""

    _num_methods = 24
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Type_method_offset = 1
    _get_SceneContributorCollection_method_offset = 2
    _get_LinkCount_method_offset = 3
    _get_ValidateConfiguration_method_offset = 4
    _get_ValidatePlatformFacets_method_offset = 5
    _get_IntervalStart_method_offset = 6
    _set_IntervalStart_method_offset = 7
    _get_IntervalStop_method_offset = 8
    _set_IntervalStop_method_offset = 9
    _get_ComputeStepMode_method_offset = 10
    _set_ComputeStepMode_method_offset = 11
    _get_FixedStepCount_method_offset = 12
    _set_FixedStepCount_method_offset = 13
    _get_FixedStepSize_method_offset = 14
    _set_FixedStepSize_method_offset = 15
    _get_ResultsFileMode_method_offset = 16
    _set_ResultsFileMode_method_offset = 17
    _get_UseScenarioAnalysisInterval_method_offset = 18
    _set_UseScenarioAnalysisInterval_method_offset = 19
    _get_HideIncompatibleTilesets_method_offset = 20
    _set_HideIncompatibleTilesets_method_offset = 21
    _get_SupportedFacetTilesets_method_offset = 22
    _get_FacetTilesetCollection_method_offset = 23
    _get_AnalysisExtent_method_offset = 24
    _metadata = {
        "iid_data" : (5297348179628469644, 14335374035294896569),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmAnalysisConfigurationModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmAnalysisConfigurationModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmAnalysisConfigurationModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmAnalysisConfigurationModel, None)
    
    _get_Type_metadata = { "offset" : _get_Type_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisConfigurationModelType),) }
    @property
    def Type(self) -> "AgERfcmAnalysisConfigurationModelType":
        """Gets the analysis configuration model type."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_Type_metadata)

    _get_SceneContributorCollection_metadata = { "offset" : _get_SceneContributorCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def SceneContributorCollection(self) -> "IAgStkRfcmSceneContributorCollection":
        """Gets the collection of scene contributors."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_SceneContributorCollection_metadata)

    _get_LinkCount_metadata = { "offset" : _get_LinkCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def LinkCount(self) -> int:
        """Gets the link count."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_LinkCount_metadata)

    _get_ValidateConfiguration_metadata = { "offset" : _get_ValidateConfiguration_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ValidateConfiguration(self) -> "IAgStkRfcmValidationResponse":
        """Validates whether or not the configuration is ready to run."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_ValidateConfiguration_metadata)

    _get_ValidatePlatformFacets_metadata = { "offset" : _get_ValidatePlatformFacets_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ValidatePlatformFacets(self) -> "IAgStkRfcmValidationResponse":
        """Validates the configuration platforms which provide facets are configured properly."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_ValidatePlatformFacets_metadata)

    _get_IntervalStart_metadata = { "offset" : _get_IntervalStart_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def IntervalStart(self) -> float:
        """Gets or sets the interval start time."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_IntervalStart_metadata)

    _set_IntervalStart_metadata = { "offset" : _set_IntervalStart_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @IntervalStart.setter
    def IntervalStart(self, intervalStart:float) -> None:
        """Gets or sets the interval start time."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_IntervalStart_metadata, intervalStart)

    _get_IntervalStop_metadata = { "offset" : _get_IntervalStop_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def IntervalStop(self) -> float:
        """Gets or sets the interval stop time."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_IntervalStop_metadata)

    _set_IntervalStop_metadata = { "offset" : _set_IntervalStop_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @IntervalStop.setter
    def IntervalStop(self, intervalStop:float) -> None:
        """Gets or sets the interval stop time."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_IntervalStop_metadata, intervalStop)

    _get_ComputeStepMode_metadata = { "offset" : _get_ComputeStepMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisConfigurationComputeStepMode),) }
    @property
    def ComputeStepMode(self) -> "AgERfcmAnalysisConfigurationComputeStepMode":
        """Gets or sets the compute step mode."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_ComputeStepMode_metadata)

    _set_ComputeStepMode_metadata = { "offset" : _set_ComputeStepMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisConfigurationComputeStepMode),) }
    @ComputeStepMode.setter
    def ComputeStepMode(self, computeStepMode:"AgERfcmAnalysisConfigurationComputeStepMode") -> None:
        """Gets or sets the compute step mode."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_ComputeStepMode_metadata, computeStepMode)

    _get_FixedStepCount_metadata = { "offset" : _get_FixedStepCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def FixedStepCount(self) -> int:
        """Gets or sets the step count."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_FixedStepCount_metadata)

    _set_FixedStepCount_metadata = { "offset" : _set_FixedStepCount_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @FixedStepCount.setter
    def FixedStepCount(self, stepCount:int) -> None:
        """Gets or sets the step count."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_FixedStepCount_metadata, stepCount)

    _get_FixedStepSize_metadata = { "offset" : _get_FixedStepSize_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FixedStepSize(self) -> float:
        """Gets or sets the step size."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_FixedStepSize_metadata)

    _set_FixedStepSize_metadata = { "offset" : _set_FixedStepSize_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @FixedStepSize.setter
    def FixedStepSize(self, stepSize:float) -> None:
        """Gets or sets the step size."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_FixedStepSize_metadata, stepSize)

    _get_ResultsFileMode_metadata = { "offset" : _get_ResultsFileMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisResultsFileMode),) }
    @property
    def ResultsFileMode(self) -> "AgERfcmAnalysisResultsFileMode":
        """Gets or sets the results file mode."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_ResultsFileMode_metadata)

    _set_ResultsFileMode_metadata = { "offset" : _set_ResultsFileMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisResultsFileMode),) }
    @ResultsFileMode.setter
    def ResultsFileMode(self, val:"AgERfcmAnalysisResultsFileMode") -> None:
        """Gets or sets the results file mode."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_ResultsFileMode_metadata, val)

    _get_UseScenarioAnalysisInterval_metadata = { "offset" : _get_UseScenarioAnalysisInterval_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UseScenarioAnalysisInterval(self) -> bool:
        """Gets or sets whether or not to use the scenario analysis interval."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_UseScenarioAnalysisInterval_metadata)

    _set_UseScenarioAnalysisInterval_metadata = { "offset" : _set_UseScenarioAnalysisInterval_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UseScenarioAnalysisInterval.setter
    def UseScenarioAnalysisInterval(self, val:bool) -> None:
        """Gets or sets whether or not to use the scenario analysis interval."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_UseScenarioAnalysisInterval_metadata, val)

    _get_HideIncompatibleTilesets_metadata = { "offset" : _get_HideIncompatibleTilesets_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def HideIncompatibleTilesets(self) -> bool:
        """Gets or sets the show all tilesets indicator."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_HideIncompatibleTilesets_metadata)

    _set_HideIncompatibleTilesets_metadata = { "offset" : _set_HideIncompatibleTilesets_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @HideIncompatibleTilesets.setter
    def HideIncompatibleTilesets(self, val:bool) -> None:
        """Gets or sets the show all tilesets indicator."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._set_HideIncompatibleTilesets_metadata, val)

    _get_SupportedFacetTilesets_metadata = { "offset" : _get_SupportedFacetTilesets_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SupportedFacetTilesets(self) -> list:
        """Gets an array of available facet tilesets."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_SupportedFacetTilesets_metadata)

    _get_FacetTilesetCollection_metadata = { "offset" : _get_FacetTilesetCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def FacetTilesetCollection(self) -> "IAgStkRfcmFacetTilesetCollection":
        """Gets the collection of facet tilesets."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_FacetTilesetCollection_metadata)

    _get_AnalysisExtent_metadata = { "offset" : _get_AnalysisExtent_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def AnalysisExtent(self) -> "IAgStkRfcmExtent":
        """Gets the facet tileset extent."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationModel._metadata, IAgStkRfcmAnalysisConfigurationModel._get_AnalysisExtent_metadata)

    _property_names[Type] = "Type"
    _property_names[SceneContributorCollection] = "SceneContributorCollection"
    _property_names[LinkCount] = "LinkCount"
    _property_names[ValidateConfiguration] = "ValidateConfiguration"
    _property_names[ValidatePlatformFacets] = "ValidatePlatformFacets"
    _property_names[IntervalStart] = "IntervalStart"
    _property_names[IntervalStop] = "IntervalStop"
    _property_names[ComputeStepMode] = "ComputeStepMode"
    _property_names[FixedStepCount] = "FixedStepCount"
    _property_names[FixedStepSize] = "FixedStepSize"
    _property_names[ResultsFileMode] = "ResultsFileMode"
    _property_names[UseScenarioAnalysisInterval] = "UseScenarioAnalysisInterval"
    _property_names[HideIncompatibleTilesets] = "HideIncompatibleTilesets"
    _property_names[SupportedFacetTilesets] = "SupportedFacetTilesets"
    _property_names[FacetTilesetCollection] = "FacetTilesetCollection"
    _property_names[AnalysisExtent] = "AnalysisExtent"


agcls.AgClassCatalog.add_catalog_entry((5297348179628469644, 14335374035294896569), IAgStkRfcmAnalysisConfigurationModel)
agcls.AgTypeNameMap["IAgStkRfcmAnalysisConfigurationModel"] = IAgStkRfcmAnalysisConfigurationModel

class IAgStkRfcmCommunicationsAnalysisConfigurationModel(object):
    """Properties for an analysis configuration model for a communications analysis. This contains a collection of the transceiver configurations belonging to the communications analysis."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_TransceiverConfigurationCollection_method_offset = 1
    _metadata = {
        "iid_data" : (4842510040248443164, 4420140607317663404),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmCommunicationsAnalysisConfigurationModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmCommunicationsAnalysisConfigurationModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmCommunicationsAnalysisConfigurationModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmCommunicationsAnalysisConfigurationModel, None)
    
    _get_TransceiverConfigurationCollection_metadata = { "offset" : _get_TransceiverConfigurationCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def TransceiverConfigurationCollection(self) -> "IAgStkRfcmCommunicationsTransceiverConfigurationCollection":
        """Gets the collection of transceiver configurations."""
        return self._intf.get_property(IAgStkRfcmCommunicationsAnalysisConfigurationModel._metadata, IAgStkRfcmCommunicationsAnalysisConfigurationModel._get_TransceiverConfigurationCollection_metadata)

    _property_names[TransceiverConfigurationCollection] = "TransceiverConfigurationCollection"


agcls.AgClassCatalog.add_catalog_entry((4842510040248443164, 4420140607317663404), IAgStkRfcmCommunicationsAnalysisConfigurationModel)
agcls.AgTypeNameMap["IAgStkRfcmCommunicationsAnalysisConfigurationModel"] = IAgStkRfcmCommunicationsAnalysisConfigurationModel

class IAgStkRfcmRadarImagingDataProduct(object):
    """Properties for the imaging data product."""

    _num_methods = 36
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Name_method_offset = 1
    _get_EnableSensorFixedDistance_method_offset = 2
    _set_EnableSensorFixedDistance_method_offset = 3
    _get_DesiredSensorFixedDistance_method_offset = 4
    _set_DesiredSensorFixedDistance_method_offset = 5
    _get_DistanceToRangeWindowStart_method_offset = 6
    _get_DistanceToRangeWindowCenter_method_offset = 7
    _get_CenterImageInRangeWindow_method_offset = 8
    _set_CenterImageInRangeWindow_method_offset = 9
    _get_EnableRangeDopplerImaging_method_offset = 10
    _set_EnableRangeDopplerImaging_method_offset = 11
    _get_RangePixelCount_method_offset = 12
    _set_RangePixelCount_method_offset = 13
    _get_VelocityPixelCount_method_offset = 14
    _set_VelocityPixelCount_method_offset = 15
    _get_RangeWindowType_method_offset = 16
    _set_RangeWindowType_method_offset = 17
    _get_RangeWindowSideLobeLevel_method_offset = 18
    _set_RangeWindowSideLobeLevel_method_offset = 19
    _get_VelocityWindowType_method_offset = 20
    _set_VelocityWindowType_method_offset = 21
    _get_VelocityWindowSideLobeLevel_method_offset = 22
    _set_VelocityWindowSideLobeLevel_method_offset = 23
    _get_RangeResolution_method_offset = 24
    _set_RangeResolution_method_offset = 25
    _get_RangeWindowSize_method_offset = 26
    _set_RangeWindowSize_method_offset = 27
    _get_CrossRangeResolution_method_offset = 28
    _set_CrossRangeResolution_method_offset = 29
    _get_CrossRangeWindowSize_method_offset = 30
    _set_CrossRangeWindowSize_method_offset = 31
    _get_RequiredBandwidth_method_offset = 32
    _get_CollectionAngle_method_offset = 33
    _get_FrequencySamplesPerPulse_method_offset = 34
    _get_MinimumPulseCount_method_offset = 35
    _get_Identifier_method_offset = 36
    _metadata = {
        "iid_data" : (5142214519392837796, 6233112050034224043),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarImagingDataProduct."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarImagingDataProduct)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarImagingDataProduct)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarImagingDataProduct, None)
    
    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Gets the image product name."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_Name_metadata)

    _get_EnableSensorFixedDistance_metadata = { "offset" : _get_EnableSensorFixedDistance_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def EnableSensorFixedDistance(self) -> bool:
        """Enables or disables the fixed disatance mode."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_EnableSensorFixedDistance_metadata)

    _set_EnableSensorFixedDistance_metadata = { "offset" : _set_EnableSensorFixedDistance_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @EnableSensorFixedDistance.setter
    def EnableSensorFixedDistance(self, val:bool) -> None:
        """Enables or disables the fixed disatance mode."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_EnableSensorFixedDistance_metadata, val)

    _get_DesiredSensorFixedDistance_metadata = { "offset" : _get_DesiredSensorFixedDistance_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DesiredSensorFixedDistance(self) -> float:
        """Gets or sets the fixed disatance."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_DesiredSensorFixedDistance_metadata)

    _set_DesiredSensorFixedDistance_metadata = { "offset" : _set_DesiredSensorFixedDistance_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @DesiredSensorFixedDistance.setter
    def DesiredSensorFixedDistance(self, val:float) -> None:
        """Gets or sets the fixed disatance."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_DesiredSensorFixedDistance_metadata, val)

    _get_DistanceToRangeWindowStart_metadata = { "offset" : _get_DistanceToRangeWindowStart_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DistanceToRangeWindowStart(self) -> float:
        """Gets or sets the distance to the range window start."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_DistanceToRangeWindowStart_metadata)

    _get_DistanceToRangeWindowCenter_metadata = { "offset" : _get_DistanceToRangeWindowCenter_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DistanceToRangeWindowCenter(self) -> float:
        """Gets or sets the distance to the range window center."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_DistanceToRangeWindowCenter_metadata)

    _get_CenterImageInRangeWindow_metadata = { "offset" : _get_CenterImageInRangeWindow_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def CenterImageInRangeWindow(self) -> bool:
        """Enables or disables whether the image will be centered in the range window."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_CenterImageInRangeWindow_metadata)

    _set_CenterImageInRangeWindow_metadata = { "offset" : _set_CenterImageInRangeWindow_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @CenterImageInRangeWindow.setter
    def CenterImageInRangeWindow(self, val:bool) -> None:
        """Enables or disables whether the image will be centered in the range window."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_CenterImageInRangeWindow_metadata, val)

    _get_EnableRangeDopplerImaging_metadata = { "offset" : _get_EnableRangeDopplerImaging_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def EnableRangeDopplerImaging(self) -> bool:
        """Enables radar range-doppler imaging."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_EnableRangeDopplerImaging_metadata)

    _set_EnableRangeDopplerImaging_metadata = { "offset" : _set_EnableRangeDopplerImaging_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @EnableRangeDopplerImaging.setter
    def EnableRangeDopplerImaging(self, val:bool) -> None:
        """Enables radar range-doppler imaging."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_EnableRangeDopplerImaging_metadata, val)

    _get_RangePixelCount_metadata = { "offset" : _get_RangePixelCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def RangePixelCount(self) -> int:
        """Gets or sets the range pixel count."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_RangePixelCount_metadata)

    _set_RangePixelCount_metadata = { "offset" : _set_RangePixelCount_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @RangePixelCount.setter
    def RangePixelCount(self, val:int) -> None:
        """Gets or sets the range pixel count."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_RangePixelCount_metadata, val)

    _get_VelocityPixelCount_metadata = { "offset" : _get_VelocityPixelCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def VelocityPixelCount(self) -> int:
        """Gets or sets the velocity pixel count."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_VelocityPixelCount_metadata)

    _set_VelocityPixelCount_metadata = { "offset" : _set_VelocityPixelCount_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @VelocityPixelCount.setter
    def VelocityPixelCount(self, val:int) -> None:
        """Gets or sets the velocity pixel count."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_VelocityPixelCount_metadata, val)

    _get_RangeWindowType_metadata = { "offset" : _get_RangeWindowType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmImageWindowType),) }
    @property
    def RangeWindowType(self) -> "AgERfcmImageWindowType":
        """Gets or sets the range window type."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_RangeWindowType_metadata)

    _set_RangeWindowType_metadata = { "offset" : _set_RangeWindowType_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmImageWindowType),) }
    @RangeWindowType.setter
    def RangeWindowType(self, val:"AgERfcmImageWindowType") -> None:
        """Gets or sets the range window type."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_RangeWindowType_metadata, val)

    _get_RangeWindowSideLobeLevel_metadata = { "offset" : _get_RangeWindowSideLobeLevel_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RangeWindowSideLobeLevel(self) -> float:
        """Gets or sets the range window side lobe level."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_RangeWindowSideLobeLevel_metadata)

    _set_RangeWindowSideLobeLevel_metadata = { "offset" : _set_RangeWindowSideLobeLevel_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RangeWindowSideLobeLevel.setter
    def RangeWindowSideLobeLevel(self, val:float) -> None:
        """Gets or sets the range window side lobe level."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_RangeWindowSideLobeLevel_metadata, val)

    _get_VelocityWindowType_metadata = { "offset" : _get_VelocityWindowType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmImageWindowType),) }
    @property
    def VelocityWindowType(self) -> "AgERfcmImageWindowType":
        """Gets or sets the velocity window type."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_VelocityWindowType_metadata)

    _set_VelocityWindowType_metadata = { "offset" : _set_VelocityWindowType_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmImageWindowType),) }
    @VelocityWindowType.setter
    def VelocityWindowType(self, val:"AgERfcmImageWindowType") -> None:
        """Gets or sets the velocity window type."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_VelocityWindowType_metadata, val)

    _get_VelocityWindowSideLobeLevel_metadata = { "offset" : _get_VelocityWindowSideLobeLevel_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def VelocityWindowSideLobeLevel(self) -> float:
        """Gets or sets the velocity window side lobe level."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_VelocityWindowSideLobeLevel_metadata)

    _set_VelocityWindowSideLobeLevel_metadata = { "offset" : _set_VelocityWindowSideLobeLevel_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @VelocityWindowSideLobeLevel.setter
    def VelocityWindowSideLobeLevel(self, val:float) -> None:
        """Gets or sets the velocity window side lobe level."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_VelocityWindowSideLobeLevel_metadata, val)

    _get_RangeResolution_metadata = { "offset" : _get_RangeResolution_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RangeResolution(self) -> float:
        """Gets or sets the range resolution."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_RangeResolution_metadata)

    _set_RangeResolution_metadata = { "offset" : _set_RangeResolution_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RangeResolution.setter
    def RangeResolution(self, val:float) -> None:
        """Gets or sets the range resolution."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_RangeResolution_metadata, val)

    _get_RangeWindowSize_metadata = { "offset" : _get_RangeWindowSize_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RangeWindowSize(self) -> float:
        """Gets or sets the range window size."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_RangeWindowSize_metadata)

    _set_RangeWindowSize_metadata = { "offset" : _set_RangeWindowSize_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RangeWindowSize.setter
    def RangeWindowSize(self, val:float) -> None:
        """Gets or sets the range window size."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_RangeWindowSize_metadata, val)

    _get_CrossRangeResolution_metadata = { "offset" : _get_CrossRangeResolution_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CrossRangeResolution(self) -> float:
        """Gets or sets the cross range resolution."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_CrossRangeResolution_metadata)

    _set_CrossRangeResolution_metadata = { "offset" : _set_CrossRangeResolution_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @CrossRangeResolution.setter
    def CrossRangeResolution(self, val:float) -> None:
        """Gets or sets the cross range resolution."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_CrossRangeResolution_metadata, val)

    _get_CrossRangeWindowSize_metadata = { "offset" : _get_CrossRangeWindowSize_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CrossRangeWindowSize(self) -> float:
        """Gets or sets the cross range window size."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_CrossRangeWindowSize_metadata)

    _set_CrossRangeWindowSize_metadata = { "offset" : _set_CrossRangeWindowSize_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @CrossRangeWindowSize.setter
    def CrossRangeWindowSize(self, val:float) -> None:
        """Gets or sets the cross range window size."""
        return self._intf.set_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._set_CrossRangeWindowSize_metadata, val)

    _get_RequiredBandwidth_metadata = { "offset" : _get_RequiredBandwidth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RequiredBandwidth(self) -> float:
        """Gets the waveform product's required bandwidth."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_RequiredBandwidth_metadata)

    _get_CollectionAngle_metadata = { "offset" : _get_CollectionAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CollectionAngle(self) -> float:
        """Gets the waveform collection angle."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_CollectionAngle_metadata)

    _get_FrequencySamplesPerPulse_metadata = { "offset" : _get_FrequencySamplesPerPulse_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def FrequencySamplesPerPulse(self) -> int:
        """Gets the number of frequency samples per pulse."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_FrequencySamplesPerPulse_metadata)

    _get_MinimumPulseCount_metadata = { "offset" : _get_MinimumPulseCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def MinimumPulseCount(self) -> int:
        """Gets the minimum pulse count."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_MinimumPulseCount_metadata)

    _get_Identifier_metadata = { "offset" : _get_Identifier_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Identifier(self) -> str:
        """Gets the unique identifier for the data product"""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProduct._metadata, IAgStkRfcmRadarImagingDataProduct._get_Identifier_metadata)

    _property_names[Name] = "Name"
    _property_names[EnableSensorFixedDistance] = "EnableSensorFixedDistance"
    _property_names[DesiredSensorFixedDistance] = "DesiredSensorFixedDistance"
    _property_names[DistanceToRangeWindowStart] = "DistanceToRangeWindowStart"
    _property_names[DistanceToRangeWindowCenter] = "DistanceToRangeWindowCenter"
    _property_names[CenterImageInRangeWindow] = "CenterImageInRangeWindow"
    _property_names[EnableRangeDopplerImaging] = "EnableRangeDopplerImaging"
    _property_names[RangePixelCount] = "RangePixelCount"
    _property_names[VelocityPixelCount] = "VelocityPixelCount"
    _property_names[RangeWindowType] = "RangeWindowType"
    _property_names[RangeWindowSideLobeLevel] = "RangeWindowSideLobeLevel"
    _property_names[VelocityWindowType] = "VelocityWindowType"
    _property_names[VelocityWindowSideLobeLevel] = "VelocityWindowSideLobeLevel"
    _property_names[RangeResolution] = "RangeResolution"
    _property_names[RangeWindowSize] = "RangeWindowSize"
    _property_names[CrossRangeResolution] = "CrossRangeResolution"
    _property_names[CrossRangeWindowSize] = "CrossRangeWindowSize"
    _property_names[RequiredBandwidth] = "RequiredBandwidth"
    _property_names[CollectionAngle] = "CollectionAngle"
    _property_names[FrequencySamplesPerPulse] = "FrequencySamplesPerPulse"
    _property_names[MinimumPulseCount] = "MinimumPulseCount"
    _property_names[Identifier] = "Identifier"


agcls.AgClassCatalog.add_catalog_entry((5142214519392837796, 6233112050034224043), IAgStkRfcmRadarImagingDataProduct)
agcls.AgTypeNameMap["IAgStkRfcmRadarImagingDataProduct"] = IAgStkRfcmRadarImagingDataProduct

class IAgStkRfcmRadarImagingDataProductCollection(object):
    """Represents a collection of radar imaging data products."""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Contains_method_offset = 4
    _FindByIdentifier_method_offset = 5
    _metadata = {
        "iid_data" : (4970923993909938536, 14862492402545961636),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarImagingDataProductCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarImagingDataProductCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarImagingDataProductCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarImagingDataProductCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmRadarImagingDataProductCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmRadarImagingDataProduct":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProductCollection._metadata, IAgStkRfcmRadarImagingDataProductCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmRadarImagingDataProduct":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmRadarImagingDataProductCollection._metadata, IAgStkRfcmRadarImagingDataProductCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmRadarImagingDataProductCollection._metadata, IAgStkRfcmRadarImagingDataProductCollection._get__NewEnum_metadata)

    _Contains_metadata = { "offset" : _Contains_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def Contains(self, identifier:str) -> bool:
        """Checks to see if a imaging data product with given identifier exists in the collection."""
        return self._intf.invoke(IAgStkRfcmRadarImagingDataProductCollection._metadata, IAgStkRfcmRadarImagingDataProductCollection._Contains_metadata, identifier, OutArg())

    _FindByIdentifier_metadata = { "offset" : _FindByIdentifier_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def FindByIdentifier(self, identifier:str) -> "IAgStkRfcmRadarImagingDataProduct":
        """Returns the imaging data product in the collection with the supplied identifier or Null if not found or invalid."""
        return self._intf.invoke(IAgStkRfcmRadarImagingDataProductCollection._metadata, IAgStkRfcmRadarImagingDataProductCollection._FindByIdentifier_metadata, identifier, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((4970923993909938536, 14862492402545961636), IAgStkRfcmRadarImagingDataProductCollection)
agcls.AgTypeNameMap["IAgStkRfcmRadarImagingDataProductCollection"] = IAgStkRfcmRadarImagingDataProductCollection

class IAgStkRfcmRadarAnalysisConfigurationModel(object):
    """Properties for an analysis configuration model for a radar analysis. This contains a collection of the transceiver configurations belonging to the radar analysis."""

    _num_methods = 2
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_TransceiverConfigurationCollection_method_offset = 1
    _get_ImagingDataProductList_method_offset = 2
    _metadata = {
        "iid_data" : (4635842407038885586, 5216845520973926036),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarAnalysisConfigurationModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarAnalysisConfigurationModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarAnalysisConfigurationModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarAnalysisConfigurationModel, None)
    
    _get_TransceiverConfigurationCollection_metadata = { "offset" : _get_TransceiverConfigurationCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def TransceiverConfigurationCollection(self) -> "IAgStkRfcmRadarTransceiverConfigurationCollection":
        """Gets the collection of transceiver configurations."""
        return self._intf.get_property(IAgStkRfcmRadarAnalysisConfigurationModel._metadata, IAgStkRfcmRadarAnalysisConfigurationModel._get_TransceiverConfigurationCollection_metadata)

    _get_ImagingDataProductList_metadata = { "offset" : _get_ImagingDataProductList_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ImagingDataProductList(self) -> "IAgStkRfcmRadarImagingDataProductCollection":
        """Gets the imaging product list."""
        return self._intf.get_property(IAgStkRfcmRadarAnalysisConfigurationModel._metadata, IAgStkRfcmRadarAnalysisConfigurationModel._get_ImagingDataProductList_metadata)

    _property_names[TransceiverConfigurationCollection] = "TransceiverConfigurationCollection"
    _property_names[ImagingDataProductList] = "ImagingDataProductList"


agcls.AgClassCatalog.add_catalog_entry((4635842407038885586, 5216845520973926036), IAgStkRfcmRadarAnalysisConfigurationModel)
agcls.AgTypeNameMap["IAgStkRfcmRadarAnalysisConfigurationModel"] = IAgStkRfcmRadarAnalysisConfigurationModel

class IAgStkRfcmRadarISarAnalysisConfigurationModel(object):
    """The analysis configuration model for an ISar analysis. This contains a collection of the transceiver configurations belonging to the ISar analysis."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_RadarTargetCollection_method_offset = 1
    _metadata = {
        "iid_data" : (4699547487188819079, 7119029616558802341),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarISarAnalysisConfigurationModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarISarAnalysisConfigurationModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarISarAnalysisConfigurationModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarISarAnalysisConfigurationModel, None)
    
    _get_RadarTargetCollection_metadata = { "offset" : _get_RadarTargetCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def RadarTargetCollection(self) -> "IAgStkRfcmSceneContributorCollection":
        """Gets the collection of radar targets."""
        return self._intf.get_property(IAgStkRfcmRadarISarAnalysisConfigurationModel._metadata, IAgStkRfcmRadarISarAnalysisConfigurationModel._get_RadarTargetCollection_metadata)

    _property_names[RadarTargetCollection] = "RadarTargetCollection"


agcls.AgClassCatalog.add_catalog_entry((4699547487188819079, 7119029616558802341), IAgStkRfcmRadarISarAnalysisConfigurationModel)
agcls.AgTypeNameMap["IAgStkRfcmRadarISarAnalysisConfigurationModel"] = IAgStkRfcmRadarISarAnalysisConfigurationModel

class IAgStkRfcmRadarSarAnalysisConfigurationModel(object):
    """The analysis configuration model for a Sar analysis. This contains a collection of the transceiver configurations belonging to the Sar analysis."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ImageLocationCollection_method_offset = 1
    _metadata = {
        "iid_data" : (4854169440574638134, 10421576952529875864),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmRadarSarAnalysisConfigurationModel."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmRadarSarAnalysisConfigurationModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmRadarSarAnalysisConfigurationModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmRadarSarAnalysisConfigurationModel, None)
    
    _get_ImageLocationCollection_metadata = { "offset" : _get_ImageLocationCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ImageLocationCollection(self) -> "IAgStkRfcmRadarSarImageLocationCollection":
        """Gets the collection of image locations."""
        return self._intf.get_property(IAgStkRfcmRadarSarAnalysisConfigurationModel._metadata, IAgStkRfcmRadarSarAnalysisConfigurationModel._get_ImageLocationCollection_metadata)

    _property_names[ImageLocationCollection] = "ImageLocationCollection"


agcls.AgClassCatalog.add_catalog_entry((4854169440574638134, 10421576952529875864), IAgStkRfcmRadarSarAnalysisConfigurationModel)
agcls.AgTypeNameMap["IAgStkRfcmRadarSarAnalysisConfigurationModel"] = IAgStkRfcmRadarSarAnalysisConfigurationModel

class IAgStkRfcmAnalysisConfiguration(object):
    """Properties of a configuration for an analysis."""

    _num_methods = 8
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Name_method_offset = 1
    _set_Name_method_offset = 2
    _get_Description_method_offset = 3
    _set_Description_method_offset = 4
    _get_SupportedCentralBodies_method_offset = 5
    _get_CentralBodyName_method_offset = 6
    _set_CentralBodyName_method_offset = 7
    _get_Model_method_offset = 8
    _metadata = {
        "iid_data" : (5101846457140874039, 3763858361601011076),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmAnalysisConfiguration."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmAnalysisConfiguration)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmAnalysisConfiguration)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmAnalysisConfiguration, None)
    
    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Gets or sets the configuration name."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._get_Name_metadata)

    _set_Name_metadata = { "offset" : _set_Name_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Name.setter
    def Name(self, name:str) -> None:
        """Gets or sets the configuration name."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._set_Name_metadata, name)

    _get_Description_metadata = { "offset" : _get_Description_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Description(self) -> str:
        """Gets or sets the configuration description."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._get_Description_metadata)

    _set_Description_metadata = { "offset" : _set_Description_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Description.setter
    def Description(self, description:str) -> None:
        """Gets or sets the configuration description."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._set_Description_metadata, description)

    _get_SupportedCentralBodies_metadata = { "offset" : _get_SupportedCentralBodies_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SupportedCentralBodies(self) -> list:
        """Gets an array of available central bodies."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._get_SupportedCentralBodies_metadata)

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """Gets the configured central body name."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._get_CentralBodyName_metadata)

    _set_CentralBodyName_metadata = { "offset" : _set_CentralBodyName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @CentralBodyName.setter
    def CentralBodyName(self, val:str) -> None:
        """Sets the configured central body name."""
        return self._intf.set_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._set_CentralBodyName_metadata, val)

    _get_Model_metadata = { "offset" : _get_Model_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Model(self) -> "IAgStkRfcmAnalysisConfigurationModel":
        """Get the analysis configuration model."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfiguration._metadata, IAgStkRfcmAnalysisConfiguration._get_Model_metadata)

    _property_names[Name] = "Name"
    _property_names[Description] = "Description"
    _property_names[SupportedCentralBodies] = "SupportedCentralBodies"
    _property_names[CentralBodyName] = "CentralBodyName"
    _property_names[Model] = "Model"


agcls.AgClassCatalog.add_catalog_entry((5101846457140874039, 3763858361601011076), IAgStkRfcmAnalysisConfiguration)
agcls.AgTypeNameMap["IAgStkRfcmAnalysisConfiguration"] = IAgStkRfcmAnalysisConfiguration

class IAgStkRfcmAnalysisConfigurationCollection(object):
    """Represents a collection of analysis configurations."""

    _num_methods = 10
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _RemoveAt_method_offset = 4
    _Remove_method_offset = 5
    _AddNew_method_offset = 6
    _Add_method_offset = 7
    _RemoveAll_method_offset = 8
    _Contains_method_offset = 9
    _Find_method_offset = 10
    _metadata = {
        "iid_data" : (4662220020043770228, 1775359325286225077),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmAnalysisConfigurationCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmAnalysisConfigurationCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmAnalysisConfigurationCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmAnalysisConfigurationCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRfcmAnalysisConfigurationCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRfcmAnalysisConfiguration":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRfcmAnalysisConfiguration":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._get__NewEnum_metadata)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Removes the analysis configuration at the supplied index."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._RemoveAt_metadata, index)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmAnalysisConfiguration"),) }
    def Remove(self, pVal:"IAgStkRfcmAnalysisConfiguration") -> None:
        """Removes the supplied analysis configuration."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._Remove_metadata, pVal)

    _AddNew_metadata = { "offset" : _AddNew_method_offset,
            "arg_types" : (agcom.LONG, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisConfigurationModelType), agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def AddNew(self, modelType:"AgERfcmAnalysisConfigurationModelType", configurationName:str) -> "IAgStkRfcmAnalysisConfiguration":
        """Adds and returns a new analysis configuration."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._AddNew_metadata, modelType, configurationName, OutArg())

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmAnalysisConfiguration"),) }
    def Add(self, pVal:"IAgStkRfcmAnalysisConfiguration") -> None:
        """Adds the supplied analysis configuration."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._Add_metadata, pVal)

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Clears the collection."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._RemoveAll_metadata, )

    _Contains_metadata = { "offset" : _Contains_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def Contains(self, configurationName:str) -> bool:
        """Determines if the collection contains an analysis configuration with the given name."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._Contains_metadata, configurationName, OutArg())

    _Find_metadata = { "offset" : _Find_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def Find(self, configurationName:str) -> "IAgStkRfcmAnalysisConfiguration":
        """Finds an analysis configuration by name. Returns Null if the configuration name does not exist in the collection."""
        return self._intf.invoke(IAgStkRfcmAnalysisConfigurationCollection._metadata, IAgStkRfcmAnalysisConfigurationCollection._Find_metadata, configurationName, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((4662220020043770228, 1775359325286225077), IAgStkRfcmAnalysisConfigurationCollection)
agcls.AgTypeNameMap["IAgStkRfcmAnalysisConfigurationCollection"] = IAgStkRfcmAnalysisConfigurationCollection

class IAgStkRfcmComputeOptions(object):
    """Properties for solver advanced compute options."""

    _num_methods = 14
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_RayDensity_method_offset = 1
    _set_RayDensity_method_offset = 2
    _get_GeometricalOpticsBlockage_method_offset = 3
    _set_GeometricalOpticsBlockage_method_offset = 4
    _get_GeometricalOpticsBlockageStartingBounce_method_offset = 5
    _set_GeometricalOpticsBlockageStartingBounce_method_offset = 6
    _get_MaximumReflections_method_offset = 7
    _set_MaximumReflections_method_offset = 8
    _get_MaximumTransmissions_method_offset = 9
    _set_MaximumTransmissions_method_offset = 10
    _get_BoundingBoxMode_method_offset = 11
    _set_BoundingBoxMode_method_offset = 12
    _get_BoundingBoxSideLength_method_offset = 13
    _set_BoundingBoxSideLength_method_offset = 14
    _metadata = {
        "iid_data" : (5486226833155479016, 11259931109832989631),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmComputeOptions."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmComputeOptions)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmComputeOptions)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmComputeOptions, None)
    
    _get_RayDensity_metadata = { "offset" : _get_RayDensity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RayDensity(self) -> float:
        """Gets or sets the ray density."""
        return self._intf.get_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._get_RayDensity_metadata)

    _set_RayDensity_metadata = { "offset" : _set_RayDensity_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RayDensity.setter
    def RayDensity(self, val:float) -> None:
        """Gets or sets the ray density"""
        return self._intf.set_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._set_RayDensity_metadata, val)

    _get_GeometricalOpticsBlockage_metadata = { "offset" : _get_GeometricalOpticsBlockage_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def GeometricalOpticsBlockage(self) -> bool:
        """Gets or sets the geometrical optics blockage."""
        return self._intf.get_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._get_GeometricalOpticsBlockage_metadata)

    _set_GeometricalOpticsBlockage_metadata = { "offset" : _set_GeometricalOpticsBlockage_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @GeometricalOpticsBlockage.setter
    def GeometricalOpticsBlockage(self, val:bool) -> None:
        """Gets or sets the geometrical optics blockage."""
        return self._intf.set_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._set_GeometricalOpticsBlockage_metadata, val)

    _get_GeometricalOpticsBlockageStartingBounce_metadata = { "offset" : _get_GeometricalOpticsBlockageStartingBounce_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def GeometricalOpticsBlockageStartingBounce(self) -> int:
        """Gets or sets the geometrical optics blockage starting bounce."""
        return self._intf.get_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._get_GeometricalOpticsBlockageStartingBounce_metadata)

    _set_GeometricalOpticsBlockageStartingBounce_metadata = { "offset" : _set_GeometricalOpticsBlockageStartingBounce_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @GeometricalOpticsBlockageStartingBounce.setter
    def GeometricalOpticsBlockageStartingBounce(self, val:int) -> None:
        """Gets or sets the geometrical optics blockage starting bounce."""
        return self._intf.set_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._set_GeometricalOpticsBlockageStartingBounce_metadata, val)

    _get_MaximumReflections_metadata = { "offset" : _get_MaximumReflections_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def MaximumReflections(self) -> int:
        """Gets or sets the maximum number of reflections."""
        return self._intf.get_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._get_MaximumReflections_metadata)

    _set_MaximumReflections_metadata = { "offset" : _set_MaximumReflections_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @MaximumReflections.setter
    def MaximumReflections(self, val:int) -> None:
        """Gets or sets the maximum number of reflections."""
        return self._intf.set_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._set_MaximumReflections_metadata, val)

    _get_MaximumTransmissions_metadata = { "offset" : _get_MaximumTransmissions_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def MaximumTransmissions(self) -> int:
        """Gets or sets the maximum number of transmissions."""
        return self._intf.get_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._get_MaximumTransmissions_metadata)

    _set_MaximumTransmissions_metadata = { "offset" : _set_MaximumTransmissions_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    @MaximumTransmissions.setter
    def MaximumTransmissions(self, val:int) -> None:
        """Gets or sets the maximum number of transmissions."""
        return self._intf.set_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._set_MaximumTransmissions_metadata, val)

    _get_BoundingBoxMode_metadata = { "offset" : _get_BoundingBoxMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisSolverBoundingBoxMode),) }
    @property
    def BoundingBoxMode(self) -> "AgERfcmAnalysisSolverBoundingBoxMode":
        """Gets or sets the bounding box."""
        return self._intf.get_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._get_BoundingBoxMode_metadata)

    _set_BoundingBoxMode_metadata = { "offset" : _set_BoundingBoxMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgERfcmAnalysisSolverBoundingBoxMode),) }
    @BoundingBoxMode.setter
    def BoundingBoxMode(self, val:"AgERfcmAnalysisSolverBoundingBoxMode") -> None:
        """Gets or sets the bounding box."""
        return self._intf.set_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._set_BoundingBoxMode_metadata, val)

    _get_BoundingBoxSideLength_metadata = { "offset" : _get_BoundingBoxSideLength_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def BoundingBoxSideLength(self) -> float:
        """Gets or sets the bounding box side length."""
        return self._intf.get_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._get_BoundingBoxSideLength_metadata)

    _set_BoundingBoxSideLength_metadata = { "offset" : _set_BoundingBoxSideLength_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @BoundingBoxSideLength.setter
    def BoundingBoxSideLength(self, val:float) -> None:
        """Gets or sets the bounding box side length"""
        return self._intf.set_property(IAgStkRfcmComputeOptions._metadata, IAgStkRfcmComputeOptions._set_BoundingBoxSideLength_metadata, val)

    _property_names[RayDensity] = "RayDensity"
    _property_names[GeometricalOpticsBlockage] = "GeometricalOpticsBlockage"
    _property_names[GeometricalOpticsBlockageStartingBounce] = "GeometricalOpticsBlockageStartingBounce"
    _property_names[MaximumReflections] = "MaximumReflections"
    _property_names[MaximumTransmissions] = "MaximumTransmissions"
    _property_names[BoundingBoxMode] = "BoundingBoxMode"
    _property_names[BoundingBoxSideLength] = "BoundingBoxSideLength"


agcls.AgClassCatalog.add_catalog_entry((5486226833155479016, 11259931109832989631), IAgStkRfcmComputeOptions)
agcls.AgTypeNameMap["IAgStkRfcmComputeOptions"] = IAgStkRfcmComputeOptions

class IAgStkRfcmGpuProperties(object):
    """Properties of a GPU that pertain to RF Channel Modeler."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Name_method_offset = 1
    _get_ComputeCapability_method_offset = 2
    _get_DeviceId_method_offset = 3
    _get_ProcessorCount_method_offset = 4
    _get_SpeedMHz_method_offset = 5
    _get_MemoryGB_method_offset = 6
    _metadata = {
        "iid_data" : (4721899476075187212, 4888009188086501010),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRfcmGpuProperties."""
        initialize_from_source_object(self, sourceObject, IAgStkRfcmGpuProperties)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRfcmGpuProperties)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRfcmGpuProperties, None)
    
    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Gets the GPU name."""
        return self._intf.get_property(IAgStkRfcmGpuProperties._metadata, IAgStkRfcmGpuProperties._get_Name_metadata)

    _get_ComputeCapability_metadata = { "offset" : _get_ComputeCapability_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ComputeCapability(self) -> str:
        """Gets the GPU compute capability."""
        return self._intf.get_property(IAgStkRfcmGpuProperties._metadata, IAgStkRfcmGpuProperties._get_ComputeCapability_metadata)

    _get_DeviceId_metadata = { "offset" : _get_DeviceId_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def DeviceId(self) -> int:
        """Gets the GPU device ID."""
        return self._intf.get_property(IAgStkRfcmGpuProperties._metadata, IAgStkRfcmGpuProperties._get_DeviceId_metadata)

    _get_ProcessorCount_metadata = { "offset" : _get_ProcessorCount_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def ProcessorCount(self) -> int:
        """Gets the GPU processor count."""
        return self._intf.get_property(IAgStkRfcmGpuProperties._metadata, IAgStkRfcmGpuProperties._get_ProcessorCount_metadata)

    _get_SpeedMHz_metadata = { "offset" : _get_SpeedMHz_method_offset,
            "arg_types" : (POINTER(agcom.FLOAT),),
            "marshallers" : (agmarshall.FLOAT_arg,) }
    @property
    def SpeedMHz(self) -> float:
        """Gets the GPU speed in MHz."""
        return self._intf.get_property(IAgStkRfcmGpuProperties._metadata, IAgStkRfcmGpuProperties._get_SpeedMHz_metadata)

    _get_MemoryGB_metadata = { "offset" : _get_MemoryGB_method_offset,
            "arg_types" : (POINTER(agcom.FLOAT),),
            "marshallers" : (agmarshall.FLOAT_arg,) }
    @property
    def MemoryGB(self) -> float:
        """Gets the GPU memory in GB."""
        return self._intf.get_property(IAgStkRfcmGpuProperties._metadata, IAgStkRfcmGpuProperties._get_MemoryGB_metadata)

    _property_names[Name] = "Name"
    _property_names[ComputeCapability] = "ComputeCapability"
    _property_names[DeviceId] = "DeviceId"
    _property_names[ProcessorCount] = "ProcessorCount"
    _property_names[SpeedMHz] = "SpeedMHz"
    _property_names[MemoryGB] = "MemoryGB"


agcls.AgClassCatalog.add_catalog_entry((4721899476075187212, 4888009188086501010), IAgStkRfcmGpuProperties)
agcls.AgTypeNameMap["IAgStkRfcmGpuProperties"] = IAgStkRfcmGpuProperties

class IAgStkRFChannelModeler(object):
    """Properties of the main RF Channel Modeler object."""

    _num_methods = 11
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_TransceiverCollection_method_offset = 1
    _get_AnalysisConfigurationCollection_method_offset = 2
    _DuplicateTransceiver_method_offset = 3
    _DuplicateAnalysisConfiguration_method_offset = 4
    _get_SupportedMaterials_method_offset = 5
    _get_DefaultMaterials_method_offset = 6
    _get_ComputeOptions_method_offset = 7
    _get_SupportedGpuPropertiesList_method_offset = 8
    _SetGpuDevices_method_offset = 9
    _ConstructAnalysis_method_offset = 10
    _ValidateAnalysis_method_offset = 11
    _metadata = {
        "iid_data" : (5326550927957697862, 7805227810553142921),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRFChannelModeler."""
        initialize_from_source_object(self, sourceObject, IAgStkRFChannelModeler)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRFChannelModeler)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRFChannelModeler, None)
    
    _get_TransceiverCollection_metadata = { "offset" : _get_TransceiverCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def TransceiverCollection(self) -> "IAgStkRfcmTransceiverCollection":
        """Gets the collection of transceiver objects."""
        return self._intf.get_property(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._get_TransceiverCollection_metadata)

    _get_AnalysisConfigurationCollection_metadata = { "offset" : _get_AnalysisConfigurationCollection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def AnalysisConfigurationCollection(self) -> "IAgStkRfcmAnalysisConfigurationCollection":
        """Gets the collection of analysis configurations."""
        return self._intf.get_property(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._get_AnalysisConfigurationCollection_metadata)

    _DuplicateTransceiver_metadata = { "offset" : _DuplicateTransceiver_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmTransceiver"), agmarshall.AgInterface_out_arg,) }
    def DuplicateTransceiver(self, pTransceiver:"IAgStkRfcmTransceiver") -> "IAgStkRfcmTransceiver":
        """Duplicates a transceiver instance."""
        return self._intf.invoke(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._DuplicateTransceiver_metadata, pTransceiver, OutArg())

    _DuplicateAnalysisConfiguration_metadata = { "offset" : _DuplicateAnalysisConfiguration_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRfcmAnalysisConfiguration"), agmarshall.AgInterface_out_arg,) }
    def DuplicateAnalysisConfiguration(self, pAnalysisConfiguration:"IAgStkRfcmAnalysisConfiguration") -> "IAgStkRfcmAnalysisConfiguration":
        """Duplicates an analysis configuration instance."""
        return self._intf.invoke(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._DuplicateAnalysisConfiguration_metadata, pAnalysisConfiguration, OutArg())

    _get_SupportedMaterials_metadata = { "offset" : _get_SupportedMaterials_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SupportedMaterials(self) -> list:
        """Gets the supported tileset materials"""
        return self._intf.get_property(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._get_SupportedMaterials_metadata)

    _get_DefaultMaterials_metadata = { "offset" : _get_DefaultMaterials_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def DefaultMaterials(self) -> list:
        """Gets the default tileset materials"""
        return self._intf.get_property(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._get_DefaultMaterials_metadata)

    _get_ComputeOptions_metadata = { "offset" : _get_ComputeOptions_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ComputeOptions(self) -> "IAgStkRfcmComputeOptions":
        """Gets the compute options."""
        return self._intf.get_property(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._get_ComputeOptions_metadata)

    _get_SupportedGpuPropertiesList_metadata = { "offset" : _get_SupportedGpuPropertiesList_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SupportedGpuPropertiesList(self) -> list:
        """Gets the GPU properties list."""
        return self._intf.get_property(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._get_SupportedGpuPropertiesList_metadata)

    _SetGpuDevices_metadata = { "offset" : _SetGpuDevices_method_offset,
            "arg_types" : (agcom.LPSAFEARRAY,),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def SetGpuDevices(self, pGpuDeviceIds:list) -> None:
        """Sets the desired GPU device IDs"""
        return self._intf.invoke(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._SetGpuDevices_metadata, pGpuDeviceIds)

    _ConstructAnalysis_metadata = { "offset" : _ConstructAnalysis_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConstructAnalysis(self, analysisConfigurationName:str) -> "IAgStkRfcmAnalysis":
        """Constructs an Analysis for an analysis configuration."""
        return self._intf.invoke(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._ConstructAnalysis_metadata, analysisConfigurationName, OutArg())

    _ValidateAnalysis_metadata = { "offset" : _ValidateAnalysis_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ValidateAnalysis(self, analysisConfigurationName:str) -> "IAgStkRfcmValidationResponse":
        """Validates an analysis configuration."""
        return self._intf.invoke(IAgStkRFChannelModeler._metadata, IAgStkRFChannelModeler._ValidateAnalysis_metadata, analysisConfigurationName, OutArg())

    _property_names[TransceiverCollection] = "TransceiverCollection"
    _property_names[AnalysisConfigurationCollection] = "AnalysisConfigurationCollection"
    _property_names[SupportedMaterials] = "SupportedMaterials"
    _property_names[DefaultMaterials] = "DefaultMaterials"
    _property_names[ComputeOptions] = "ComputeOptions"
    _property_names[SupportedGpuPropertiesList] = "SupportedGpuPropertiesList"


agcls.AgClassCatalog.add_catalog_entry((5326550927957697862, 7805227810553142921), IAgStkRFChannelModeler)
agcls.AgTypeNameMap["IAgStkRFChannelModeler"] = IAgStkRFChannelModeler



class AgStkRfcmRadarImagingDataProduct(IAgStkRfcmRadarImagingDataProduct, SupportsDeleteCallback):
    """Imaging data product that facilitates the generation of range doppler radar images."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarImagingDataProduct."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmRadarImagingDataProduct.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmRadarImagingDataProduct._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarImagingDataProduct, [IAgStkRfcmRadarImagingDataProduct])

agcls.AgClassCatalog.add_catalog_entry((5074933986252676529, 8852701032538182291), AgStkRfcmRadarImagingDataProduct)
agcls.AgTypeNameMap["AgStkRfcmRadarImagingDataProduct"] = AgStkRfcmRadarImagingDataProduct

class AgStkRfcmMaterial(IAgStkRfcmMaterial, SupportsDeleteCallback):
    """A material for scene contributors."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmMaterial."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmMaterial.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmMaterial._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmMaterial, [IAgStkRfcmMaterial])

agcls.AgClassCatalog.add_catalog_entry((5585828003287260468, 16548653199708755882), AgStkRfcmMaterial)
agcls.AgTypeNameMap["AgStkRfcmMaterial"] = AgStkRfcmMaterial

class AgStkRfcmFacetTileset(IAgStkRfcmFacetTileset, SupportsDeleteCallback):
    """The facet tileset information."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmFacetTileset."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmFacetTileset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmFacetTileset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmFacetTileset, [IAgStkRfcmFacetTileset])

agcls.AgClassCatalog.add_catalog_entry((4888196436732093925, 11141857126072407213), AgStkRfcmFacetTileset)
agcls.AgTypeNameMap["AgStkRfcmFacetTileset"] = AgStkRfcmFacetTileset

class AgStkRfcmValidationResponse(IAgStkRfcmValidationResponse, SupportsDeleteCallback):
    """The response from validating an analysis configuration."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmValidationResponse."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmValidationResponse.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmValidationResponse._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmValidationResponse, [IAgStkRfcmValidationResponse])

agcls.AgClassCatalog.add_catalog_entry((4804640472049572896, 16088033728626929551), AgStkRfcmValidationResponse)
agcls.AgTypeNameMap["AgStkRfcmValidationResponse"] = AgStkRfcmValidationResponse

class AgStkRfcmExtent(IAgStkRfcmExtent, SupportsDeleteCallback):
    """The extent in which the channel characterizations will be computed."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmExtent."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmExtent.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmExtent._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmExtent, [IAgStkRfcmExtent])

agcls.AgClassCatalog.add_catalog_entry((4900388743329603538, 7944534523141337986), AgStkRfcmExtent)
agcls.AgTypeNameMap["AgStkRfcmExtent"] = AgStkRfcmExtent

class AgStkRfcmCommunicationsWaveform(IAgStkRfcmCommunicationsWaveform, SupportsDeleteCallback):
    """The waveform settings of a communications transceiver."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmCommunicationsWaveform."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmCommunicationsWaveform.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmCommunicationsWaveform._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmCommunicationsWaveform, [IAgStkRfcmCommunicationsWaveform])

agcls.AgClassCatalog.add_catalog_entry((5578603191846218821, 13050805049586632106), AgStkRfcmCommunicationsWaveform)
agcls.AgTypeNameMap["AgStkRfcmCommunicationsWaveform"] = AgStkRfcmCommunicationsWaveform

class AgStkRfcmRadarWaveform(IAgStkRfcmRadarWaveform, SupportsDeleteCallback):
    """The waveform settings of a radar transceiver."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarWaveform."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmRadarWaveform.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmRadarWaveform._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarWaveform, [IAgStkRfcmRadarWaveform])

agcls.AgClassCatalog.add_catalog_entry((4703831939351115472, 12881818140868134074), AgStkRfcmRadarWaveform)
agcls.AgTypeNameMap["AgStkRfcmRadarWaveform"] = AgStkRfcmRadarWaveform

class AgStkRfcmParametricBeamAntenna(IAgStkRfcmAntenna, IAgStkRfcmParametricBeamAntenna, SupportsDeleteCallback):
    """The antenna settings for a parametric beam antenna."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmParametricBeamAntenna."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAntenna.__init__(self, sourceObject)
        IAgStkRfcmParametricBeamAntenna.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAntenna._private_init(self, intf)
        IAgStkRfcmParametricBeamAntenna._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmParametricBeamAntenna, [IAgStkRfcmAntenna, IAgStkRfcmParametricBeamAntenna])

agcls.AgClassCatalog.add_catalog_entry((5281565447641177900, 16732104418991711902), AgStkRfcmParametricBeamAntenna)
agcls.AgTypeNameMap["AgStkRfcmParametricBeamAntenna"] = AgStkRfcmParametricBeamAntenna

class AgStkRfcmElementExportPatternAntenna(IAgStkRfcmAntenna, IAgStkRfcmElementExportPatternAntenna, SupportsDeleteCallback):
    """The antenna settings for an element export pattern antenna."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmElementExportPatternAntenna."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAntenna.__init__(self, sourceObject)
        IAgStkRfcmElementExportPatternAntenna.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAntenna._private_init(self, intf)
        IAgStkRfcmElementExportPatternAntenna._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmElementExportPatternAntenna, [IAgStkRfcmAntenna, IAgStkRfcmElementExportPatternAntenna])

agcls.AgClassCatalog.add_catalog_entry((4825374820807761942, 16197124924034080433), AgStkRfcmElementExportPatternAntenna)
agcls.AgTypeNameMap["AgStkRfcmElementExportPatternAntenna"] = AgStkRfcmElementExportPatternAntenna

class AgStkRfcmFarFieldDataPatternAntenna(IAgStkRfcmAntenna, IAgStkRfcmFarFieldDataPatternAntenna, SupportsDeleteCallback):
    """The antenna settings for a far field data pattern antenna."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmFarFieldDataPatternAntenna."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAntenna.__init__(self, sourceObject)
        IAgStkRfcmFarFieldDataPatternAntenna.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAntenna._private_init(self, intf)
        IAgStkRfcmFarFieldDataPatternAntenna._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmFarFieldDataPatternAntenna, [IAgStkRfcmAntenna, IAgStkRfcmFarFieldDataPatternAntenna])

agcls.AgClassCatalog.add_catalog_entry((5592290011870032292, 2726481583475271050), AgStkRfcmFarFieldDataPatternAntenna)
agcls.AgTypeNameMap["AgStkRfcmFarFieldDataPatternAntenna"] = AgStkRfcmFarFieldDataPatternAntenna

class AgStkRfcmTransceiver(IAgStkRfcmTransceiver, SupportsDeleteCallback):
    """The transceiver object and its settings."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmTransceiver."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmTransceiver.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmTransceiver._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmTransceiver, [IAgStkRfcmTransceiver])

agcls.AgClassCatalog.add_catalog_entry((4774390769497310370, 10087295320591673777), AgStkRfcmTransceiver)
agcls.AgTypeNameMap["AgStkRfcmTransceiver"] = AgStkRfcmTransceiver

class AgStkRfcmCommunicationsTransceiverConfiguration(IAgStkRfcmCommunicationsTransceiverConfiguration, SupportsDeleteCallback):
    """The transceiver configuration for a communications transceiver."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmCommunicationsTransceiverConfiguration."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmCommunicationsTransceiverConfiguration.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmCommunicationsTransceiverConfiguration._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmCommunicationsTransceiverConfiguration, [IAgStkRfcmCommunicationsTransceiverConfiguration])

agcls.AgClassCatalog.add_catalog_entry((4989635995711489442, 13106208359506057875), AgStkRfcmCommunicationsTransceiverConfiguration)
agcls.AgTypeNameMap["AgStkRfcmCommunicationsTransceiverConfiguration"] = AgStkRfcmCommunicationsTransceiverConfiguration

class AgStkRfcmRadarTransceiverConfiguration(IAgStkRfcmRadarTransceiverConfiguration, SupportsDeleteCallback):
    """The transceiver configuration for a radar transceiver."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarTransceiverConfiguration."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmRadarTransceiverConfiguration.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmRadarTransceiverConfiguration._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarTransceiverConfiguration, [IAgStkRfcmRadarTransceiverConfiguration])

agcls.AgClassCatalog.add_catalog_entry((5302182047077719402, 6821497016786865593), AgStkRfcmRadarTransceiverConfiguration)
agcls.AgTypeNameMap["AgStkRfcmRadarTransceiverConfiguration"] = AgStkRfcmRadarTransceiverConfiguration

class AgStkRfcmRadarImagingDataProductCollection(IAgStkRfcmRadarImagingDataProductCollection, SupportsDeleteCallback):
    """A collection of radar transceivers."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarImagingDataProductCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmRadarImagingDataProductCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmRadarImagingDataProductCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarImagingDataProductCollection, [IAgStkRfcmRadarImagingDataProductCollection])

agcls.AgClassCatalog.add_catalog_entry((5262960150006393489, 11430595506678663558), AgStkRfcmRadarImagingDataProductCollection)
agcls.AgTypeNameMap["AgStkRfcmRadarImagingDataProductCollection"] = AgStkRfcmRadarImagingDataProductCollection

class AgStkRfcmRadarTransceiverConfigurationCollection(IAgStkRfcmRadarTransceiverConfigurationCollection, SupportsDeleteCallback):
    """A collection of radar transceivers."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarTransceiverConfigurationCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmRadarTransceiverConfigurationCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmRadarTransceiverConfigurationCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarTransceiverConfigurationCollection, [IAgStkRfcmRadarTransceiverConfigurationCollection])

agcls.AgClassCatalog.add_catalog_entry((4790458976272477186, 15304866967432392352), AgStkRfcmRadarTransceiverConfigurationCollection)
agcls.AgTypeNameMap["AgStkRfcmRadarTransceiverConfigurationCollection"] = AgStkRfcmRadarTransceiverConfigurationCollection

class AgStkRfcmAnalysisConfiguration(IAgStkRfcmAnalysisConfiguration, SupportsDeleteCallback):
    """The configuration for an analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmAnalysisConfiguration."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisConfiguration.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisConfiguration._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmAnalysisConfiguration, [IAgStkRfcmAnalysisConfiguration])

agcls.AgClassCatalog.add_catalog_entry((5392730798104370011, 563428922600983438), AgStkRfcmAnalysisConfiguration)
agcls.AgTypeNameMap["AgStkRfcmAnalysisConfiguration"] = AgStkRfcmAnalysisConfiguration

class AgStkRfcmCommunicationsAnalysisConfigurationModel(IAgStkRfcmAnalysisConfigurationModel, IAgStkRfcmCommunicationsAnalysisConfigurationModel, SupportsDeleteCallback):
    """The analysis configuration model for a communications analysis. This contains a collection of the transceiver configurations belonging to the communications analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmCommunicationsAnalysisConfigurationModel."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisConfigurationModel.__init__(self, sourceObject)
        IAgStkRfcmCommunicationsAnalysisConfigurationModel.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisConfigurationModel._private_init(self, intf)
        IAgStkRfcmCommunicationsAnalysisConfigurationModel._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmCommunicationsAnalysisConfigurationModel, [IAgStkRfcmAnalysisConfigurationModel, IAgStkRfcmCommunicationsAnalysisConfigurationModel])

agcls.AgClassCatalog.add_catalog_entry((5515277576377628430, 13436450372685581228), AgStkRfcmCommunicationsAnalysisConfigurationModel)
agcls.AgTypeNameMap["AgStkRfcmCommunicationsAnalysisConfigurationModel"] = AgStkRfcmCommunicationsAnalysisConfigurationModel

class AgStkRfcmRadarISarAnalysisConfigurationModel(IAgStkRfcmAnalysisConfigurationModel, IAgStkRfcmRadarAnalysisConfigurationModel, IAgStkRfcmRadarISarAnalysisConfigurationModel, SupportsDeleteCallback):
    """The analysis configuration model for an ISar analysis. This contains a collection of the transceiver configurations belonging to the ISar analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarISarAnalysisConfigurationModel."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisConfigurationModel.__init__(self, sourceObject)
        IAgStkRfcmRadarAnalysisConfigurationModel.__init__(self, sourceObject)
        IAgStkRfcmRadarISarAnalysisConfigurationModel.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisConfigurationModel._private_init(self, intf)
        IAgStkRfcmRadarAnalysisConfigurationModel._private_init(self, intf)
        IAgStkRfcmRadarISarAnalysisConfigurationModel._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarISarAnalysisConfigurationModel, [IAgStkRfcmAnalysisConfigurationModel, IAgStkRfcmRadarAnalysisConfigurationModel, IAgStkRfcmRadarISarAnalysisConfigurationModel])

agcls.AgClassCatalog.add_catalog_entry((5228864121001253272, 11476005751415570308), AgStkRfcmRadarISarAnalysisConfigurationModel)
agcls.AgTypeNameMap["AgStkRfcmRadarISarAnalysisConfigurationModel"] = AgStkRfcmRadarISarAnalysisConfigurationModel

class AgStkRfcmRadarSarAnalysisConfigurationModel(IAgStkRfcmAnalysisConfigurationModel, IAgStkRfcmRadarAnalysisConfigurationModel, IAgStkRfcmRadarSarAnalysisConfigurationModel, SupportsDeleteCallback):
    """The analysis configuration model for a Sar analysis. This contains a collection of the transceiver configurations belonging to the Sar analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarSarAnalysisConfigurationModel."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisConfigurationModel.__init__(self, sourceObject)
        IAgStkRfcmRadarAnalysisConfigurationModel.__init__(self, sourceObject)
        IAgStkRfcmRadarSarAnalysisConfigurationModel.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisConfigurationModel._private_init(self, intf)
        IAgStkRfcmRadarAnalysisConfigurationModel._private_init(self, intf)
        IAgStkRfcmRadarSarAnalysisConfigurationModel._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarSarAnalysisConfigurationModel, [IAgStkRfcmAnalysisConfigurationModel, IAgStkRfcmRadarAnalysisConfigurationModel, IAgStkRfcmRadarSarAnalysisConfigurationModel])

agcls.AgClassCatalog.add_catalog_entry((5764377955799592933, 16878723110774774148), AgStkRfcmRadarSarAnalysisConfigurationModel)
agcls.AgTypeNameMap["AgStkRfcmRadarSarAnalysisConfigurationModel"] = AgStkRfcmRadarSarAnalysisConfigurationModel

class AgStkRfcmTransceiverCollection(IAgStkRfcmTransceiverCollection, SupportsDeleteCallback):
    """A collection of transceiver objects."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmTransceiverCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmTransceiverCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmTransceiverCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmTransceiverCollection, [IAgStkRfcmTransceiverCollection])

agcls.AgClassCatalog.add_catalog_entry((5274798942248124582, 15790306252761209771), AgStkRfcmTransceiverCollection)
agcls.AgTypeNameMap["AgStkRfcmTransceiverCollection"] = AgStkRfcmTransceiverCollection

class AgStkRfcmFacetTilesetCollection(IAgStkRfcmFacetTilesetCollection, SupportsDeleteCallback):
    """A collection of facet tilesets."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmFacetTilesetCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmFacetTilesetCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmFacetTilesetCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmFacetTilesetCollection, [IAgStkRfcmFacetTilesetCollection])

agcls.AgClassCatalog.add_catalog_entry((5307708137821167772, 1526680685227976082), AgStkRfcmFacetTilesetCollection)
agcls.AgTypeNameMap["AgStkRfcmFacetTilesetCollection"] = AgStkRfcmFacetTilesetCollection

class AgStkRfcmSceneContributor(IAgStkRfcmSceneContributor, SupportsDeleteCallback):
    """A scene contributor object."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmSceneContributor."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmSceneContributor.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmSceneContributor._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmSceneContributor, [IAgStkRfcmSceneContributor])

agcls.AgClassCatalog.add_catalog_entry((4973272663297336587, 5054245476557569700), AgStkRfcmSceneContributor)
agcls.AgTypeNameMap["AgStkRfcmSceneContributor"] = AgStkRfcmSceneContributor

class AgStkRfcmSceneContributorCollection(IAgStkRfcmSceneContributorCollection, SupportsDeleteCallback):
    """A collection of scene contributor objects."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmSceneContributorCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmSceneContributorCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmSceneContributorCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmSceneContributorCollection, [IAgStkRfcmSceneContributorCollection])

agcls.AgClassCatalog.add_catalog_entry((5079782350604257666, 16703292362421634220), AgStkRfcmSceneContributorCollection)
agcls.AgTypeNameMap["AgStkRfcmSceneContributorCollection"] = AgStkRfcmSceneContributorCollection

class AgStkRfcmRadarTargetCollection(IAgStkRfcmSceneContributorCollection, SupportsDeleteCallback):
    """A collection of radar target objects."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarTargetCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmSceneContributorCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmSceneContributorCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarTargetCollection, [IAgStkRfcmSceneContributorCollection])

agcls.AgClassCatalog.add_catalog_entry((5310760862917692294, 11829976016985872805), AgStkRfcmRadarTargetCollection)
agcls.AgTypeNameMap["AgStkRfcmRadarTargetCollection"] = AgStkRfcmRadarTargetCollection

class AgStkRfcmRadarSarImageLocation(IAgStkRfcmRadarSarImageLocation, SupportsDeleteCallback):
    """The image location information for use by a range doppler Sar analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarSarImageLocation."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmRadarSarImageLocation.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmRadarSarImageLocation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarSarImageLocation, [IAgStkRfcmRadarSarImageLocation])

agcls.AgClassCatalog.add_catalog_entry((5444737755923510910, 18321320075764662437), AgStkRfcmRadarSarImageLocation)
agcls.AgTypeNameMap["AgStkRfcmRadarSarImageLocation"] = AgStkRfcmRadarSarImageLocation

class AgStkRfcmRadarSarImageLocationCollection(IAgStkRfcmRadarSarImageLocationCollection, SupportsDeleteCallback):
    """A collection of image location information."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarSarImageLocationCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmRadarSarImageLocationCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmRadarSarImageLocationCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarSarImageLocationCollection, [IAgStkRfcmRadarSarImageLocationCollection])

agcls.AgClassCatalog.add_catalog_entry((4952796876820433574, 17254855614936067770), AgStkRfcmRadarSarImageLocationCollection)
agcls.AgTypeNameMap["AgStkRfcmRadarSarImageLocationCollection"] = AgStkRfcmRadarSarImageLocationCollection

class AgStkRfcmCommunicationsTransceiverConfigurationCollection(IAgStkRfcmCommunicationsTransceiverConfigurationCollection, SupportsDeleteCallback):
    """A collection of communication transceivers."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmCommunicationsTransceiverConfigurationCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmCommunicationsTransceiverConfigurationCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmCommunicationsTransceiverConfigurationCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmCommunicationsTransceiverConfigurationCollection, [IAgStkRfcmCommunicationsTransceiverConfigurationCollection])

agcls.AgClassCatalog.add_catalog_entry((4918177005773267776, 5330117875639860627), AgStkRfcmCommunicationsTransceiverConfigurationCollection)
agcls.AgTypeNameMap["AgStkRfcmCommunicationsTransceiverConfigurationCollection"] = AgStkRfcmCommunicationsTransceiverConfigurationCollection

class AgStkRfcmAnalysisConfigurationCollection(IAgStkRfcmAnalysisConfigurationCollection, SupportsDeleteCallback):
    """A collection of analysis configurations."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmAnalysisConfigurationCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisConfigurationCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisConfigurationCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmAnalysisConfigurationCollection, [IAgStkRfcmAnalysisConfigurationCollection])

agcls.AgClassCatalog.add_catalog_entry((4928253720090755449, 12599536154964304772), AgStkRfcmAnalysisConfigurationCollection)
agcls.AgTypeNameMap["AgStkRfcmAnalysisConfigurationCollection"] = AgStkRfcmAnalysisConfigurationCollection

class AgStkRfcmComputeOptions(IAgStkRfcmComputeOptions, SupportsDeleteCallback):
    """The options for computing RF Channel Modeler."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmComputeOptions."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmComputeOptions.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmComputeOptions._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmComputeOptions, [IAgStkRfcmComputeOptions])

agcls.AgClassCatalog.add_catalog_entry((5519048876673409941, 3923537089545973176), AgStkRfcmComputeOptions)
agcls.AgTypeNameMap["AgStkRfcmComputeOptions"] = AgStkRfcmComputeOptions

class AgStkRFChannelModeler(IAgStkRFChannelModeler, SupportsDeleteCallback):
    """The main RF Channel Modeler object."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRFChannelModeler."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRFChannelModeler.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRFChannelModeler._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRFChannelModeler, [IAgStkRFChannelModeler])

agcls.AgClassCatalog.add_catalog_entry((5711907369548252697, 4711585359054994589), AgStkRFChannelModeler)
agcls.AgTypeNameMap["AgStkRFChannelModeler"] = AgStkRFChannelModeler

class AgStkRfcmCommunicationsTransceiverModel(IAgStkRfcmTransceiverModel, IAgStkRfcmCommunicationsTransceiverModel, SupportsDeleteCallback):
    """The model for a communications transceiver."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmCommunicationsTransceiverModel."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmTransceiverModel.__init__(self, sourceObject)
        IAgStkRfcmCommunicationsTransceiverModel.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmTransceiverModel._private_init(self, intf)
        IAgStkRfcmCommunicationsTransceiverModel._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmCommunicationsTransceiverModel, [IAgStkRfcmTransceiverModel, IAgStkRfcmCommunicationsTransceiverModel])

agcls.AgClassCatalog.add_catalog_entry((5460540020574842430, 12586276357591230339), AgStkRfcmCommunicationsTransceiverModel)
agcls.AgTypeNameMap["AgStkRfcmCommunicationsTransceiverModel"] = AgStkRfcmCommunicationsTransceiverModel

class AgStkRfcmRadarTransceiverModel(IAgStkRfcmTransceiverModel, IAgStkRfcmRadarTransceiverModel, SupportsDeleteCallback):
    """The model for a radar transceiver."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarTransceiverModel."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmTransceiverModel.__init__(self, sourceObject)
        IAgStkRfcmRadarTransceiverModel.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmTransceiverModel._private_init(self, intf)
        IAgStkRfcmRadarTransceiverModel._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarTransceiverModel, [IAgStkRfcmTransceiverModel, IAgStkRfcmRadarTransceiverModel])

agcls.AgClassCatalog.add_catalog_entry((5535067053932425138, 5002300541366460048), AgStkRfcmRadarTransceiverModel)
agcls.AgTypeNameMap["AgStkRfcmRadarTransceiverModel"] = AgStkRfcmRadarTransceiverModel

class AgStkRfcmRangeDopplerResponse(IAgStkRfcmResponse, IAgStkRfcmRangeDopplerResponse, SupportsDeleteCallback):
    """The response data and properties for a range doppler channel characterization."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRangeDopplerResponse."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmResponse.__init__(self, sourceObject)
        IAgStkRfcmRangeDopplerResponse.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmResponse._private_init(self, intf)
        IAgStkRfcmRangeDopplerResponse._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRangeDopplerResponse, [IAgStkRfcmResponse, IAgStkRfcmRangeDopplerResponse])

agcls.AgClassCatalog.add_catalog_entry((5543401830740382270, 3545126179169781131), AgStkRfcmRangeDopplerResponse)
agcls.AgTypeNameMap["AgStkRfcmRangeDopplerResponse"] = AgStkRfcmRangeDopplerResponse

class AgStkRfcmFrequencyPulseResponse(IAgStkRfcmResponse, IAgStkRfcmFrequencyPulseResponse, SupportsDeleteCallback):
    """The response data and properties for a frequency pulse channel characterization."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmFrequencyPulseResponse."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmResponse.__init__(self, sourceObject)
        IAgStkRfcmFrequencyPulseResponse.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmResponse._private_init(self, intf)
        IAgStkRfcmFrequencyPulseResponse._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmFrequencyPulseResponse, [IAgStkRfcmResponse, IAgStkRfcmFrequencyPulseResponse])

agcls.AgClassCatalog.add_catalog_entry((5371909063848130331, 188560514196819341), AgStkRfcmFrequencyPulseResponse)
agcls.AgTypeNameMap["AgStkRfcmFrequencyPulseResponse"] = AgStkRfcmFrequencyPulseResponse

class AgStkRfcmAnalysisLink(IAgStkRfcmAnalysisLink, SupportsDeleteCallback):
    """A transceiver link for an analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmAnalysisLink."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisLink.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisLink._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmAnalysisLink, [IAgStkRfcmAnalysisLink])

agcls.AgClassCatalog.add_catalog_entry((5035691807805684055, 1039028034256790706), AgStkRfcmAnalysisLink)
agcls.AgTypeNameMap["AgStkRfcmAnalysisLink"] = AgStkRfcmAnalysisLink

class AgStkRfcmRadarSarAnalysisLink(IAgStkRfcmAnalysisLink, IAgStkRfcmRadarSarAnalysisLink, SupportsDeleteCallback):
    """A transceiver link for a Sar analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarSarAnalysisLink."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisLink.__init__(self, sourceObject)
        IAgStkRfcmRadarSarAnalysisLink.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisLink._private_init(self, intf)
        IAgStkRfcmRadarSarAnalysisLink._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarSarAnalysisLink, [IAgStkRfcmAnalysisLink, IAgStkRfcmRadarSarAnalysisLink])

agcls.AgClassCatalog.add_catalog_entry((5067638514630488731, 265473950441651589), AgStkRfcmRadarSarAnalysisLink)
agcls.AgTypeNameMap["AgStkRfcmRadarSarAnalysisLink"] = AgStkRfcmRadarSarAnalysisLink

class AgStkRfcmRadarISarAnalysisLink(IAgStkRfcmAnalysisLink, IAgStkRfcmRadarISarAnalysisLink, SupportsDeleteCallback):
    """A transceiver link for an ISar analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmRadarISarAnalysisLink."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisLink.__init__(self, sourceObject)
        IAgStkRfcmRadarISarAnalysisLink.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisLink._private_init(self, intf)
        IAgStkRfcmRadarISarAnalysisLink._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmRadarISarAnalysisLink, [IAgStkRfcmAnalysisLink, IAgStkRfcmRadarISarAnalysisLink])

agcls.AgClassCatalog.add_catalog_entry((5167524712546203694, 8283996936521855423), AgStkRfcmRadarISarAnalysisLink)
agcls.AgTypeNameMap["AgStkRfcmRadarISarAnalysisLink"] = AgStkRfcmRadarISarAnalysisLink

class AgStkRfcmAnalysisLinkCollection(IAgStkRfcmAnalysisLinkCollection, SupportsDeleteCallback):
    """A collection of links between transceivers."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmAnalysisLinkCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysisLinkCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysisLinkCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmAnalysisLinkCollection, [IAgStkRfcmAnalysisLinkCollection])

agcls.AgClassCatalog.add_catalog_entry((5590692282349627472, 14211210503561071262), AgStkRfcmAnalysisLinkCollection)
agcls.AgTypeNameMap["AgStkRfcmAnalysisLinkCollection"] = AgStkRfcmAnalysisLinkCollection

class AgStkRfcmAnalysis(IAgStkRfcmAnalysis, SupportsDeleteCallback):
    """An RF Channel Modeler analysis."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmAnalysis."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmAnalysis.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmAnalysis._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmAnalysis, [IAgStkRfcmAnalysis])

agcls.AgClassCatalog.add_catalog_entry((4803344109459367919, 15926375216492296123), AgStkRfcmAnalysis)
agcls.AgTypeNameMap["AgStkRfcmAnalysis"] = AgStkRfcmAnalysis

class AgStkRfcmGpuProperties(IAgStkRfcmGpuProperties, SupportsDeleteCallback):
    """The properties of a GPU pertaining to RF Channel Modeler."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRfcmGpuProperties."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRfcmGpuProperties.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRfcmGpuProperties._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRfcmGpuProperties, [IAgStkRfcmGpuProperties])

agcls.AgClassCatalog.add_catalog_entry((4745059216132635585, 4320058157532729488), AgStkRfcmGpuProperties)
agcls.AgTypeNameMap["AgStkRfcmGpuProperties"] = AgStkRfcmGpuProperties


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
