################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgAvtrBasicManeuverMATLABFactory", "AgAvtrStrategyMATLAB3DGuidance", "AgAvtrStrategyMATLABFull3D", "AgAvtrStrategyMATLABNav", 
"AgAvtrStrategyMATLABProfile", "IAgAvtrStrategyMATLAB3DGuidance", "IAgAvtrStrategyMATLABFull3D", "IAgAvtrStrategyMATLABNav", 
"IAgAvtrStrategyMATLABProfile"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ...internal  import comutil          as agcom
from ...internal  import coclassutil      as agcls
from ...internal  import marshall         as agmarshall
from ...internal  import dataanalysisutil as agdata
from ...utilities import colors           as agcolor
from ...internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ...internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ...internal.eventutil   import *
from ...utilities.exceptions import *

from ...stkobjects.aviator import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class IAgAvtrStrategyMATLABNav(object):
    """Interface used to access options for a MATLAB - Horizontal Plane Strategy of a Basic Maneuver Procedure."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_FunctionName_method_offset = 1
    _set_FunctionName_method_offset = 2
    _IsFunctionPathValid_method_offset = 3
    _get_CheckForErrors_method_offset = 4
    _set_CheckForErrors_method_offset = 5
    _get_DisplayOutput_method_offset = 6
    _set_DisplayOutput_method_offset = 7
    _metadata = {
        "iid_data" : (5227863432379747556, 7965596508726907792),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAvtrStrategyMATLABNav."""
        initialize_from_source_object(self, sourceObject, IAgAvtrStrategyMATLABNav)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAvtrStrategyMATLABNav)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAvtrStrategyMATLABNav, None)
    
    _get_FunctionName_metadata = { "offset" : _get_FunctionName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FunctionName(self) -> str:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLABNav._metadata, IAgAvtrStrategyMATLABNav._get_FunctionName_metadata)

    _set_FunctionName_metadata = { "offset" : _set_FunctionName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FunctionName.setter
    def FunctionName(self, newVal:str) -> None:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLABNav._metadata, IAgAvtrStrategyMATLABNav._set_FunctionName_metadata, newVal)

    _IsFunctionPathValid_metadata = { "offset" : _IsFunctionPathValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def IsFunctionPathValid(self) -> bool:
        """Check if the MATLAB function path is valid."""
        return self._intf.invoke(IAgAvtrStrategyMATLABNav._metadata, IAgAvtrStrategyMATLABNav._IsFunctionPathValid_metadata, OutArg())

    _get_CheckForErrors_metadata = { "offset" : _get_CheckForErrors_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def CheckForErrors(self) -> bool:
        """Gets or sets the option to check the function for errors."""
        return self._intf.get_property(IAgAvtrStrategyMATLABNav._metadata, IAgAvtrStrategyMATLABNav._get_CheckForErrors_metadata)

    _set_CheckForErrors_metadata = { "offset" : _set_CheckForErrors_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @CheckForErrors.setter
    def CheckForErrors(self, newVal:bool) -> None:
        """Gets or sets the option to check the function for errors."""
        return self._intf.set_property(IAgAvtrStrategyMATLABNav._metadata, IAgAvtrStrategyMATLABNav._set_CheckForErrors_metadata, newVal)

    _get_DisplayOutput_metadata = { "offset" : _get_DisplayOutput_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DisplayOutput(self) -> bool:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLABNav._metadata, IAgAvtrStrategyMATLABNav._get_DisplayOutput_metadata)

    _set_DisplayOutput_metadata = { "offset" : _set_DisplayOutput_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DisplayOutput.setter
    def DisplayOutput(self, newVal:bool) -> None:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLABNav._metadata, IAgAvtrStrategyMATLABNav._set_DisplayOutput_metadata, newVal)

    _property_names[FunctionName] = "FunctionName"
    _property_names[CheckForErrors] = "CheckForErrors"
    _property_names[DisplayOutput] = "DisplayOutput"


agcls.AgClassCatalog.add_catalog_entry((5227863432379747556, 7965596508726907792), IAgAvtrStrategyMATLABNav)
agcls.AgTypeNameMap["IAgAvtrStrategyMATLABNav"] = IAgAvtrStrategyMATLABNav

class IAgAvtrStrategyMATLABProfile(object):
    """Interface used to access options for a MATLAB - Vertical Plane Strategy of a Basic Maneuver Procedure."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_FunctionName_method_offset = 1
    _set_FunctionName_method_offset = 2
    _IsFunctionPathValid_method_offset = 3
    _get_CheckForErrors_method_offset = 4
    _set_CheckForErrors_method_offset = 5
    _get_DisplayOutput_method_offset = 6
    _set_DisplayOutput_method_offset = 7
    _metadata = {
        "iid_data" : (5762811461223097488, 815303183833033109),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAvtrStrategyMATLABProfile."""
        initialize_from_source_object(self, sourceObject, IAgAvtrStrategyMATLABProfile)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAvtrStrategyMATLABProfile)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAvtrStrategyMATLABProfile, None)
    
    _get_FunctionName_metadata = { "offset" : _get_FunctionName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FunctionName(self) -> str:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLABProfile._metadata, IAgAvtrStrategyMATLABProfile._get_FunctionName_metadata)

    _set_FunctionName_metadata = { "offset" : _set_FunctionName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FunctionName.setter
    def FunctionName(self, newVal:str) -> None:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLABProfile._metadata, IAgAvtrStrategyMATLABProfile._set_FunctionName_metadata, newVal)

    _IsFunctionPathValid_metadata = { "offset" : _IsFunctionPathValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def IsFunctionPathValid(self) -> bool:
        """Check if the MATLAB function path is valid."""
        return self._intf.invoke(IAgAvtrStrategyMATLABProfile._metadata, IAgAvtrStrategyMATLABProfile._IsFunctionPathValid_metadata, OutArg())

    _get_CheckForErrors_metadata = { "offset" : _get_CheckForErrors_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def CheckForErrors(self) -> bool:
        """Gets or sets the option to check the function for errors."""
        return self._intf.get_property(IAgAvtrStrategyMATLABProfile._metadata, IAgAvtrStrategyMATLABProfile._get_CheckForErrors_metadata)

    _set_CheckForErrors_metadata = { "offset" : _set_CheckForErrors_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @CheckForErrors.setter
    def CheckForErrors(self, newVal:bool) -> None:
        """Gets or sets the option to check the function for errors."""
        return self._intf.set_property(IAgAvtrStrategyMATLABProfile._metadata, IAgAvtrStrategyMATLABProfile._set_CheckForErrors_metadata, newVal)

    _get_DisplayOutput_metadata = { "offset" : _get_DisplayOutput_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DisplayOutput(self) -> bool:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLABProfile._metadata, IAgAvtrStrategyMATLABProfile._get_DisplayOutput_metadata)

    _set_DisplayOutput_metadata = { "offset" : _set_DisplayOutput_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DisplayOutput.setter
    def DisplayOutput(self, newVal:bool) -> None:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLABProfile._metadata, IAgAvtrStrategyMATLABProfile._set_DisplayOutput_metadata, newVal)

    _property_names[FunctionName] = "FunctionName"
    _property_names[CheckForErrors] = "CheckForErrors"
    _property_names[DisplayOutput] = "DisplayOutput"


agcls.AgClassCatalog.add_catalog_entry((5762811461223097488, 815303183833033109), IAgAvtrStrategyMATLABProfile)
agcls.AgTypeNameMap["IAgAvtrStrategyMATLABProfile"] = IAgAvtrStrategyMATLABProfile

class IAgAvtrStrategyMATLABFull3D(object):
    """Interface used to access options for a MATLAB - Full 3D Strategy of a Basic Maneuver Procedure."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_FunctionName_method_offset = 1
    _set_FunctionName_method_offset = 2
    _IsFunctionPathValid_method_offset = 3
    _get_CheckForErrors_method_offset = 4
    _set_CheckForErrors_method_offset = 5
    _get_DisplayOutput_method_offset = 6
    _set_DisplayOutput_method_offset = 7
    _metadata = {
        "iid_data" : (4991766284198429486, 11343135184924199837),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAvtrStrategyMATLABFull3D."""
        initialize_from_source_object(self, sourceObject, IAgAvtrStrategyMATLABFull3D)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAvtrStrategyMATLABFull3D)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAvtrStrategyMATLABFull3D, None)
    
    _get_FunctionName_metadata = { "offset" : _get_FunctionName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FunctionName(self) -> str:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLABFull3D._metadata, IAgAvtrStrategyMATLABFull3D._get_FunctionName_metadata)

    _set_FunctionName_metadata = { "offset" : _set_FunctionName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FunctionName.setter
    def FunctionName(self, newVal:str) -> None:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLABFull3D._metadata, IAgAvtrStrategyMATLABFull3D._set_FunctionName_metadata, newVal)

    _IsFunctionPathValid_metadata = { "offset" : _IsFunctionPathValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def IsFunctionPathValid(self) -> bool:
        """Check if the MATLAB function path is valid."""
        return self._intf.invoke(IAgAvtrStrategyMATLABFull3D._metadata, IAgAvtrStrategyMATLABFull3D._IsFunctionPathValid_metadata, OutArg())

    _get_CheckForErrors_metadata = { "offset" : _get_CheckForErrors_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def CheckForErrors(self) -> bool:
        """Gets or sets the option to check the function for errors."""
        return self._intf.get_property(IAgAvtrStrategyMATLABFull3D._metadata, IAgAvtrStrategyMATLABFull3D._get_CheckForErrors_metadata)

    _set_CheckForErrors_metadata = { "offset" : _set_CheckForErrors_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @CheckForErrors.setter
    def CheckForErrors(self, newVal:bool) -> None:
        """Gets or sets the option to check the function for errors."""
        return self._intf.set_property(IAgAvtrStrategyMATLABFull3D._metadata, IAgAvtrStrategyMATLABFull3D._set_CheckForErrors_metadata, newVal)

    _get_DisplayOutput_metadata = { "offset" : _get_DisplayOutput_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DisplayOutput(self) -> bool:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLABFull3D._metadata, IAgAvtrStrategyMATLABFull3D._get_DisplayOutput_metadata)

    _set_DisplayOutput_metadata = { "offset" : _set_DisplayOutput_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DisplayOutput.setter
    def DisplayOutput(self, newVal:bool) -> None:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLABFull3D._metadata, IAgAvtrStrategyMATLABFull3D._set_DisplayOutput_metadata, newVal)

    _property_names[FunctionName] = "FunctionName"
    _property_names[CheckForErrors] = "CheckForErrors"
    _property_names[DisplayOutput] = "DisplayOutput"


agcls.AgClassCatalog.add_catalog_entry((4991766284198429486, 11343135184924199837), IAgAvtrStrategyMATLABFull3D)
agcls.AgTypeNameMap["IAgAvtrStrategyMATLABFull3D"] = IAgAvtrStrategyMATLABFull3D

class IAgAvtrStrategyMATLAB3DGuidance(object):
    """Interface used to access options for a MATLAB - 3D Guidance Strategy of a Basic Maneuver Procedure."""

    _num_methods = 29
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_TargetName_method_offset = 1
    _set_TargetName_method_offset = 2
    _get_ValidTargetNames_method_offset = 3
    _get_TargetResolution_method_offset = 4
    _set_TargetResolution_method_offset = 5
    _get_UseStopTimeToGo_method_offset = 6
    _get_StopTimeToGo_method_offset = 7
    _SetStopTimeToGo_method_offset = 8
    _get_UseStopSlantRange_method_offset = 9
    _get_StopSlantRange_method_offset = 10
    _SetStopSlantRange_method_offset = 11
    _get_FunctionName_method_offset = 12
    _set_FunctionName_method_offset = 13
    _IsFunctionPathValid_method_offset = 14
    _get_CheckForErrors_method_offset = 15
    _set_CheckForErrors_method_offset = 16
    _get_DisplayOutput_method_offset = 17
    _set_DisplayOutput_method_offset = 18
    _get_ClosureMode_method_offset = 19
    _set_ClosureMode_method_offset = 20
    _get_HOBSMaxAngle_method_offset = 21
    _set_HOBSMaxAngle_method_offset = 22
    _get_HOBSAngleTol_method_offset = 23
    _set_HOBSAngleTol_method_offset = 24
    _get_ComputeTASDot_method_offset = 25
    _set_ComputeTASDot_method_offset = 26
    _get_AirspeedOptions_method_offset = 27
    _get_PosVelStrategies_method_offset = 28
    _CancelTgtPosVel_method_offset = 29
    _metadata = {
        "iid_data" : (5207808632699689454, 11389872158525712815),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAvtrStrategyMATLAB3DGuidance."""
        initialize_from_source_object(self, sourceObject, IAgAvtrStrategyMATLAB3DGuidance)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAvtrStrategyMATLAB3DGuidance)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAvtrStrategyMATLAB3DGuidance, None)
    
    _get_TargetName_metadata = { "offset" : _get_TargetName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def TargetName(self) -> str:
        """Gets or sets the target name."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_TargetName_metadata)

    _set_TargetName_metadata = { "offset" : _set_TargetName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @TargetName.setter
    def TargetName(self, newVal:str) -> None:
        """Gets or sets the target name."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_TargetName_metadata, newVal)

    _get_ValidTargetNames_metadata = { "offset" : _get_ValidTargetNames_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ValidTargetNames(self) -> list:
        """Returns the valid target names."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_ValidTargetNames_metadata)

    _get_TargetResolution_metadata = { "offset" : _get_TargetResolution_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TargetResolution(self) -> float:
        """Gets or sets the target position/velocity sampling resolution."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_TargetResolution_metadata)

    _set_TargetResolution_metadata = { "offset" : _set_TargetResolution_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @TargetResolution.setter
    def TargetResolution(self, newVal:float) -> None:
        """Gets or sets the target position/velocity sampling resolution."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_TargetResolution_metadata, newVal)

    _get_UseStopTimeToGo_metadata = { "offset" : _get_UseStopTimeToGo_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UseStopTimeToGo(self) -> bool:
        """Get the option to specify a time to go stopping condition."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_UseStopTimeToGo_metadata)

    _get_StopTimeToGo_metadata = { "offset" : _get_StopTimeToGo_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def StopTimeToGo(self) -> float:
        """Get the stop time from the target at which the maneuver will stop."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_StopTimeToGo_metadata)

    _SetStopTimeToGo_metadata = { "offset" : _SetStopTimeToGo_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL, agcom.DOUBLE,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg, agmarshall.DOUBLE_arg,) }
    def SetStopTimeToGo(self, enable:bool, time:float) -> None:
        """Set the option to use the stop time from target stopping condition and set the according value."""
        return self._intf.invoke(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._SetStopTimeToGo_metadata, enable, time)

    _get_UseStopSlantRange_metadata = { "offset" : _get_UseStopSlantRange_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UseStopSlantRange(self) -> bool:
        """Get the option to specify a range from target stopping condition."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_UseStopSlantRange_metadata)

    _get_StopSlantRange_metadata = { "offset" : _get_StopSlantRange_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def StopSlantRange(self) -> float:
        """Get the range from the target at which the maneuver will stop."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_StopSlantRange_metadata)

    _SetStopSlantRange_metadata = { "offset" : _SetStopSlantRange_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL, agcom.DOUBLE,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg, agmarshall.DOUBLE_arg,) }
    def SetStopSlantRange(self, enable:bool, range:float) -> None:
        """Set the option to use the stop slant range stopping condition and set the according value."""
        return self._intf.invoke(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._SetStopSlantRange_metadata, enable, range)

    _get_FunctionName_metadata = { "offset" : _get_FunctionName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FunctionName(self) -> str:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_FunctionName_metadata)

    _set_FunctionName_metadata = { "offset" : _set_FunctionName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FunctionName.setter
    def FunctionName(self, newVal:str) -> None:
        """Gets or sets the name of the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_FunctionName_metadata, newVal)

    _IsFunctionPathValid_metadata = { "offset" : _IsFunctionPathValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def IsFunctionPathValid(self) -> bool:
        """Check if the MATLAB function path is valid."""
        return self._intf.invoke(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._IsFunctionPathValid_metadata, OutArg())

    _get_CheckForErrors_metadata = { "offset" : _get_CheckForErrors_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def CheckForErrors(self) -> bool:
        """Gets or sets the option to check the function for errors."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_CheckForErrors_metadata)

    _set_CheckForErrors_metadata = { "offset" : _set_CheckForErrors_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @CheckForErrors.setter
    def CheckForErrors(self, newVal:bool) -> None:
        """Gets or sets the option to check the function for errors."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_CheckForErrors_metadata, newVal)

    _get_DisplayOutput_metadata = { "offset" : _get_DisplayOutput_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DisplayOutput(self) -> bool:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_DisplayOutput_metadata)

    _set_DisplayOutput_metadata = { "offset" : _set_DisplayOutput_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DisplayOutput.setter
    def DisplayOutput(self, newVal:bool) -> None:
        """Gets or sets the option to display the output from the MATLAB function."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_DisplayOutput_metadata, newVal)

    _get_ClosureMode_metadata = { "offset" : _get_ClosureMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAvtrClosureMode),) }
    @property
    def ClosureMode(self) -> "AgEAvtrClosureMode":
        """Gets or sets the closure mode for the guidance strategy."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_ClosureMode_metadata)

    _set_ClosureMode_metadata = { "offset" : _set_ClosureMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAvtrClosureMode),) }
    @ClosureMode.setter
    def ClosureMode(self, newVal:"AgEAvtrClosureMode") -> None:
        """Gets or sets the closure mode for the guidance strategy."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_ClosureMode_metadata, newVal)

    _get_HOBSMaxAngle_metadata = { "offset" : _get_HOBSMaxAngle_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def HOBSMaxAngle(self) -> typing.Any:
        """Gets or sets the closure high off boresight max angle."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_HOBSMaxAngle_metadata)

    _set_HOBSMaxAngle_metadata = { "offset" : _set_HOBSMaxAngle_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @HOBSMaxAngle.setter
    def HOBSMaxAngle(self, newVal:typing.Any) -> None:
        """Gets or sets the closure high off boresight max angle."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_HOBSMaxAngle_metadata, newVal)

    _get_HOBSAngleTol_metadata = { "offset" : _get_HOBSAngleTol_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def HOBSAngleTol(self) -> typing.Any:
        """Gets or sets the closure high off boresight angle tolerance."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_HOBSAngleTol_metadata)

    _set_HOBSAngleTol_metadata = { "offset" : _set_HOBSAngleTol_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @HOBSAngleTol.setter
    def HOBSAngleTol(self, newVal:typing.Any) -> None:
        """Gets or sets the closure high off boresight angle tolerance."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_HOBSAngleTol_metadata, newVal)

    _get_ComputeTASDot_metadata = { "offset" : _get_ComputeTASDot_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def ComputeTASDot(self) -> bool:
        """Gets or sets the option to allow MATLAB to compute the true airspeed for the aircraft."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_ComputeTASDot_metadata)

    _set_ComputeTASDot_metadata = { "offset" : _set_ComputeTASDot_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @ComputeTASDot.setter
    def ComputeTASDot(self, newVal:bool) -> None:
        """Gets or sets the option to allow MATLAB to compute the true airspeed for the aircraft."""
        return self._intf.set_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._set_ComputeTASDot_metadata, newVal)

    _get_AirspeedOptions_metadata = { "offset" : _get_AirspeedOptions_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def AirspeedOptions(self) -> "IAgAvtrBasicManeuverAirspeedOptions":
        """Get the airspeed options."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_AirspeedOptions_metadata)

    _get_PosVelStrategies_metadata = { "offset" : _get_PosVelStrategies_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def PosVelStrategies(self) -> "IAgAvtrBasicManeuverTargetPosVel":
        """Get the position velocity strategies for MATLAB 3D Guidance."""
        return self._intf.get_property(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._get_PosVelStrategies_metadata)

    _CancelTgtPosVel_metadata = { "offset" : _CancelTgtPosVel_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def CancelTgtPosVel(self) -> None:
        """Cancel the position velocity strategies for MATLAB 3D Guidance."""
        return self._intf.invoke(IAgAvtrStrategyMATLAB3DGuidance._metadata, IAgAvtrStrategyMATLAB3DGuidance._CancelTgtPosVel_metadata, )

    _property_names[TargetName] = "TargetName"
    _property_names[ValidTargetNames] = "ValidTargetNames"
    _property_names[TargetResolution] = "TargetResolution"
    _property_names[UseStopTimeToGo] = "UseStopTimeToGo"
    _property_names[StopTimeToGo] = "StopTimeToGo"
    _property_names[UseStopSlantRange] = "UseStopSlantRange"
    _property_names[StopSlantRange] = "StopSlantRange"
    _property_names[FunctionName] = "FunctionName"
    _property_names[CheckForErrors] = "CheckForErrors"
    _property_names[DisplayOutput] = "DisplayOutput"
    _property_names[ClosureMode] = "ClosureMode"
    _property_names[HOBSMaxAngle] = "HOBSMaxAngle"
    _property_names[HOBSAngleTol] = "HOBSAngleTol"
    _property_names[ComputeTASDot] = "ComputeTASDot"
    _property_names[AirspeedOptions] = "AirspeedOptions"
    _property_names[PosVelStrategies] = "PosVelStrategies"


agcls.AgClassCatalog.add_catalog_entry((5207808632699689454, 11389872158525712815), IAgAvtrStrategyMATLAB3DGuidance)
agcls.AgTypeNameMap["IAgAvtrStrategyMATLAB3DGuidance"] = IAgAvtrStrategyMATLAB3DGuidance



class AgAvtrStrategyMATLABNav(IAgAvtrStrategyMATLABNav, IAgAvtrBasicManeuverStrategy, SupportsDeleteCallback):
    """Class defining the MATLAB - Horizontal Plane strategy for a basic maneuver procedure."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAvtrStrategyMATLABNav."""
        SupportsDeleteCallback.__init__(self)
        IAgAvtrStrategyMATLABNav.__init__(self, sourceObject)
        IAgAvtrBasicManeuverStrategy.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAvtrStrategyMATLABNav._private_init(self, intf)
        IAgAvtrBasicManeuverStrategy._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAvtrStrategyMATLABNav, [IAgAvtrStrategyMATLABNav, IAgAvtrBasicManeuverStrategy])

agcls.AgClassCatalog.add_catalog_entry((4922865625757889154, 4997589758508718220), AgAvtrStrategyMATLABNav)
agcls.AgTypeNameMap["AgAvtrStrategyMATLABNav"] = AgAvtrStrategyMATLABNav

class AgAvtrStrategyMATLABProfile(IAgAvtrStrategyMATLABProfile, IAgAvtrBasicManeuverStrategy, SupportsDeleteCallback):
    """Class defining the MATLAB - Vertical Plane strategy for a basic maneuver procedure."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAvtrStrategyMATLABProfile."""
        SupportsDeleteCallback.__init__(self)
        IAgAvtrStrategyMATLABProfile.__init__(self, sourceObject)
        IAgAvtrBasicManeuverStrategy.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAvtrStrategyMATLABProfile._private_init(self, intf)
        IAgAvtrBasicManeuverStrategy._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAvtrStrategyMATLABProfile, [IAgAvtrStrategyMATLABProfile, IAgAvtrBasicManeuverStrategy])

agcls.AgClassCatalog.add_catalog_entry((5431676618088683906, 7176732423655266234), AgAvtrStrategyMATLABProfile)
agcls.AgTypeNameMap["AgAvtrStrategyMATLABProfile"] = AgAvtrStrategyMATLABProfile

class AgAvtrStrategyMATLABFull3D(IAgAvtrStrategyMATLABFull3D, IAgAvtrBasicManeuverStrategy, SupportsDeleteCallback):
    """Class defining the MATLAB - Full 3D strategy for a basic maneuver procedure."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAvtrStrategyMATLABFull3D."""
        SupportsDeleteCallback.__init__(self)
        IAgAvtrStrategyMATLABFull3D.__init__(self, sourceObject)
        IAgAvtrBasicManeuverStrategy.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAvtrStrategyMATLABFull3D._private_init(self, intf)
        IAgAvtrBasicManeuverStrategy._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAvtrStrategyMATLABFull3D, [IAgAvtrStrategyMATLABFull3D, IAgAvtrBasicManeuverStrategy])

agcls.AgClassCatalog.add_catalog_entry((5699885202707284005, 15299874748251640476), AgAvtrStrategyMATLABFull3D)
agcls.AgTypeNameMap["AgAvtrStrategyMATLABFull3D"] = AgAvtrStrategyMATLABFull3D

class AgAvtrStrategyMATLAB3DGuidance(IAgAvtrStrategyMATLAB3DGuidance, IAgAvtrBasicManeuverStrategy, SupportsDeleteCallback):
    """Class defining the MATLAB - 3D Guidance strategy for a basic maneuver procedure."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAvtrStrategyMATLAB3DGuidance."""
        SupportsDeleteCallback.__init__(self)
        IAgAvtrStrategyMATLAB3DGuidance.__init__(self, sourceObject)
        IAgAvtrBasicManeuverStrategy.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAvtrStrategyMATLAB3DGuidance._private_init(self, intf)
        IAgAvtrBasicManeuverStrategy._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAvtrStrategyMATLAB3DGuidance, [IAgAvtrStrategyMATLAB3DGuidance, IAgAvtrBasicManeuverStrategy])

agcls.AgClassCatalog.add_catalog_entry((4932746689876178541, 12483900520759435676), AgAvtrStrategyMATLAB3DGuidance)
agcls.AgTypeNameMap["AgAvtrStrategyMATLAB3DGuidance"] = AgAvtrStrategyMATLAB3DGuidance

class AgAvtrBasicManeuverMATLABFactory(IAgAvtrAutomationStrategyFactory, SupportsDeleteCallback):
    """Class defining the factory to create the basic maneuver PropNav strategies."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAvtrBasicManeuverMATLABFactory."""
        SupportsDeleteCallback.__init__(self)
        IAgAvtrAutomationStrategyFactory.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAvtrAutomationStrategyFactory._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAvtrBasicManeuverMATLABFactory, [IAgAvtrAutomationStrategyFactory])

agcls.AgClassCatalog.add_catalog_entry((5583954005185604195, 6409795893672302240), AgAvtrBasicManeuverMATLABFactory)
agcls.AgTypeNameMap["AgAvtrBasicManeuverMATLABFactory"] = AgAvtrBasicManeuverMATLABFactory


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
