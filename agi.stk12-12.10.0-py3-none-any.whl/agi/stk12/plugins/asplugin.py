################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgAsEphemFileReaderPluginResultData", "AgAsEphemFileReaderPluginResultEphem", "AgAsEphemFileReaderPluginResultReg", 
"AgAsEphemFileReaderPluginResultVerify", "AgEAsCovRep", "AgEAsCovType", "AgEAsEphemFileDistanceUnit", "AgEAsEphemFileTimeUnit", 
"AgEAsEphemInterpolationMethod", "AgEAsPluginErrorCodes", "IAgAsEphemFileReaderPlugin", "IAgAsEphemFileReaderPluginResultData", 
"IAgAsEphemFileReaderPluginResultEphem", "IAgAsEphemFileReaderPluginResultReg", "IAgAsEphemFileReaderPluginResultVerify"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.attrautomation import *
from ..plugins.utplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEAsPluginErrorCodes(IntEnum):
    """Enumeration of AgAsPlugin General Error Codes"""
   
    eAstroPluginInternalFailure = (((1 << 31) | (4 << 16)) | 0x0001)
    """Plugin: An internal failure occurred."""
    eEphemerisReaderBadFormat = (((1 << 31) | (4 << 16)) | 0x0002)
    """The specified format is invalid (either containing spaces or matching an existing format)."""
    eAstroPluginBadCentralBody = (((1 << 31) | (4 << 16)) | 0x0003)
    """The central body name is invalid."""
    eEphemerisReaderBadCoordinateSystem = (((1 << 31) | (4 << 16)) | 0x0004)
    """The coordinate system is unrecognized."""
    eEphemerisReaderBadInterpolationMethod = (((1 << 31) | (4 << 16)) | 0x0005)
    """The interpolation method is invalid."""
    eEphemerisReaderBadInterpolationOrder = (((1 << 31) | (4 << 16)) | 0x0006)
    """The interpolation order is invalid."""
    eEphemerisReaderBadCovarianceRepresentation = (((1 << 31) | (4 << 16)) | 0x0008)
    """The covariance representation is invalid."""
    eEphemerisReaderBadVopMu = (((1 << 31) | (4 << 16)) | 0x0007)
    """The VopMu value is invalid. Must be positive."""
    eEphemerisReaderBadDistanceUnit = (((1 << 31) | (4 << 16)) | 0x0008)
    """The distance unit is invalid."""
    eEphemerisReaderBadTimeUnit = (((1 << 31) | (4 << 16)) | 0x0009)
    """The time unit is invalid."""
    eAstroPluginBadDouble = (((1 << 31) | (4 << 16)) | 0x0010)
    """The double is not a finite value (i.e., infinite or indeterminant)."""
    eEphemerisReaderBadCovarianceArray = (((1 << 31) | (4 << 16)) | 0x0011)
    """The covariance array does not contain the required number of entries (6 or 21)."""

AgEAsPluginErrorCodes.eAstroPluginInternalFailure.__doc__ = "Plugin: An internal failure occurred."
AgEAsPluginErrorCodes.eEphemerisReaderBadFormat.__doc__ = "The specified format is invalid (either containing spaces or matching an existing format)."
AgEAsPluginErrorCodes.eAstroPluginBadCentralBody.__doc__ = "The central body name is invalid."
AgEAsPluginErrorCodes.eEphemerisReaderBadCoordinateSystem.__doc__ = "The coordinate system is unrecognized."
AgEAsPluginErrorCodes.eEphemerisReaderBadInterpolationMethod.__doc__ = "The interpolation method is invalid."
AgEAsPluginErrorCodes.eEphemerisReaderBadInterpolationOrder.__doc__ = "The interpolation order is invalid."
AgEAsPluginErrorCodes.eEphemerisReaderBadCovarianceRepresentation.__doc__ = "The covariance representation is invalid."
AgEAsPluginErrorCodes.eEphemerisReaderBadVopMu.__doc__ = "The VopMu value is invalid. Must be positive."
AgEAsPluginErrorCodes.eEphemerisReaderBadDistanceUnit.__doc__ = "The distance unit is invalid."
AgEAsPluginErrorCodes.eEphemerisReaderBadTimeUnit.__doc__ = "The time unit is invalid."
AgEAsPluginErrorCodes.eAstroPluginBadDouble.__doc__ = "The double is not a finite value (i.e., infinite or indeterminant)."
AgEAsPluginErrorCodes.eEphemerisReaderBadCovarianceArray.__doc__ = "The covariance array does not contain the required number of entries (6 or 21)."

agcls.AgTypeNameMap["AgEAsPluginErrorCodes"] = AgEAsPluginErrorCodes

class AgEAsEphemInterpolationMethod(IntEnum):
    """Enumeration of interpolation methods valid for IAgAsEphemFileReaderPlugin"""
   
    eAsEphemInterpolationMethodUnknown = -1
    """Invalid AgEAsEphemInterpolationMethod indicator."""
    eAsEphemInterpolationMethodLagrange = 0
    """Lagrange interpolation. Position and velocity are interpolated independently."""
    eAsEphemInterpolationMethodHermite = 1
    """Hermitian interpolation. Position and velocity are interpolated together."""
    eAsEphemInterpolationMethodLagrangeVOP = 2
    """Lagrange VOP interpolation. Position and velocity are interpolated independently, using a VOP formulation."""

AgEAsEphemInterpolationMethod.eAsEphemInterpolationMethodUnknown.__doc__ = "Invalid AgEAsEphemInterpolationMethod indicator."
AgEAsEphemInterpolationMethod.eAsEphemInterpolationMethodLagrange.__doc__ = "Lagrange interpolation. Position and velocity are interpolated independently."
AgEAsEphemInterpolationMethod.eAsEphemInterpolationMethodHermite.__doc__ = "Hermitian interpolation. Position and velocity are interpolated together."
AgEAsEphemInterpolationMethod.eAsEphemInterpolationMethodLagrangeVOP.__doc__ = "Lagrange VOP interpolation. Position and velocity are interpolated independently, using a VOP formulation."

agcls.AgTypeNameMap["AgEAsEphemInterpolationMethod"] = AgEAsEphemInterpolationMethod

class AgEAsCovRep(IntEnum):
    """Enumeration of covariance representations for IAgAsEphemFileReaderPlugin"""
   
    eAsCovRepUnknown = -1
    """Invalid AgEAsCovRep indicator."""
    eAsCovRepStandard = 0
    """The covariance components are expressed using the same coordinate system as the ephemeris (i.e., X, Y, Z, etc.)"""
    eAsCovRepRIC = 1
    """The covariance components are expressed using radial, inTrack, and crossTrack components, computed using the same coordinate system as the ephemeris."""

AgEAsCovRep.eAsCovRepUnknown.__doc__ = "Invalid AgEAsCovRep indicator."
AgEAsCovRep.eAsCovRepStandard.__doc__ = "The covariance components are expressed using the same coordinate system as the ephemeris (i.e., X, Y, Z, etc.)"
AgEAsCovRep.eAsCovRepRIC.__doc__ = "The covariance components are expressed using radial, inTrack, and crossTrack components, computed using the same coordinate system as the ephemeris."

agcls.AgTypeNameMap["AgEAsCovRep"] = AgEAsCovRep

class AgEAsCovType(IntEnum):
    """Enumeration of the desired covariance level."""
   
    eAsCovTypeUnknown = -1
    """Invalid AgEAsCovType indicator."""
    eAsCovTypeNone = 0
    """No covariance is desired."""
    eAsCovTypePosition = 1
    """Position covariance is desired. The 6 values of the lower triangular position covariance matrix will be kept if provided."""
    eAsCovTypePositionVelocity = 2
    """Position and velocity covariance is desired.  The 21 values of the lower triangular position-velocity covariance matrix will be kept if provided."""

AgEAsCovType.eAsCovTypeUnknown.__doc__ = "Invalid AgEAsCovType indicator."
AgEAsCovType.eAsCovTypeNone.__doc__ = "No covariance is desired."
AgEAsCovType.eAsCovTypePosition.__doc__ = "Position covariance is desired. The 6 values of the lower triangular position covariance matrix will be kept if provided."
AgEAsCovType.eAsCovTypePositionVelocity.__doc__ = "Position and velocity covariance is desired.  The 21 values of the lower triangular position-velocity covariance matrix will be kept if provided."

agcls.AgTypeNameMap["AgEAsCovType"] = AgEAsCovType

class AgEAsEphemFileDistanceUnit(IntEnum):
    """Sets the distance units."""
   
    eAsEphemFileDistanceUnitUnknown = -1
    """Invalid AgEAsEphemFileDistanceUnit indicator."""
    eAsEphemFileDistanceUnitMeter = 0
    """Meter"""
    eAsEphemFileDistanceUnitKilometer = 1
    """Kilometer"""
    eAsEphemFileDistanceUnitKiloFeet = 2
    """KiloFeet"""
    eAsEphemFileDistanceUnitFeet = 3
    """Feet"""
    eAsEphemFileDistanceUnitNautMile = 4
    """Nautical Mile"""

AgEAsEphemFileDistanceUnit.eAsEphemFileDistanceUnitUnknown.__doc__ = "Invalid AgEAsEphemFileDistanceUnit indicator."
AgEAsEphemFileDistanceUnit.eAsEphemFileDistanceUnitMeter.__doc__ = "Meter"
AgEAsEphemFileDistanceUnit.eAsEphemFileDistanceUnitKilometer.__doc__ = "Kilometer"
AgEAsEphemFileDistanceUnit.eAsEphemFileDistanceUnitKiloFeet.__doc__ = "KiloFeet"
AgEAsEphemFileDistanceUnit.eAsEphemFileDistanceUnitFeet.__doc__ = "Feet"
AgEAsEphemFileDistanceUnit.eAsEphemFileDistanceUnitNautMile.__doc__ = "Nautical Mile"

agcls.AgTypeNameMap["AgEAsEphemFileDistanceUnit"] = AgEAsEphemFileDistanceUnit

class AgEAsEphemFileTimeUnit(IntEnum):
    """Sets the time units."""
   
    eAsEphemFileTimeUnitUnknown = -1
    """Invalid AgEAsEphemFileTimeUnit indicator."""
    eAsEphemFileTimeUnitSecond = 0
    """Seconds"""
    eAsEphemFileTimeUnitMinute = 1
    """Minutes"""
    eAsEphemFileTimeUnitHour = 2
    """Hours"""
    eAsEphemFileTimeUnitDay = 3
    """Days"""

AgEAsEphemFileTimeUnit.eAsEphemFileTimeUnitUnknown.__doc__ = "Invalid AgEAsEphemFileTimeUnit indicator."
AgEAsEphemFileTimeUnit.eAsEphemFileTimeUnitSecond.__doc__ = "Seconds"
AgEAsEphemFileTimeUnit.eAsEphemFileTimeUnitMinute.__doc__ = "Minutes"
AgEAsEphemFileTimeUnit.eAsEphemFileTimeUnitHour.__doc__ = "Hours"
AgEAsEphemFileTimeUnit.eAsEphemFileTimeUnitDay.__doc__ = "Days"

agcls.AgTypeNameMap["AgEAsEphemFileTimeUnit"] = AgEAsEphemFileTimeUnit


class IAgAsEphemFileReaderPluginResultReg(object):
    """Interface for use with IAgAsEphemFileReaderPlugin"""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_FormatID_method_offset = 1
    _set_FormatID_method_offset = 2
    _get_Name_method_offset = 3
    _set_Name_method_offset = 4
    _AddFileExtension_method_offset = 5
    _metadata = {
        "iid_data" : (4773010053674526648, 14635815357213890235),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsEphemFileReaderPluginResultReg."""
        initialize_from_source_object(self, sourceObject, IAgAsEphemFileReaderPluginResultReg)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsEphemFileReaderPluginResultReg)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsEphemFileReaderPluginResultReg, None)
    
    _get_FormatID_metadata = { "offset" : _get_FormatID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FormatID(self) -> str:
        """File Format identification. Cannot contain spaces."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultReg._metadata, IAgAsEphemFileReaderPluginResultReg._get_FormatID_metadata)

    _set_FormatID_metadata = { "offset" : _set_FormatID_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FormatID.setter
    def FormatID(self, formatID:str) -> None:
        """File Format identification. Cannot contain spaces."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultReg._metadata, IAgAsEphemFileReaderPluginResultReg._set_FormatID_metadata, formatID)

    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Name to use in the user interface."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultReg._metadata, IAgAsEphemFileReaderPluginResultReg._get_Name_metadata)

    _set_Name_metadata = { "offset" : _set_Name_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Name.setter
    def Name(self, name:str) -> None:
        """Name to use in the user interface."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultReg._metadata, IAgAsEphemFileReaderPluginResultReg._set_Name_metadata, name)

    _AddFileExtension_metadata = { "offset" : _AddFileExtension_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def AddFileExtension(self, fileExt:str) -> None:
        """Adds a file extension to associate with this format. For example, .txt, .inp, ...."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultReg._metadata, IAgAsEphemFileReaderPluginResultReg._AddFileExtension_metadata, fileExt)

    _property_names[FormatID] = "FormatID"
    _property_names[Name] = "Name"


agcls.AgClassCatalog.add_catalog_entry((4773010053674526648, 14635815357213890235), IAgAsEphemFileReaderPluginResultReg)
agcls.AgTypeNameMap["IAgAsEphemFileReaderPluginResultReg"] = IAgAsEphemFileReaderPluginResultReg

class IAgAsEphemFileReaderPluginResultVerify(object):
    """Interface for use with IAgAsEphemFileReaderPlugin"""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Filename_method_offset = 1
    _get_IsValid_method_offset = 2
    _set_IsValid_method_offset = 3
    _get_Message_method_offset = 4
    _set_Message_method_offset = 5
    _metadata = {
        "iid_data" : (5539853788480076564, 16396231237742784922),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsEphemFileReaderPluginResultVerify."""
        initialize_from_source_object(self, sourceObject, IAgAsEphemFileReaderPluginResultVerify)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsEphemFileReaderPluginResultVerify)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsEphemFileReaderPluginResultVerify, None)
    
    _get_Filename_metadata = { "offset" : _get_Filename_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Filename(self) -> str:
        """The filename to verify."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultVerify._metadata, IAgAsEphemFileReaderPluginResultVerify._get_Filename_metadata)

    _get_IsValid_metadata = { "offset" : _get_IsValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsValid(self) -> bool:
        """The result of validating the file. Return true for a valid file, else return false."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultVerify._metadata, IAgAsEphemFileReaderPluginResultVerify._get_IsValid_metadata)

    _set_IsValid_metadata = { "offset" : _set_IsValid_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @IsValid.setter
    def IsValid(self, isValid:bool) -> None:
        """The result of validating the file. Return true for a valid file, else return false."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultVerify._metadata, IAgAsEphemFileReaderPluginResultVerify._set_IsValid_metadata, isValid)

    _get_Message_metadata = { "offset" : _get_Message_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Message(self) -> str:
        """The message of the validation of the file if it has failed."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultVerify._metadata, IAgAsEphemFileReaderPluginResultVerify._get_Message_metadata)

    _set_Message_metadata = { "offset" : _set_Message_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Message.setter
    def Message(self, message:str) -> None:
        """The message of the validation of the file if it has failed."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultVerify._metadata, IAgAsEphemFileReaderPluginResultVerify._set_Message_metadata, message)

    _property_names[Filename] = "Filename"
    _property_names[IsValid] = "IsValid"
    _property_names[Message] = "Message"


agcls.AgClassCatalog.add_catalog_entry((5539853788480076564, 16396231237742784922), IAgAsEphemFileReaderPluginResultVerify)
agcls.AgTypeNameMap["IAgAsEphemFileReaderPluginResultVerify"] = IAgAsEphemFileReaderPluginResultVerify

class IAgAsEphemFileReaderPluginResultEphem(object):
    """Interface for use with IAgAsEphemFileReaderPlugin"""

    _num_methods = 29
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_FormatID_method_offset = 1
    _get_Name_method_offset = 2
    _get_Filename_method_offset = 3
    _set_IsValid_method_offset = 4
    _set_Message_method_offset = 5
    _AddMetaData_method_offset = 6
    _set_CentralBody_method_offset = 7
    _set_CoordinateSystem_method_offset = 8
    _SetCoordinateSystemEpoch_method_offset = 9
    _GetCoordinateSystemEpoch_method_offset = 10
    _set_InterpolationMethod_method_offset = 11
    _get_InterpolationMethod_method_offset = 12
    _set_InterpolationOrder_method_offset = 13
    _get_InterpolationOrder_method_offset = 14
    _set_CovarianceRepresentation_method_offset = 15
    _get_CovarianceRepresentation_method_offset = 16
    _AddInterpolationBoundary_method_offset = 17
    _SetRefEpoch_method_offset = 18
    _GetRefEpoch_method_offset = 19
    _SetUnits_method_offset = 20
    _GetDistanceUnit_method_offset = 21
    _GetTimeUnit_method_offset = 22
    _set_MuLagrangeVOP_method_offset = 23
    _get_MuLagrangeVOP_method_offset = 24
    _AddEphemeris_method_offset = 25
    _AddEphemerisAtEpoch_method_offset = 26
    _AddEphemerisOnDate_method_offset = 27
    _get_CovarianceType_method_offset = 28
    _AddTrendControlTime_method_offset = 29
    _metadata = {
        "iid_data" : (5198900982889857505, 9355741408957519504),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsEphemFileReaderPluginResultEphem."""
        initialize_from_source_object(self, sourceObject, IAgAsEphemFileReaderPluginResultEphem)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsEphemFileReaderPluginResultEphem)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsEphemFileReaderPluginResultEphem, None)
    
    _get_FormatID_metadata = { "offset" : _get_FormatID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FormatID(self) -> str:
        """File Format identification. Cannot contain spaces."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_FormatID_metadata)

    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Name to use in the user interface."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_Name_metadata)

    _get_Filename_metadata = { "offset" : _get_Filename_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Filename(self) -> str:
        """The filename to verify."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_Filename_metadata)

    _get_IsValid_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def IsValid(self) -> None:
        """IsValid is a write-only property."""
        raise RuntimeError("IsValid is a write-only property.")


    _set_IsValid_metadata = { "offset" : _set_IsValid_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @IsValid.setter
    def IsValid(self, validity:bool) -> None:
        """False indicates a failure has occurred and that the message should be displayed"""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_IsValid_metadata, validity)

    _get_Message_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def Message(self) -> None:
        """Message is a write-only property."""
        raise RuntimeError("Message is a write-only property.")


    _set_Message_metadata = { "offset" : _set_Message_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Message.setter
    def Message(self, errorMsg:str) -> None:
        """Sets an error message when not valid"""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_Message_metadata, errorMsg)

    _AddMetaData_metadata = { "offset" : _AddMetaData_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddMetaData(self, keyword:str, value:str) -> None:
        """Associates the Value with the given Keyword"""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._AddMetaData_metadata, keyword, value)

    _get_CentralBody_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def CentralBody(self) -> None:
        """CentralBody is a write-only property."""
        raise RuntimeError("CentralBody is a write-only property.")


    _set_CentralBody_metadata = { "offset" : _set_CentralBody_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @CentralBody.setter
    def CentralBody(self, name:str) -> None:
        """The central body for the coordinate system used for the ephemeris and covariance."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_CentralBody_metadata, name)

    _get_CoordinateSystem_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def CoordinateSystem(self) -> None:
        """CoordinateSystem is a write-only property."""
        raise RuntimeError("CoordinateSystem is a write-only property.")


    _set_CoordinateSystem_metadata = { "offset" : _set_CoordinateSystem_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @CoordinateSystem.setter
    def CoordinateSystem(self, name:str) -> None:
        """The name of the coordinate system used for the ephemeris and covariance. AWB systems are supported using the same notation as that for CoordinateSystem in a .e file, e.g., AWB TopoCentric Facility/Facility1."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_CoordinateSystem_metadata, name)

    _SetCoordinateSystemEpoch_metadata = { "offset" : _SetCoordinateSystemEpoch_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetCoordinateSystemEpoch(self, dateAbbrv:str, epoch:str) -> None:
        """The coordinate system epoch for the CoordinateSystem, expressed as a string in format given by DateAbbrv. Not needed for systems with fixed epochs (like ICRF, J2000, B1950)."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._SetCoordinateSystemEpoch_metadata, dateAbbrv, epoch)

    _GetCoordinateSystemEpoch_metadata = { "offset" : _GetCoordinateSystemEpoch_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def GetCoordinateSystemEpoch(self, dateAbbrv:str) -> str:
        """The coordinate system epoch for the CoordinateSystem, expressed as a string in format given by DateAbbrv. Not needed for systems with fixed epochs (like ICRF, J2000, B1950)."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._GetCoordinateSystemEpoch_metadata, dateAbbrv, OutArg())

    _get_InterpolationMethod_metadata = { "offset" : _get_InterpolationMethod_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEphemInterpolationMethod),) }
    @property
    def InterpolationMethod(self) -> "AgEAsEphemInterpolationMethod":
        """The interpolation method used with the ephemeris."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_InterpolationMethod_metadata)

    _set_InterpolationMethod_metadata = { "offset" : _set_InterpolationMethod_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEphemInterpolationMethod),) }
    @InterpolationMethod.setter
    def InterpolationMethod(self, method:"AgEAsEphemInterpolationMethod") -> None:
        """The interpolation method used with the ephemeris."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_InterpolationMethod_metadata, method)

    _get_InterpolationOrder_metadata = { "offset" : _get_InterpolationOrder_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def InterpolationOrder(self) -> int:
        """The interpolation order to use. For Lagrange-type interpolation, 1+Order samples are used; for Hermitian, (Order+1)/2 samples are used."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_InterpolationOrder_metadata)

    _set_InterpolationOrder_metadata = { "offset" : _set_InterpolationOrder_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @InterpolationOrder.setter
    def InterpolationOrder(self, order:int) -> None:
        """The interpolation order to use. For Lagrange-type interpolation, 1+Order samples are used; for Hermitian, (Order+1)/2 samples are used."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_InterpolationOrder_metadata, order)

    _get_CovarianceRepresentation_metadata = { "offset" : _get_CovarianceRepresentation_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsCovRep),) }
    @property
    def CovarianceRepresentation(self) -> "AgEAsCovRep":
        """Sets the covariance representation."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_CovarianceRepresentation_metadata)

    _set_CovarianceRepresentation_metadata = { "offset" : _set_CovarianceRepresentation_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsCovRep),) }
    @CovarianceRepresentation.setter
    def CovarianceRepresentation(self, covRep:"AgEAsCovRep") -> None:
        """Sets the covariance representation."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_CovarianceRepresentation_metadata, covRep)

    _AddInterpolationBoundary_metadata = { "offset" : _AddInterpolationBoundary_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddInterpolationBoundary(self, dateAbbrv:str, epoch:str) -> None:
        """Adds an interpolation boundary at the Epoch specified in format given by DateAbbrv."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._AddInterpolationBoundary_metadata, dateAbbrv, epoch)

    _SetRefEpoch_metadata = { "offset" : _SetRefEpoch_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetRefEpoch(self, dateAbbrv:str, epoch:str) -> None:
        """Sets the reference epoch for points added by AddEphemeris(). The Epoch is specified in the format given by DateAbbrv."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._SetRefEpoch_metadata, dateAbbrv, epoch)

    _GetRefEpoch_metadata = { "offset" : _GetRefEpoch_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def GetRefEpoch(self, dateAbbrv:str) -> str:
        """Sets the reference epoch for points added by AddEphemeris(). The Epoch is specified in the format given by DateAbbrv."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._GetRefEpoch_metadata, dateAbbrv, OutArg())

    _SetUnits_metadata = { "offset" : _SetUnits_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEphemFileDistanceUnit), agmarshall.AgEnum_arg(AgEAsEphemFileTimeUnit),) }
    def SetUnits(self, distUnit:"AgEAsEphemFileDistanceUnit", timeUnit:"AgEAsEphemFileTimeUnit") -> None:
        """Sets the distance and time units used for both ephemeris and covariance."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._SetUnits_metadata, distUnit, timeUnit)

    _GetDistanceUnit_metadata = { "offset" : _GetDistanceUnit_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEphemFileDistanceUnit),) }
    def GetDistanceUnit(self) -> "AgEAsEphemFileDistanceUnit":
        """Gets the distance unit used for both ephemeris and covariance."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._GetDistanceUnit_metadata, OutArg())

    _GetTimeUnit_metadata = { "offset" : _GetTimeUnit_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEphemFileTimeUnit),) }
    def GetTimeUnit(self) -> "AgEAsEphemFileTimeUnit":
        """Gets the distance unit used for both ephemeris and covariance."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._GetTimeUnit_metadata, OutArg())

    _get_MuLagrangeVOP_metadata = { "offset" : _get_MuLagrangeVOP_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MuLagrangeVOP(self) -> float:
        """The gravitational parameter (expressed using the distance and time units) to use when using LagrangeVOP interpolation."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_MuLagrangeVOP_metadata)

    _set_MuLagrangeVOP_metadata = { "offset" : _set_MuLagrangeVOP_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @MuLagrangeVOP.setter
    def MuLagrangeVOP(self, vopMu:float) -> None:
        """The gravitational parameter (expressed using the distance and time units) to use when using LagrangeVOP interpolation."""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._set_MuLagrangeVOP_metadata, vopMu)

    _AddEphemeris_metadata = { "offset" : _AddEphemeris_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LPSAFEARRAY, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg, agmarshall.VARIANT_BOOL_arg,) }
    def AddEphemeris(self, timeSinceEpoch:float, x:float, y:float, z:float, vx:float, vy:float, vz:float, covArray:list) -> bool:
        """Adds an ephemeris point. Covariance array is optional. It contains the lower triangle of the covariance matrix, either 6 elements for position only, or 21 elements when using pos-vel covariance."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._AddEphemeris_metadata, timeSinceEpoch, x, y, z, vx, vy, vz, covArray, OutArg())

    _AddEphemerisAtEpoch_metadata = { "offset" : _AddEphemerisAtEpoch_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LPSAFEARRAY, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg, agmarshall.VARIANT_BOOL_arg,) }
    def AddEphemerisAtEpoch(self, dateAbbrv:str, epoch:str, x:float, y:float, z:float, vx:float, vy:float, vz:float, covArray:list) -> bool:
        """Adds an ephemeris point at the Epoch given in the format DateAbbrv. The Covariance array is optional. It contains the lower triangle of the covariance matrix, either 6 elements for position only, or 21 elements when using pos-vel covariance."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._AddEphemerisAtEpoch_metadata, dateAbbrv, epoch, x, y, z, vx, vy, vz, covArray, OutArg())

    _AddEphemerisOnDate_metadata = { "offset" : _AddEphemerisOnDate_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.LONG, agcom.LONG, agcom.LONG, agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LPSAFEARRAY, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.LONG_arg, agmarshall.LONG_arg, agmarshall.LONG_arg, agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg, agmarshall.VARIANT_BOOL_arg,) }
    def AddEphemerisOnDate(self, scale:"AgEUtTimeScale", year:int, month:int, dayOfMonth:int, hour:int, minute:int, seconds:float, x:float, y:float, z:float, vx:float, vy:float, vz:float, covArray:list) -> bool:
        """Adds an ephemeris point on the date specified. The Covariance array is optional. It contains the lower triangle of the covariance matrix, either 6 elements for position only, or 21 elements when using pos-vel covariance. Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._AddEphemerisOnDate_metadata, scale, year, month, dayOfMonth, hour, minute, seconds, x, y, z, vx, vy, vz, covArray, OutArg())

    _get_CovarianceType_metadata = { "offset" : _get_CovarianceType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsCovType),) }
    @property
    def CovarianceType(self) -> "AgEAsCovType":
        """Specifies the type of covariance desired."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._get_CovarianceType_metadata)

    _AddTrendControlTime_metadata = { "offset" : _AddTrendControlTime_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddTrendControlTime(self, dateAbbrv:str, epoch:str) -> None:
        """Adds a trending control time at the Epoch specified in format given by DateAbbrv."""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultEphem._metadata, IAgAsEphemFileReaderPluginResultEphem._AddTrendControlTime_metadata, dateAbbrv, epoch)

    _property_names[FormatID] = "FormatID"
    _property_names[Name] = "Name"
    _property_names[Filename] = "Filename"
    _property_names[IsValid] = "IsValid"
    _property_names[Message] = "Message"
    _property_names[CentralBody] = "CentralBody"
    _property_names[CoordinateSystem] = "CoordinateSystem"
    _property_names[InterpolationMethod] = "InterpolationMethod"
    _property_names[InterpolationOrder] = "InterpolationOrder"
    _property_names[CovarianceRepresentation] = "CovarianceRepresentation"
    _property_names[MuLagrangeVOP] = "MuLagrangeVOP"
    _property_names[CovarianceType] = "CovarianceType"


agcls.AgClassCatalog.add_catalog_entry((5198900982889857505, 9355741408957519504), IAgAsEphemFileReaderPluginResultEphem)
agcls.AgTypeNameMap["IAgAsEphemFileReaderPluginResultEphem"] = IAgAsEphemFileReaderPluginResultEphem

class IAgAsEphemFileReaderPluginResultData(object):
    """Interface for use with IAgAsEphemFileReaderPlugin"""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_FormatID_method_offset = 1
    _get_Name_method_offset = 2
    _get_Filename_method_offset = 3
    _set_IsValid_method_offset = 4
    _set_Message_method_offset = 5
    _AddMetaData_method_offset = 6
    _metadata = {
        "iid_data" : (4831615030319360604, 12437923571268424369),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsEphemFileReaderPluginResultData."""
        initialize_from_source_object(self, sourceObject, IAgAsEphemFileReaderPluginResultData)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsEphemFileReaderPluginResultData)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsEphemFileReaderPluginResultData, None)
    
    _get_FormatID_metadata = { "offset" : _get_FormatID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FormatID(self) -> str:
        """File Format identification. Cannot contain spaces."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultData._metadata, IAgAsEphemFileReaderPluginResultData._get_FormatID_metadata)

    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Name to use in the user interface."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultData._metadata, IAgAsEphemFileReaderPluginResultData._get_Name_metadata)

    _get_Filename_metadata = { "offset" : _get_Filename_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Filename(self) -> str:
        """The filename to verify."""
        return self._intf.get_property(IAgAsEphemFileReaderPluginResultData._metadata, IAgAsEphemFileReaderPluginResultData._get_Filename_metadata)

    _get_IsValid_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def IsValid(self) -> None:
        """IsValid is a write-only property."""
        raise RuntimeError("IsValid is a write-only property.")


    _set_IsValid_metadata = { "offset" : _set_IsValid_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @IsValid.setter
    def IsValid(self, validity:bool) -> None:
        """False indicates a failure has occurred and that the message should be displayed"""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultData._metadata, IAgAsEphemFileReaderPluginResultData._set_IsValid_metadata, validity)

    _get_Message_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def Message(self) -> None:
        """Message is a write-only property."""
        raise RuntimeError("Message is a write-only property.")


    _set_Message_metadata = { "offset" : _set_Message_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Message.setter
    def Message(self, errorMsg:str) -> None:
        """Sets an error message when not valid"""
        return self._intf.set_property(IAgAsEphemFileReaderPluginResultData._metadata, IAgAsEphemFileReaderPluginResultData._set_Message_metadata, errorMsg)

    _AddMetaData_metadata = { "offset" : _AddMetaData_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddMetaData(self, keyword:str, value:str) -> None:
        """Associates the Value with the given Keyword"""
        return self._intf.invoke(IAgAsEphemFileReaderPluginResultData._metadata, IAgAsEphemFileReaderPluginResultData._AddMetaData_metadata, keyword, value)

    _property_names[FormatID] = "FormatID"
    _property_names[Name] = "Name"
    _property_names[Filename] = "Filename"
    _property_names[IsValid] = "IsValid"
    _property_names[Message] = "Message"


agcls.AgClassCatalog.add_catalog_entry((4831615030319360604, 12437923571268424369), IAgAsEphemFileReaderPluginResultData)
agcls.AgTypeNameMap["IAgAsEphemFileReaderPluginResultData"] = IAgAsEphemFileReaderPluginResultData


class IAgAsEphemFileReaderPlugin(object):
    """
    COM Plugin interface for a External File Reader.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered on instantiation of the reader."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Register(self, result:"IAgAsEphemFileReaderPluginResultReg") -> None:
        """Triggered when the plugin is asked to register its name, format, and file extension associations"""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Verify(self, result:"IAgAsEphemFileReaderPluginResultVerify") -> None:
        """Triggered when the plugin is asked to verify a file."""
        raise STKPluginMethodNotImplementedError("Verify was not implemented.")

    def ReadEphemeris(self, result:"IAgAsEphemFileReaderPluginResultEphem") -> None:
        """Triggered when the plugin is asked to read a file and obtain its ephemeris"""
        raise STKPluginMethodNotImplementedError("ReadEphemeris was not implemented.")

    def ReadMetaData(self, result:"IAgAsEphemFileReaderPluginResultData") -> None:
        """Triggered when the plugin is asked to read a file and return any meta-data contained in the file"""
        raise STKPluginMethodNotImplementedError("ReadMetaData was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is destroyed."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")




class AgAsEphemFileReaderPluginResultReg(IAgAsEphemFileReaderPluginResultReg, SupportsDeleteCallback):
    """Interface for use with IAgAsEphemFileReaderPlugin"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsEphemFileReaderPluginResultReg."""
        SupportsDeleteCallback.__init__(self)
        IAgAsEphemFileReaderPluginResultReg.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsEphemFileReaderPluginResultReg._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsEphemFileReaderPluginResultReg, [IAgAsEphemFileReaderPluginResultReg])

agcls.AgClassCatalog.add_catalog_entry((4978716312539184143, 5114899543027706282), AgAsEphemFileReaderPluginResultReg)
agcls.AgTypeNameMap["AgAsEphemFileReaderPluginResultReg"] = AgAsEphemFileReaderPluginResultReg

class AgAsEphemFileReaderPluginResultVerify(IAgAsEphemFileReaderPluginResultVerify, SupportsDeleteCallback):
    """Interface for use with IAgAsEphemFileReaderPlugin"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsEphemFileReaderPluginResultVerify."""
        SupportsDeleteCallback.__init__(self)
        IAgAsEphemFileReaderPluginResultVerify.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsEphemFileReaderPluginResultVerify._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsEphemFileReaderPluginResultVerify, [IAgAsEphemFileReaderPluginResultVerify])

agcls.AgClassCatalog.add_catalog_entry((4887312666567837083, 109029694109009341), AgAsEphemFileReaderPluginResultVerify)
agcls.AgTypeNameMap["AgAsEphemFileReaderPluginResultVerify"] = AgAsEphemFileReaderPluginResultVerify

class AgAsEphemFileReaderPluginResultEphem(IAgAsEphemFileReaderPluginResultEphem, SupportsDeleteCallback):
    """Interface for use with IAgAsEphemFileReaderPlugin"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsEphemFileReaderPluginResultEphem."""
        SupportsDeleteCallback.__init__(self)
        IAgAsEphemFileReaderPluginResultEphem.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsEphemFileReaderPluginResultEphem._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsEphemFileReaderPluginResultEphem, [IAgAsEphemFileReaderPluginResultEphem])

agcls.AgClassCatalog.add_catalog_entry((5593896047448495549, 17740296370492256933), AgAsEphemFileReaderPluginResultEphem)
agcls.AgTypeNameMap["AgAsEphemFileReaderPluginResultEphem"] = AgAsEphemFileReaderPluginResultEphem

class AgAsEphemFileReaderPluginResultData(IAgAsEphemFileReaderPluginResultData, SupportsDeleteCallback):
    """Interface for use with IAgAsEphemFileReaderPlugin"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsEphemFileReaderPluginResultData."""
        SupportsDeleteCallback.__init__(self)
        IAgAsEphemFileReaderPluginResultData.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsEphemFileReaderPluginResultData._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsEphemFileReaderPluginResultData, [IAgAsEphemFileReaderPluginResultData])

agcls.AgClassCatalog.add_catalog_entry((5002126522450069045, 2654061521232113285), AgAsEphemFileReaderPluginResultData)
agcls.AgTypeNameMap["AgAsEphemFileReaderPluginResultData"] = AgAsEphemFileReaderPluginResultData


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
