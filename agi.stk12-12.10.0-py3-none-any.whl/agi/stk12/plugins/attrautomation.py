################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgAttrBuilder", "AgEAttrAddFlags", "IAgAttrAutomationConnector", "IAgAttrBuilder", "IAgAttrConfig"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEAttrAddFlags(IntFlag):
    """Enumeration of Attribute Flags"""
   
    eAddFlagNone = 0x0000
    """No special flag"""
    eAddFlagTransparent = 0x0002
    """When applied to a container, makes the container transparent (i.e. its attributes are directly visible without having to navigate into the container)"""
    eAddFlagHidden = 0x0004
    """The attribute is not visible in the user interface property page."""
    eAddFlagTransient = 0x0008
    """The attribute is ignored during save/load."""
    eAddFlagReadOnly = 0x0010
    """The attribute is read-only and cannot be modified by the user."""
    eAddFlagFixed = 0x0020
    """The attribute container has a fixed size. Additions/removals of sub-elements are prohibited."""

AgEAttrAddFlags.eAddFlagNone.__doc__ = "No special flag"
AgEAttrAddFlags.eAddFlagTransparent.__doc__ = "When applied to a container, makes the container transparent (i.e. its attributes are directly visible without having to navigate into the container)"
AgEAttrAddFlags.eAddFlagHidden.__doc__ = "The attribute is not visible in the user interface property page."
AgEAttrAddFlags.eAddFlagTransient.__doc__ = "The attribute is ignored during save/load."
AgEAttrAddFlags.eAddFlagReadOnly.__doc__ = "The attribute is read-only and cannot be modified by the user."
AgEAttrAddFlags.eAddFlagFixed.__doc__ = "The attribute container has a fixed size. Additions/removals of sub-elements are prohibited."

agcls.AgTypeNameMap["AgEAttrAddFlags"] = AgEAttrAddFlags


class IAgAttrBuilder(object):
    """Attribute Automation Builder Interface helps construct an Attribute Scope"""

    _num_methods = 29
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _NewScope_method_offset = 1
    _AddIntDispatchProperty_method_offset = 2
    _AddLongDispatchProperty_method_offset = 3
    _AddStringDispatchProperty_method_offset = 4
    _AddBoolDispatchProperty_method_offset = 5
    _AddFileDispatchProperty_method_offset = 6
    _AddDirectoryDispatchProperty_method_offset = 7
    _AddRelFileDispatchProperty_method_offset = 8
    _AddDoubleDispatchProperty_method_offset = 9
    _AddDateDispatchProperty_method_offset = 10
    _ToString_method_offset = 11
    _MergeFromString_method_offset = 12
    _AddDependencyDispatchProperty_method_offset = 13
    _AddFlagsDispatchProperty_method_offset = 14
    _AddChoicesDispatchProperty_method_offset = 15
    _AddListDispatchProperty_method_offset = 16
    _AddVARIANTDispatchProperty_method_offset = 17
    _AddMultiLineStringDispatchProperty_method_offset = 18
    _ToFormattedString_method_offset = 19
    _AddQuantityDispatchProperty2_method_offset = 20
    _AddQuantityMinMaxDispatchProperty2_method_offset = 21
    _AddScopeDispatchProperty_method_offset = 22
    _AddChoicesFuncDispatchProperty_method_offset = 23
    _AddDoubleMinDispatchProperty_method_offset = 24
    _AddDoubleMinMaxDispatchProperty_method_offset = 25
    _AddQuantityMinDispatchProperty2_method_offset = 26
    _AddIntMinDispatchProperty_method_offset = 27
    _AddIntMinMaxDispatchProperty_method_offset = 28
    _AddScopeDispatchProperty2_method_offset = 29
    _metadata = {
        "iid_data" : (4782631166002323158, 4723007708228976813),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAttrBuilder."""
        initialize_from_source_object(self, sourceObject, IAgAttrBuilder)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAttrBuilder)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAttrBuilder, None)
    
    _NewScope_metadata = { "offset" : _NewScope_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def NewScope(self) -> typing.Any:
        """Create a new Attribute Scope for use in Attribute Builder method calls"""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._NewScope_metadata, OutArg())

    _AddIntDispatchProperty_metadata = { "offset" : _AddIntDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddIntDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type int to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddIntDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _AddLongDispatchProperty_metadata = { "offset" : _AddLongDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddLongDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type long to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddLongDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _AddStringDispatchProperty_metadata = { "offset" : _AddStringDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddStringDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type string to the Attribute Scope. Only allows single line strings. For multi-line strings use AddMultiLineStringDispatchProperty. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddStringDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _AddBoolDispatchProperty_metadata = { "offset" : _AddBoolDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddBoolDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type bool to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddBoolDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _AddFileDispatchProperty_metadata = { "offset" : _AddFileDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddFileDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, fileType:str, fileFilter:str, flags:int) -> None:
        """Add an Attribute of type file (string) to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddFileDispatchProperty_metadata, dispScope, name, description, propName, fileType, fileFilter, flags)

    _AddDirectoryDispatchProperty_metadata = { "offset" : _AddDirectoryDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddDirectoryDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type directory (string) to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddDirectoryDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _AddRelFileDispatchProperty_metadata = { "offset" : _AddRelFileDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddRelFileDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, fileType:str, fileFilter:str, flags:int) -> None:
        """Add an Attribute of type relative file path (string) to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddRelFileDispatchProperty_metadata, dispScope, name, description, propName, fileType, fileFilter, flags)

    _AddDoubleDispatchProperty_metadata = { "offset" : _AddDoubleDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddDoubleDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type double to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddDoubleDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _AddDateDispatchProperty_metadata = { "offset" : _AddDateDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddDateDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type date (represented as a double in EpSec) to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddDateDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _ToString_metadata = { "offset" : _ToString_method_offset,
            "arg_types" : (agcom.PVOID, agcom.PVOID, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg,) }
    def ToString(self, dispPlugin:"IDispatch", dispScope:"IDispatch") -> str:
        """Serialize an Attribute scope for a plugin to a formatted XML String representation. (internal use)"""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._ToString_metadata, dispPlugin, dispScope, OutArg())

    _MergeFromString_metadata = { "offset" : _MergeFromString_method_offset,
            "arg_types" : (agcom.PVOID, agcom.PVOID, agcom.BSTR,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg,) }
    def MergeFromString(self, dispPlugin:"IDispatch", dispScope:"IDispatch", xmlString:str) -> None:
        """Deserialize an Attribute scope into a plugin from a formatted XML String representation. (internal use)"""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._MergeFromString_metadata, dispPlugin, dispScope, xmlString)

    _AddDependencyDispatchProperty_metadata = { "offset" : _AddDependencyDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddDependencyDispatchProperty(self, dispScope:"IDispatch", parentAttributeName:str, childAttributeName:str) -> None:
        """Add a Dependency between two Attributes within the Attribute Scope provided. Dependencies are used to force the update of the child attribute when the parent attribute is modified by the user."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddDependencyDispatchProperty_metadata, dispScope, parentAttributeName, childAttributeName)

    _AddFlagsDispatchProperty_metadata = { "offset" : _AddFlagsDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddFlagsDispatchProperty(self, dispScope:"IDispatch", name:str, flagPropName:str) -> None:
        """Add a callback to retrieve the flags for the provided Attribute name from the provided property name. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddFlagsDispatchProperty_metadata, dispScope, name, flagPropName)

    _AddChoicesDispatchProperty_metadata = { "offset" : _AddChoicesDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LPSAFEARRAY,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AddChoicesDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, choices:list) -> None:
        """Add an Attribute that provides a combobox of values from which the user can choose. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddChoicesDispatchProperty_metadata, dispScope, name, description, propName, choices)

    _AddListDispatchProperty_metadata = { "offset" : _AddListDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddListDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, newElemMethodName:str, flags:int) -> None:
        """Add an Attribute that represents a list of values. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddListDispatchProperty_metadata, dispScope, name, description, propName, newElemMethodName, flags)

    _AddVARIANTDispatchProperty_metadata = { "offset" : _AddVARIANTDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddVARIANTDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type variant to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddVARIANTDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _AddMultiLineStringDispatchProperty_metadata = { "offset" : _AddMultiLineStringDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddMultiLineStringDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, flags:int) -> None:
        """Add an Attribute of type multi-line string to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddMultiLineStringDispatchProperty_metadata, dispScope, name, description, propName, flags)

    _ToFormattedString_metadata = { "offset" : _ToFormattedString_method_offset,
            "arg_types" : (agcom.PVOID, agcom.PVOID, agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def ToFormattedString(self, dispPlugin:"IDispatch", dispScope:"IDispatch", formatId:str) -> str:
        """Get a String representation of the Attribute Scope, formatted using the specified FormatId. (internal use)"""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._ToFormattedString_metadata, dispPlugin, dispScope, formatId, OutArg())

    _AddQuantityDispatchProperty2_metadata = { "offset" : _AddQuantityDispatchProperty2_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def AddQuantityDispatchProperty2(self, dispScope:"IDispatch", name:str, description:str, propName:str, dimension:str, displayUnit:str, internalUnit:str, flags:int) -> None:
        """Add an Attribute of type quantity to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddQuantityDispatchProperty2_metadata, dispScope, name, description, propName, dimension, displayUnit, internalUnit, flags)

    _AddQuantityMinMaxDispatchProperty2_metadata = { "offset" : _AddQuantityMinMaxDispatchProperty2_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LONG_arg,) }
    def AddQuantityMinMaxDispatchProperty2(self, dispScope:"IDispatch", name:str, description:str, propName:str, dimension:str, displayUnit:str, internalUnit:str, minVal:float, maxVal:float, flags:int) -> None:
        """Add an Attribute of type quantity to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddQuantityMinMaxDispatchProperty2_metadata, dispScope, name, description, propName, dimension, displayUnit, internalUnit, minVal, maxVal, flags)

    _AddScopeDispatchProperty_metadata = { "offset" : _AddScopeDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_in_arg("IDispatch"),) }
    def AddScopeDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, newDispScope:"IDispatch") -> None:
        """Add an Attribute to the 'NewDispScope' Scope (to construct a hierarchy). It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddScopeDispatchProperty_metadata, dispScope, name, description, newDispScope)

    _AddChoicesFuncDispatchProperty_metadata = { "offset" : _AddChoicesFuncDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddChoicesFuncDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, funcPropName:str) -> None:
        """Add an Attribute that provides a combobox of values from which the user can choose. Similar to AddChoicesDispatchProperty but uses a callback to get the list of available values instead of a static array of strings. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddChoicesFuncDispatchProperty_metadata, dispScope, name, description, propName, funcPropName)

    _AddDoubleMinDispatchProperty_metadata = { "offset" : _AddDoubleMinDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.DOUBLE, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.LONG_arg,) }
    def AddDoubleMinDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, minVal:float, flags:int) -> None:
        """Add an Attribute of type double with a min to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddDoubleMinDispatchProperty_metadata, dispScope, name, description, propName, minVal, flags)

    _AddDoubleMinMaxDispatchProperty_metadata = { "offset" : _AddDoubleMinMaxDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LONG_arg,) }
    def AddDoubleMinMaxDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, minVal:float, maxVal:float, flags:int) -> None:
        """Add an Attribute of type double with a min and max to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddDoubleMinMaxDispatchProperty_metadata, dispScope, name, description, propName, minVal, maxVal, flags)

    _AddQuantityMinDispatchProperty2_metadata = { "offset" : _AddQuantityMinDispatchProperty2_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.DOUBLE, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.LONG_arg,) }
    def AddQuantityMinDispatchProperty2(self, dispScope:"IDispatch", name:str, description:str, propName:str, dimension:str, displayUnit:str, internalUnit:str, minVal:float, flags:int) -> None:
        """Add an Attribute of type quantity with a min to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddQuantityMinDispatchProperty2_metadata, dispScope, name, description, propName, dimension, displayUnit, internalUnit, minVal, flags)

    _AddIntMinDispatchProperty_metadata = { "offset" : _AddIntMinDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.INT, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.INT_arg, agmarshall.LONG_arg,) }
    def AddIntMinDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, minVal:int, flags:int) -> None:
        """Add an Attribute of type int with a minimum to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddIntMinDispatchProperty_metadata, dispScope, name, description, propName, minVal, flags)

    _AddIntMinMaxDispatchProperty_metadata = { "offset" : _AddIntMinMaxDispatchProperty_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.INT, agcom.INT, agcom.LONG,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.LONG_arg,) }
    def AddIntMinMaxDispatchProperty(self, dispScope:"IDispatch", name:str, description:str, propName:str, minVal:int, maxVal:int, flags:int) -> None:
        """Add an Attribute of type int with a min and max to the Attribute Scope. It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddIntMinMaxDispatchProperty_metadata, dispScope, name, description, propName, minVal, maxVal, flags)

    _AddScopeDispatchProperty2_metadata = { "offset" : _AddScopeDispatchProperty2_method_offset,
            "arg_types" : (agcom.PVOID, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddScopeDispatchProperty2(self, dispScope:"IDispatch", name:str, description:str) -> None:
        """Add an Attribute to the current Attribute Scope (to construct a hierarchy). It is recommended that any name used for these configuration properties not include spaces because certain interfaces to the properties may not work correctly."""
        return self._intf.invoke(IAgAttrBuilder._metadata, IAgAttrBuilder._AddScopeDispatchProperty2_metadata, dispScope, name, description)



agcls.AgClassCatalog.add_catalog_entry((4782631166002323158, 4723007708228976813), IAgAttrBuilder)
agcls.AgTypeNameMap["IAgAttrBuilder"] = IAgAttrBuilder

class IAgAttrConfig(object):
    """Attributes Configuration Interface"""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _GetConfig_method_offset = 1
    _metadata = {
        "iid_data" : (4700426038192390987, 6734016162035374240),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAttrConfig."""
        initialize_from_source_object(self, sourceObject, IAgAttrConfig)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAttrConfig)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAttrConfig, None)
    
    _GetConfig_metadata = { "offset" : _GetConfig_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgAttrBuilder"), agmarshall.AgInterface_out_arg,) }
    def GetConfig(self, pAttrBuilder:"IAgAttrBuilder") -> typing.Any:
        """Get the configuration represented by an attribute container (also called attribute scope)."""
        return self._intf.invoke(IAgAttrConfig._metadata, IAgAttrConfig._GetConfig_metadata, pAttrBuilder, OutArg())



agcls.AgClassCatalog.add_catalog_entry((4700426038192390987, 6734016162035374240), IAgAttrConfig)
agcls.AgTypeNameMap["IAgAttrConfig"] = IAgAttrConfig

class IAgAttrAutomationConnector(object):
    """Attributes Automation Connector Interface"""

    _num_methods = 2
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _ConnectObject_method_offset = 1
    _DisconnectObject_method_offset = 2
    _metadata = {
        "iid_data" : (5145162609891700475, 14140887617087403433),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAttrAutomationConnector."""
        initialize_from_source_object(self, sourceObject, IAgAttrAutomationConnector)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAttrAutomationConnector)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAttrAutomationConnector, None)
    
    _ConnectObject_metadata = { "offset" : _ConnectObject_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"),) }
    def ConnectObject(self, objectDispatch:"IDispatch") -> None:
        """Connect to Attributes Automation Adapter Object (AgAttrAutomationAdapter)"""
        return self._intf.invoke(IAgAttrAutomationConnector._metadata, IAgAttrAutomationConnector._ConnectObject_metadata, objectDispatch)

    _DisconnectObject_metadata = { "offset" : _DisconnectObject_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def DisconnectObject(self) -> None:
        """Disconnect from Attributes Automation Adapter Object (AgAttrAutomationAdapter)"""
        return self._intf.invoke(IAgAttrAutomationConnector._metadata, IAgAttrAutomationConnector._DisconnectObject_metadata, )



agcls.AgClassCatalog.add_catalog_entry((5145162609891700475, 14140887617087403433), IAgAttrAutomationConnector)
agcls.AgTypeNameMap["IAgAttrAutomationConnector"] = IAgAttrAutomationConnector



class AgAttrBuilder(IAgAttrBuilder, SupportsDeleteCallback):
    """Attribute Automation Builder Class helps construct an Attribute Scope"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgAttrBuilder."""
        SupportsDeleteCallback.__init__(self)
        IAgAttrBuilder.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAttrBuilder._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAttrBuilder, [IAgAttrBuilder])

agcls.AgClassCatalog.add_catalog_entry((5134307930535496098, 11565577713921253530), AgAttrBuilder)
agcls.AgTypeNameMap["AgAttrBuilder"] = AgAttrBuilder


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
