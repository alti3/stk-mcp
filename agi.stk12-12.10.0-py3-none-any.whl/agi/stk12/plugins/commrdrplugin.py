################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgStkCommRdrAbsorpLossPythonPlugin", "AgStkCommRdrAbsorptionLossPropagateSignalParams", "IAgSTKCommRdrNoiseTempComputeParams", 
"IAgSTKCommRdrNoiseTempPlugin", "IAgStkCommRdrAbsorptionLossPlugin", "IAgStkCommRdrAbsorptionLossPropagateSignalParams", 
"IAgStkRadarPosVelProvider"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.attrautomation import *
from ..plugins.utplugin import *
from ..plugins.crdnplugin import *
from ..plugins.commrdrfoundation import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class IAgSTKCommRdrNoiseTempComputeParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the Noise Temperature plugin Compute method."""

    _num_methods = 12
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Time_method_offset = 1
    _get_Frequency_method_offset = 2
    _get_Range_method_offset = 3
    _get_Speed_method_offset = 4
    _get_AltitudeMSL_method_offset = 5
    _get_PitchAngle_method_offset = 6
    _get_RollAngle_method_offset = 7
    _GetPositionCBF_method_offset = 8
    _GetVelocityCBF_method_offset = 9
    _GetDirection_method_offset = 10
    _get_DirectionArray_method_offset = 11
    _SetNoiseTemp_method_offset = 12
    _metadata = {
        "iid_data" : (4923515196631896833, 14662532349870128294),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKCommRdrNoiseTempComputeParams."""
        initialize_from_source_object(self, sourceObject, IAgSTKCommRdrNoiseTempComputeParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKCommRdrNoiseTempComputeParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKCommRdrNoiseTempComputeParams, None)
    
    _get_Time_metadata = { "offset" : _get_Time_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Time(self) -> float:
        """Gets the time value."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_Time_metadata)

    _get_Frequency_metadata = { "offset" : _get_Frequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Frequency(self) -> float:
        """Gets the frequency value."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_Frequency_metadata)

    _get_Range_metadata = { "offset" : _get_Range_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Range(self) -> float:
        """Gets the link range value."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_Range_metadata)

    _get_Speed_metadata = { "offset" : _get_Speed_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Speed(self) -> float:
        """Gets the object speed value."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_Speed_metadata)

    _get_AltitudeMSL_metadata = { "offset" : _get_AltitudeMSL_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AltitudeMSL(self) -> float:
        """Gets the object MSL Altitude value."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_AltitudeMSL_metadata)

    _get_PitchAngle_metadata = { "offset" : _get_PitchAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def PitchAngle(self) -> float:
        """Gets the object Pitch angle value."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_PitchAngle_metadata)

    _get_RollAngle_metadata = { "offset" : _get_RollAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RollAngle(self) -> float:
        """Gets the object Roll Angle value."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_RollAngle_metadata)

    _GetPositionCBF_metadata = { "offset" : _GetPositionCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetPositionCBF(self) -> typing.Tuple[float, float, float]:
        """Gets the base position vector in the central body fixed frame."""
        return self._intf.invoke(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._GetPositionCBF_metadata, OutArg(), OutArg(), OutArg())

    _GetVelocityCBF_metadata = { "offset" : _GetVelocityCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetVelocityCBF(self) -> typing.Tuple[float, float, float]:
        """Gets the velocity vector in the central body fixed frame."""
        return self._intf.invoke(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._GetVelocityCBF_metadata, OutArg(), OutArg(), OutArg())

    _GetDirection_metadata = { "offset" : _GetDirection_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetDirection(self) -> typing.Tuple[float, float, float]:
        """Gets the direction vector in the body fixed frame."""
        return self._intf.invoke(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._GetDirection_metadata, OutArg(), OutArg(), OutArg())

    _get_DirectionArray_metadata = { "offset" : _get_DirectionArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def DirectionArray(self) -> list:
        """Gets the direction vector in the body fixed frame as an array."""
        return self._intf.get_property(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._get_DirectionArray_metadata)

    _SetNoiseTemp_metadata = { "offset" : _SetNoiseTemp_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetNoiseTemp(self, noiseTemp:float) -> None:
        """Sets the Noise Temperature value."""
        return self._intf.invoke(IAgSTKCommRdrNoiseTempComputeParams._metadata, IAgSTKCommRdrNoiseTempComputeParams._SetNoiseTemp_metadata, noiseTemp)

    _property_names[Time] = "Time"
    _property_names[Frequency] = "Frequency"
    _property_names[Range] = "Range"
    _property_names[Speed] = "Speed"
    _property_names[AltitudeMSL] = "AltitudeMSL"
    _property_names[PitchAngle] = "PitchAngle"
    _property_names[RollAngle] = "RollAngle"
    _property_names[DirectionArray] = "DirectionArray"


agcls.AgClassCatalog.add_catalog_entry((4923515196631896833, 14662532349870128294), IAgSTKCommRdrNoiseTempComputeParams)
agcls.AgTypeNameMap["IAgSTKCommRdrNoiseTempComputeParams"] = IAgSTKCommRdrNoiseTempComputeParams

class IAgSTKCommRdrNoiseTempPlugin(object):
    """Interface implemented by an object that represents a Noise Temperature plugin."""

    _num_methods = 3
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _Initialize_method_offset = 1
    _ComputeNoiseTemperature_method_offset = 2
    _Free_method_offset = 3
    _metadata = {
        "iid_data" : (5638610371413752832, 7904932074713434017),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKCommRdrNoiseTempPlugin."""
        initialize_from_source_object(self, sourceObject, IAgSTKCommRdrNoiseTempPlugin)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKCommRdrNoiseTempPlugin)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKCommRdrNoiseTempPlugin, None)
    
    _Initialize_metadata = { "offset" : _Initialize_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgUtPluginSite"),) }
    def Initialize(self, site:"IAgUtPluginSite") -> None:
        """Initializes the plugin with the plugin site."""
        return self._intf.invoke(IAgSTKCommRdrNoiseTempPlugin._metadata, IAgSTKCommRdrNoiseTempPlugin._Initialize_metadata, site)

    _ComputeNoiseTemperature_metadata = { "offset" : _ComputeNoiseTemperature_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgSTKCommRdrNoiseTempComputeParams"),) }
    def ComputeNoiseTemperature(self, computeParams:"IAgSTKCommRdrNoiseTempComputeParams") -> None:
        """Noise Temperature plugin compute value."""
        return self._intf.invoke(IAgSTKCommRdrNoiseTempPlugin._metadata, IAgSTKCommRdrNoiseTempPlugin._ComputeNoiseTemperature_metadata, computeParams)

    _Free_metadata = { "offset" : _Free_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Free(self) -> None:
        """Free Noise Temperature plugin."""
        return self._intf.invoke(IAgSTKCommRdrNoiseTempPlugin._metadata, IAgSTKCommRdrNoiseTempPlugin._Free_metadata, )



agcls.AgClassCatalog.add_catalog_entry((5638610371413752832, 7904932074713434017), IAgSTKCommRdrNoiseTempPlugin)
agcls.AgTypeNameMap["IAgSTKCommRdrNoiseTempPlugin"] = IAgSTKCommRdrNoiseTempPlugin

class IAgStkRadarPosVelProvider(object):
    """Interface implemented by an object that provides the position and velocity for an STK radar object or radar target object."""

    _num_methods = 29
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_CurrentTime_method_offset = 1
    _GetVelocityCBF_method_offset = 2
    _get_VelocityCBFArray_method_offset = 3
    _GetPositionCBF_method_offset = 4
    _get_PositionCBFArray_method_offset = 5
    _GetPositionLLA_method_offset = 6
    _get_PositionLLAArray_method_offset = 7
    _get_LocalRadiusDetic_method_offset = 8
    _get_LocalRadiusCentric_method_offset = 9
    _GetSurfaceNormalDetic_method_offset = 10
    _get_SurfaceNormalDeticArray_method_offset = 11
    _GetSurfaceNormalCentric_method_offset = 12
    _get_SurfaceNormalCentricArray_method_offset = 13
    _ComputeLocalRadiusDetic_method_offset = 14
    _ComputeLocalRadiusCentric_method_offset = 15
    _ComputeSurfaceNormalDetic_method_offset = 16
    _ComputeSurfaceNormalDeticArray_method_offset = 17
    _ComputeSurfaceNormalCentric_method_offset = 18
    _ComputeSurfaceNormalCentricArray_method_offset = 19
    _ConvertCBFCartesianToLLA_method_offset = 20
    _ConvertCBFCartesianToLLAArray_method_offset = 21
    _ConvertLLAToCBFCartesian_method_offset = 22
    _ConvertLLAToCBFCartesianArray_method_offset = 23
    _ConvertCBFCartesianToVVLHCartesian_method_offset = 24
    _ConvertCBFCartesianToVVLHCartesianArray_method_offset = 25
    _ConvertBodyCartesianToCBFCartesian_method_offset = 26
    _ConvertBodyCartesianToCBFCartesianArray_method_offset = 27
    _ConvertCBFCartesianToBodyCartesian_method_offset = 28
    _ConvertCBFCartesianToBodyCartesianArray_method_offset = 29
    _metadata = {
        "iid_data" : (4821309614856942207, 5400228342774437775),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarPosVelProvider."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarPosVelProvider)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarPosVelProvider)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarPosVelProvider, None)
    
    _get_CurrentTime_metadata = { "offset" : _get_CurrentTime_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CurrentTime(self) -> float:
        """Gets the current time in EpSec."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_CurrentTime_metadata)

    _GetVelocityCBF_metadata = { "offset" : _GetVelocityCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetVelocityCBF(self) -> typing.Tuple[float, float, float]:
        """Gets velocity in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetVelocityCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_VelocityCBFArray_metadata = { "offset" : _get_VelocityCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def VelocityCBFArray(self) -> list:
        """Gets velocity in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_VelocityCBFArray_metadata)

    _GetPositionCBF_metadata = { "offset" : _GetPositionCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetPositionCBF(self) -> typing.Tuple[float, float, float]:
        """Gets position in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetPositionCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_PositionCBFArray_metadata = { "offset" : _get_PositionCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def PositionCBFArray(self) -> list:
        """Gets position in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_PositionCBFArray_metadata)

    _GetPositionLLA_metadata = { "offset" : _GetPositionLLA_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetPositionLLA(self) -> typing.Tuple[float, float, float]:
        """Gets position in latitude, longitude, and altitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetPositionLLA_metadata, OutArg(), OutArg(), OutArg())

    _get_PositionLLAArray_metadata = { "offset" : _get_PositionLLAArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def PositionLLAArray(self) -> list:
        """Gets position in latitude, longitude, and altitude as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_PositionLLAArray_metadata)

    _get_LocalRadiusDetic_metadata = { "offset" : _get_LocalRadiusDetic_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LocalRadiusDetic(self) -> float:
        """Gets the central body radius detic using the position/velocity provider's current latitude and longitude."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_LocalRadiusDetic_metadata)

    _get_LocalRadiusCentric_metadata = { "offset" : _get_LocalRadiusCentric_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LocalRadiusCentric(self) -> float:
        """Gets the central body radius centric using the position/velocity provider's current latitude and longitude."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_LocalRadiusCentric_metadata)

    _GetSurfaceNormalDetic_metadata = { "offset" : _GetSurfaceNormalDetic_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetSurfaceNormalDetic(self) -> typing.Tuple[float, float, float]:
        """Gets the surface normal detic."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetSurfaceNormalDetic_metadata, OutArg(), OutArg(), OutArg())

    _get_SurfaceNormalDeticArray_metadata = { "offset" : _get_SurfaceNormalDeticArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SurfaceNormalDeticArray(self) -> list:
        """Gets the surface normal detic as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_SurfaceNormalDeticArray_metadata)

    _GetSurfaceNormalCentric_metadata = { "offset" : _GetSurfaceNormalCentric_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetSurfaceNormalCentric(self) -> typing.Tuple[float, float, float]:
        """Gets the surface normal centric as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetSurfaceNormalCentric_metadata, OutArg(), OutArg(), OutArg())

    _get_SurfaceNormalCentricArray_metadata = { "offset" : _get_SurfaceNormalCentricArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SurfaceNormalCentricArray(self) -> list:
        """Gets the surface normal centric as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_SurfaceNormalCentricArray_metadata)

    _ComputeLocalRadiusDetic_metadata = { "offset" : _ComputeLocalRadiusDetic_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeLocalRadiusDetic(self, latitude:float, longitude:float) -> float:
        """Computes the central body radius detic for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeLocalRadiusDetic_metadata, latitude, longitude, OutArg())

    _ComputeLocalRadiusCentric_metadata = { "offset" : _ComputeLocalRadiusCentric_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeLocalRadiusCentric(self, latitude:float, longitude:float) -> float:
        """Computes the central body radius centric for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeLocalRadiusCentric_metadata, latitude, longitude, OutArg())

    _ComputeSurfaceNormalDetic_metadata = { "offset" : _ComputeSurfaceNormalDetic_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeSurfaceNormalDetic(self, latitude:float, longitude:float) -> typing.Tuple[float, float, float]:
        """Computes the surface normal detic vector for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalDetic_metadata, latitude, longitude, OutArg(), OutArg(), OutArg())

    _ComputeSurfaceNormalDeticArray_metadata = { "offset" : _ComputeSurfaceNormalDeticArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ComputeSurfaceNormalDeticArray(self, latitude:float, longitude:float) -> list:
        """Computes the surface normal detic vector for a given latitude and longitude as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalDeticArray_metadata, latitude, longitude, OutArg())

    _ComputeSurfaceNormalCentric_metadata = { "offset" : _ComputeSurfaceNormalCentric_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeSurfaceNormalCentric(self, latitude:float, longitude:float) -> typing.Tuple[float, float, float]:
        """Computes the surface normal centric vector for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalCentric_metadata, latitude, longitude, OutArg(), OutArg(), OutArg())

    _ComputeSurfaceNormalCentricArray_metadata = { "offset" : _ComputeSurfaceNormalCentricArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ComputeSurfaceNormalCentricArray(self, latitude:float, longitude:float) -> list:
        """Computes the surface normal centric vector for a given latitude and longitude as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalCentricArray_metadata, latitude, longitude, OutArg())

    _ConvertCBFCartesianToLLA_metadata = { "offset" : _ConvertCBFCartesianToLLA_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertCBFCartesianToLLA(self, x:float, y:float, z:float) -> typing.Tuple[float, float, float]:
        """Converts central body fixed cartesian to latitude, longitude, and altitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToLLA_metadata, x, y, z, OutArg(), OutArg(), OutArg())

    _ConvertCBFCartesianToLLAArray_metadata = { "offset" : _ConvertCBFCartesianToLLAArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertCBFCartesianToLLAArray(self, x:float, y:float, z:float) -> list:
        """Converts central body fixed cartesian to latitude, longitude, and altitude as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToLLAArray_metadata, x, y, z, OutArg())

    _ConvertLLAToCBFCartesian_metadata = { "offset" : _ConvertLLAToCBFCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertLLAToCBFCartesian(self, latitude:float, longitude:float, altitude:float) -> typing.Tuple[float, float, float]:
        """Converts latitude, longitude, and altitude to central body fixed cartesian."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertLLAToCBFCartesian_metadata, latitude, longitude, altitude, OutArg(), OutArg(), OutArg())

    _ConvertLLAToCBFCartesianArray_metadata = { "offset" : _ConvertLLAToCBFCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertLLAToCBFCartesianArray(self, latitude:float, longitude:float, altitude:float) -> list:
        """Converts latitude, longitude, and altitude to central body fixed cartesian as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertLLAToCBFCartesianArray_metadata, latitude, longitude, altitude, OutArg())

    _ConvertCBFCartesianToVVLHCartesian_metadata = { "offset" : _ConvertCBFCartesianToVVLHCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertCBFCartesianToVVLHCartesian(self, xCbf:float, yCbf:float, zCbf:float) -> typing.Tuple[float, float, float]:
        """Converts a central body fixed cartesian into the VVLA frame."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToVVLHCartesian_metadata, xCbf, yCbf, zCbf, OutArg(), OutArg(), OutArg())

    _ConvertCBFCartesianToVVLHCartesianArray_metadata = { "offset" : _ConvertCBFCartesianToVVLHCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertCBFCartesianToVVLHCartesianArray(self, xCbf:float, yCbf:float, zCbf:float) -> list:
        """Converts a central body fixed cartesian into the VVLA frame as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToVVLHCartesianArray_metadata, xCbf, yCbf, zCbf, OutArg())

    _ConvertBodyCartesianToCBFCartesian_metadata = { "offset" : _ConvertBodyCartesianToCBFCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertBodyCartesianToCBFCartesian(self, xBody:float, yBody:float, zBody:float) -> typing.Tuple[float, float, float]:
        """Converts a vector in body coordinates into CBF fixed coordinates"""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertBodyCartesianToCBFCartesian_metadata, xBody, yBody, zBody, OutArg(), OutArg(), OutArg())

    _ConvertBodyCartesianToCBFCartesianArray_metadata = { "offset" : _ConvertBodyCartesianToCBFCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertBodyCartesianToCBFCartesianArray(self, xBody:float, yBody:float, zBody:float) -> list:
        """Converts a vector in body coordinates into CBF fixed coordinates as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertBodyCartesianToCBFCartesianArray_metadata, xBody, yBody, zBody, OutArg())

    _ConvertCBFCartesianToBodyCartesian_metadata = { "offset" : _ConvertCBFCartesianToBodyCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertCBFCartesianToBodyCartesian(self, xCbf:float, yCbf:float, zCbf:float) -> typing.Tuple[float, float, float]:
        """Converts a vector in CBF coordinates into body coordinates."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToBodyCartesian_metadata, xCbf, yCbf, zCbf, OutArg(), OutArg(), OutArg())

    _ConvertCBFCartesianToBodyCartesianArray_metadata = { "offset" : _ConvertCBFCartesianToBodyCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertCBFCartesianToBodyCartesianArray(self, xCbf:float, yCbf:float, zCbf:float) -> list:
        """Converts a vector in CBF coordinates into body coordinates as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToBodyCartesianArray_metadata, xCbf, yCbf, zCbf, OutArg())

    _property_names[CurrentTime] = "CurrentTime"
    _property_names[VelocityCBFArray] = "VelocityCBFArray"
    _property_names[PositionCBFArray] = "PositionCBFArray"
    _property_names[PositionLLAArray] = "PositionLLAArray"
    _property_names[LocalRadiusDetic] = "LocalRadiusDetic"
    _property_names[LocalRadiusCentric] = "LocalRadiusCentric"
    _property_names[SurfaceNormalDeticArray] = "SurfaceNormalDeticArray"
    _property_names[SurfaceNormalCentricArray] = "SurfaceNormalCentricArray"


agcls.AgClassCatalog.add_catalog_entry((4821309614856942207, 5400228342774437775), IAgStkRadarPosVelProvider)
agcls.AgTypeNameMap["IAgStkRadarPosVelProvider"] = IAgStkRadarPosVelProvider

class IAgStkCommRdrAbsorptionLossPropagateSignalParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the Absorption Model plugin PropagateSignal method."""

    _num_methods = 10
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_EpochSec_method_offset = 1
    _get_DateUTC_method_offset = 2
    _get_CbName_method_offset = 3
    _get_XmtrPath_method_offset = 4
    _get_RcvrPath_method_offset = 5
    _get_Frequency_method_offset = 6
    _get_XmtrPosCBF_method_offset = 7
    _get_RcvrPosCBF_method_offset = 8
    _set_NoiseTemp_method_offset = 9
    _set_AbsorpLoss_method_offset = 10
    _metadata = {
        "iid_data" : (4944835510194240084, 11723001511971181476),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkCommRdrAbsorptionLossPropagateSignalParams."""
        initialize_from_source_object(self, sourceObject, IAgStkCommRdrAbsorptionLossPropagateSignalParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkCommRdrAbsorptionLossPropagateSignalParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkCommRdrAbsorptionLossPropagateSignalParams, None)
    
    _get_EpochSec_metadata = { "offset" : _get_EpochSec_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def EpochSec(self) -> float:
        """Gets the current time in EpSec."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_EpochSec_metadata)

    _get_DateUTC_metadata = { "offset" : _get_DateUTC_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def DateUTC(self) -> str:
        """Gets date in UTC."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_DateUTC_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Gets central body name."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_CbName_metadata)

    _get_XmtrPath_metadata = { "offset" : _get_XmtrPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def XmtrPath(self) -> str:
        """Gets transmitter path."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_XmtrPath_metadata)

    _get_RcvrPath_metadata = { "offset" : _get_RcvrPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def RcvrPath(self) -> str:
        """Gets receiver path."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_RcvrPath_metadata)

    _get_Frequency_metadata = { "offset" : _get_Frequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Frequency(self) -> float:
        """Gets frequency."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_Frequency_metadata)

    _get_XmtrPosCBF_metadata = { "offset" : _get_XmtrPosCBF_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def XmtrPosCBF(self) -> list:
        """Gets the transmitter's position as an array."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_XmtrPosCBF_metadata)

    _get_RcvrPosCBF_metadata = { "offset" : _get_RcvrPosCBF_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def RcvrPosCBF(self) -> list:
        """Gets the receiver's position as an array."""
        return self._intf.get_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._get_RcvrPosCBF_metadata)

    _get_NoiseTemp_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def NoiseTemp(self) -> None:
        """NoiseTemp is a write-only property."""
        raise RuntimeError("NoiseTemp is a write-only property.")


    _set_NoiseTemp_metadata = { "offset" : _set_NoiseTemp_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @NoiseTemp.setter
    def NoiseTemp(self, noiseTemp:float) -> None:
        """Sets the noise temp value."""
        return self._intf.set_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._set_NoiseTemp_metadata, noiseTemp)

    _get_AbsorpLoss_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def AbsorpLoss(self) -> None:
        """AbsorpLoss is a write-only property."""
        raise RuntimeError("AbsorpLoss is a write-only property.")


    _set_AbsorpLoss_metadata = { "offset" : _set_AbsorpLoss_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @AbsorpLoss.setter
    def AbsorpLoss(self, absorpLoss:float) -> None:
        """Sets the absorption loss value."""
        return self._intf.set_property(IAgStkCommRdrAbsorptionLossPropagateSignalParams._metadata, IAgStkCommRdrAbsorptionLossPropagateSignalParams._set_AbsorpLoss_metadata, absorpLoss)

    _property_names[EpochSec] = "EpochSec"
    _property_names[DateUTC] = "DateUTC"
    _property_names[CbName] = "CbName"
    _property_names[XmtrPath] = "XmtrPath"
    _property_names[RcvrPath] = "RcvrPath"
    _property_names[Frequency] = "Frequency"
    _property_names[XmtrPosCBF] = "XmtrPosCBF"
    _property_names[RcvrPosCBF] = "RcvrPosCBF"
    _property_names[NoiseTemp] = "NoiseTemp"
    _property_names[AbsorpLoss] = "AbsorpLoss"


agcls.AgClassCatalog.add_catalog_entry((4944835510194240084, 11723001511971181476), IAgStkCommRdrAbsorptionLossPropagateSignalParams)
agcls.AgTypeNameMap["IAgStkCommRdrAbsorptionLossPropagateSignalParams"] = IAgStkCommRdrAbsorptionLossPropagateSignalParams


class IAgStkCommRdrAbsorptionLossPlugin(object):
    """
    Interface implemented by an object that represents an Absorption Loss plugin.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Initialize(self, site:"IAgUtPluginSite") -> None:
        """Initializes the plugin with the plugin site."""
        raise STKPluginMethodNotImplementedError("Initialize was not implemented.")

    def PrePropagateSignal(self) -> bool:
        """Absorption Loss plugin pre-propagate signal."""
        raise STKPluginMethodNotImplementedError("PrePropagateSignal was not implemented.")

    def PropagateSignal(self, propagateSignalParams:"IAgStkCommRdrAbsorptionLossPropagateSignalParams") -> bool:
        """Absorption Loss plugin propagate signal."""
        raise STKPluginMethodNotImplementedError("PropagateSignal was not implemented.")

    def PostPropagateSignal(self) -> None:
        """Absorption Loss plugin post-propagate signal"""
        raise STKPluginMethodNotImplementedError("PostPropagateSignal was not implemented.")

    def Free(self) -> None:
        """Free Absorption Loss plugin."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")




class AgStkCommRdrAbsorptionLossPropagateSignalParams(IAgStkCommRdrAbsorptionLossPropagateSignalParams, SupportsDeleteCallback):
    """The CoClass for the IAgStkCommRdrAbsorptionLossPropagateSignalParams interface."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkCommRdrAbsorptionLossPropagateSignalParams."""
        SupportsDeleteCallback.__init__(self)
        IAgStkCommRdrAbsorptionLossPropagateSignalParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkCommRdrAbsorptionLossPropagateSignalParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkCommRdrAbsorptionLossPropagateSignalParams, [IAgStkCommRdrAbsorptionLossPropagateSignalParams])

agcls.AgClassCatalog.add_catalog_entry((5519478740142830301, 16944744193382380461), AgStkCommRdrAbsorptionLossPropagateSignalParams)
agcls.AgTypeNameMap["AgStkCommRdrAbsorptionLossPropagateSignalParams"] = AgStkCommRdrAbsorptionLossPropagateSignalParams

class AgStkCommRdrAbsorpLossPythonPlugin(IAgStkCommRdrAbsorptionLossPlugin, IAgUtPluginConfig, SupportsDeleteCallback):
    """The implementation of IAgStkCommRdrAbsorptionLossPlugin for Python."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkCommRdrAbsorpLossPythonPlugin."""
        SupportsDeleteCallback.__init__(self)
        IAgStkCommRdrAbsorptionLossPlugin.__init__(self, sourceObject)
        IAgUtPluginConfig.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkCommRdrAbsorptionLossPlugin._private_init(self, intf)
        IAgUtPluginConfig._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkCommRdrAbsorpLossPythonPlugin, [IAgStkCommRdrAbsorptionLossPlugin, IAgUtPluginConfig])

agcls.AgClassCatalog.add_catalog_entry((4781975107880834439, 14913080491131864976), AgStkCommRdrAbsorpLossPythonPlugin)
agcls.AgTypeNameMap["AgStkCommRdrAbsorpLossPythonPlugin"] = AgStkCommRdrAbsorpLossPythonPlugin


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
