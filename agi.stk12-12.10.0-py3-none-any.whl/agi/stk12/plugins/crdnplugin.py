################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgCrdnAxesPluginResultEval", "AgCrdnAxesPluginResultReg", "AgCrdnAxesPluginResultReset", "AgCrdnCalcScalarPluginResultEval", 
"AgCrdnCalcScalarPluginResultReg", "AgCrdnCalcScalarPluginResultReset", "AgCrdnConfiguredAngle", "AgCrdnConfiguredAngleWithRate", 
"AgCrdnConfiguredAxes", "AgCrdnConfiguredAxesWithRate", "AgCrdnConfiguredCalcParameterSet", "AgCrdnConfiguredCalcParameterSetWithRate", 
"AgCrdnConfiguredCalcScalar", "AgCrdnConfiguredCalcScalarWithRate", "AgCrdnConfiguredPoint", "AgCrdnConfiguredPointWithRate", 
"AgCrdnConfiguredSystem", "AgCrdnConfiguredSystemWithRate", "AgCrdnConfiguredVector", "AgCrdnConfiguredVectorWithRate", 
"AgCrdnPluginCalcProvider", "AgCrdnPluginProvider", "AgCrdnPointPluginResultEval", "AgCrdnPointPluginResultReg", "AgCrdnPointPluginResultReset", 
"AgCrdnVectorPluginResultEval", "AgCrdnVectorPluginResultReg", "AgCrdnVectorPluginResultReset", "AgECrdnEulerSequence", 
"IAgCrdnAxesPlugin", "IAgCrdnAxesPluginResultEval", "IAgCrdnAxesPluginResultReg", "IAgCrdnAxesPluginResultReset", "IAgCrdnCalcScalarPlugin", 
"IAgCrdnCalcScalarPluginResultEval", "IAgCrdnCalcScalarPluginResultReg", "IAgCrdnCalcScalarPluginResultReset", "IAgCrdnConfiguredAngle", 
"IAgCrdnConfiguredAngleWithRate", "IAgCrdnConfiguredAxes", "IAgCrdnConfiguredAxesWithRate", "IAgCrdnConfiguredCalcParameterSet", 
"IAgCrdnConfiguredCalcParameterSetWithRate", "IAgCrdnConfiguredCalcScalar", "IAgCrdnConfiguredCalcScalarWithRate", "IAgCrdnConfiguredPoint", 
"IAgCrdnConfiguredPointWithRate", "IAgCrdnConfiguredSystem", "IAgCrdnConfiguredSystemWithRate", "IAgCrdnConfiguredVector", 
"IAgCrdnConfiguredVectorWithRate", "IAgCrdnPluginCalcProvider", "IAgCrdnPluginProvider", "IAgCrdnPointPlugin", "IAgCrdnPointPluginResultEval", 
"IAgCrdnPointPluginResultReg", "IAgCrdnPointPluginResultReset", "IAgCrdnVectorPlugin", "IAgCrdnVectorPluginResultEval", 
"IAgCrdnVectorPluginResultReg", "IAgCrdnVectorPluginResultReset"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.utplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgECrdnEulerSequence(IntEnum):
    """Enumeration AgECrdnEulerSequence."""
   
    eCrdnEulerSequence121 = 121
    """Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated x-axis."""
    eCrdnEulerSequence123 = 123
    """Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated z-axis."""
    eCrdnEulerSequence131 = 131
    """Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated x-axis."""
    eCrdnEulerSequence132 = 132
    """Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated y-axis."""
    eCrdnEulerSequence212 = 212
    """Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated y-axis."""
    eCrdnEulerSequence213 = 213
    """Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated z-axis."""
    eCrdnEulerSequence231 = 231
    """Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated x-axis."""
    eCrdnEulerSequence232 = 232
    """Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated y-axis."""
    eCrdnEulerSequence312 = 312
    """Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated y-axis."""
    eCrdnEulerSequence313 = 313
    """Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated z-axis."""
    eCrdnEulerSequence321 = 321
    """Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."""
    eCrdnEulerSequence323 = 323
    """Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."""

AgECrdnEulerSequence.eCrdnEulerSequence121.__doc__ = "Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated x-axis."
AgECrdnEulerSequence.eCrdnEulerSequence123.__doc__ = "Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated z-axis."
AgECrdnEulerSequence.eCrdnEulerSequence131.__doc__ = "Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated x-axis."
AgECrdnEulerSequence.eCrdnEulerSequence132.__doc__ = "Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated y-axis."
AgECrdnEulerSequence.eCrdnEulerSequence212.__doc__ = "Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated y-axis."
AgECrdnEulerSequence.eCrdnEulerSequence213.__doc__ = "Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated z-axis."
AgECrdnEulerSequence.eCrdnEulerSequence231.__doc__ = "Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated x-axis."
AgECrdnEulerSequence.eCrdnEulerSequence232.__doc__ = "Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated y-axis."
AgECrdnEulerSequence.eCrdnEulerSequence312.__doc__ = "Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated y-axis."
AgECrdnEulerSequence.eCrdnEulerSequence313.__doc__ = "Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated z-axis."
AgECrdnEulerSequence.eCrdnEulerSequence321.__doc__ = "Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."
AgECrdnEulerSequence.eCrdnEulerSequence323.__doc__ = "Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."

agcls.AgTypeNameMap["AgECrdnEulerSequence"] = AgECrdnEulerSequence


class IAgCrdnConfiguredVector(object):
    """Crdn Vector object interface which computes its components."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _metadata = {
        "iid_data" : (5704829249802413356, 9574622729115287999),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredVector."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredVector)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredVector)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredVector, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredVector._metadata, IAgCrdnConfiguredVector._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any."""
        return self._intf.get_property(IAgCrdnConfiguredVector._metadata, IAgCrdnConfiguredVector._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the Vector (in internal units) at the given time returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredVector._metadata, IAgCrdnConfiguredVector._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the Vector (in internal units) at the interface's current time, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredVector._metadata, IAgCrdnConfiguredVector._CurrentValue_Array_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5704829249802413356, 9574622729115287999), IAgCrdnConfiguredVector)
agcls.AgTypeNameMap["IAgCrdnConfiguredVector"] = IAgCrdnConfiguredVector

class IAgCrdnConfiguredVectorWithRate(object):
    """Crdn Vector object interface which computes its components and rates."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _metadata = {
        "iid_data" : (4694582204013109555, 12164982555832989077),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredVectorWithRate."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredVectorWithRate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredVectorWithRate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredVectorWithRate, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredVectorWithRate._metadata, IAgCrdnConfiguredVectorWithRate._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredVectorWithRate._metadata, IAgCrdnConfiguredVectorWithRate._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the Vector and its rate (in internal units) at the given time returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredVectorWithRate._metadata, IAgCrdnConfiguredVectorWithRate._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the Vector and its rate (in internal units) at the interface's current time, returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredVectorWithRate._metadata, IAgCrdnConfiguredVectorWithRate._CurrentValue_Array_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((4694582204013109555, 12164982555832989077), IAgCrdnConfiguredVectorWithRate)
agcls.AgTypeNameMap["IAgCrdnConfiguredVectorWithRate"] = IAgCrdnConfiguredVectorWithRate

class IAgCrdnConfiguredAxes(object):
    """Crdn Axes object interface which computes its quaternion."""

    _num_methods = 10
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _TransformComponents_method_offset = 7
    _TransformComponents_Array_method_offset = 8
    _TransformComponentsAtEpoch_method_offset = 9
    _TransformComponentsAtEpoch_Array_method_offset = 10
    _metadata = {
        "iid_data" : (5623109743961196020, 17163484232186150320),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredAxes."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredAxes)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredAxes)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredAxes, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredAxes._metadata, IAgCrdnConfiguredAxes._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredAxes._metadata, IAgCrdnConfiguredAxes._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the quaternion representing the Axes at the given time returned as an array representing q1, q2, q3, q4. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxes._metadata, IAgCrdnConfiguredAxes._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the quaternion representing the Axes at the interface's current time, returned as an array representing q1, q2, q3, q4. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxes._metadata, IAgCrdnConfiguredAxes._CurrentValue_Array_metadata, dispInterface, OutArg())

    _TransformComponents_Array_metadata = { "offset" : _TransformComponents_Array_method_offset,
            "arg_types" : (agcom.PVOID, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponents_Array(self, dispInterface:"IDispatch", x:float, y:float, z:float) -> list:
        """Transforms vector components given wrt Axes into those wrt RefAxes at the interface's current time, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxes._metadata, IAgCrdnConfiguredAxes._TransformComponents_Array_metadata, dispInterface, x, y, z, OutArg())

    _TransformComponentsAtEpoch_Array_metadata = { "offset" : _TransformComponentsAtEpoch_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponentsAtEpoch_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float, x:float, y:float, z:float) -> list:
        """Transforms vector components given wrt Axes into those wrt RefAxes at the given time, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxes._metadata, IAgCrdnConfiguredAxes._TransformComponentsAtEpoch_Array_metadata, scale, wholeDays, secsIntoDay, x, y, z, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5623109743961196020, 17163484232186150320), IAgCrdnConfiguredAxes)
agcls.AgTypeNameMap["IAgCrdnConfiguredAxes"] = IAgCrdnConfiguredAxes

class IAgCrdnConfiguredAxesWithRate(object):
    """Crdn Axes object interface which computes its quaternion and angular velocity."""

    _num_methods = 10
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _TransformComponents_method_offset = 7
    _TransformComponents_Array_method_offset = 8
    _TransformComponentsAtEpoch_method_offset = 9
    _TransformComponentsAtEpoch_Array_method_offset = 10
    _metadata = {
        "iid_data" : (4853776537405580126, 8727080963907991947),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredAxesWithRate."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredAxesWithRate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredAxesWithRate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredAxesWithRate, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredAxesWithRate._metadata, IAgCrdnConfiguredAxesWithRate._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredAxesWithRate._metadata, IAgCrdnConfiguredAxesWithRate._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the quaternion representing the Axes and its angular rate in reference components at the given time returned as an array representing q1, q2, q3, q4, wx, wy, wz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxesWithRate._metadata, IAgCrdnConfiguredAxesWithRate._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the quaternion representing the Axes and its angular rate in reference components at the interface's current time, returned as an array representing q1, q2, q3, q4, wx, wy, wz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxesWithRate._metadata, IAgCrdnConfiguredAxesWithRate._CurrentValue_Array_metadata, dispInterface, OutArg())

    _TransformComponents_Array_metadata = { "offset" : _TransformComponents_Array_method_offset,
            "arg_types" : (agcom.PVOID, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponents_Array(self, dispInterface:"IDispatch", x:float, y:float, z:float, vx:float, vy:float, vz:float) -> list:
        """Transforms vector components given wrt Axes into those wrt RefAxes at the interface's current time, returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxesWithRate._metadata, IAgCrdnConfiguredAxesWithRate._TransformComponents_Array_metadata, dispInterface, x, y, z, vx, vy, vz, OutArg())

    _TransformComponentsAtEpoch_Array_metadata = { "offset" : _TransformComponentsAtEpoch_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponentsAtEpoch_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float, x:float, y:float, z:float, vx:float, vy:float, vz:float) -> list:
        """Transforms vector components given wrt Axes into those wrt RefAxes at the given time, returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAxesWithRate._metadata, IAgCrdnConfiguredAxesWithRate._TransformComponentsAtEpoch_Array_metadata, scale, wholeDays, secsIntoDay, x, y, z, vx, vy, vz, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((4853776537405580126, 8727080963907991947), IAgCrdnConfiguredAxesWithRate)
agcls.AgTypeNameMap["IAgCrdnConfiguredAxesWithRate"] = IAgCrdnConfiguredAxesWithRate

class IAgCrdnConfiguredAngle(object):
    """Crdn Angle object interface."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_RetVal_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_RetVal_method_offset = 6
    _metadata = {
        "iid_data" : (4894786533394285039, 4210200944832361661),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredAngle."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredAngle)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredAngle)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredAngle, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredAngle._metadata, IAgCrdnConfiguredAngle._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredAngle._metadata, IAgCrdnConfiguredAngle._get_ErrorText_metadata)

    _Evaluate_RetVal_metadata = { "offset" : _Evaluate_RetVal_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def Evaluate_RetVal(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> float:
        """Computes the Angle (rad) at the given time"""
        return self._intf.invoke(IAgCrdnConfiguredAngle._metadata, IAgCrdnConfiguredAngle._Evaluate_RetVal_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_RetVal_metadata = { "offset" : _CurrentValue_RetVal_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.DOUBLE_arg,) }
    def CurrentValue_RetVal(self, dispInterface:"IDispatch") -> float:
        """Computes the Angle (rad) at the interface's current time"""
        return self._intf.invoke(IAgCrdnConfiguredAngle._metadata, IAgCrdnConfiguredAngle._CurrentValue_RetVal_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((4894786533394285039, 4210200944832361661), IAgCrdnConfiguredAngle)
agcls.AgTypeNameMap["IAgCrdnConfiguredAngle"] = IAgCrdnConfiguredAngle

class IAgCrdnConfiguredAngleWithRate(object):
    """Crdn Angle object interface."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _metadata = {
        "iid_data" : (5437987855487766412, 16871935197380962207),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredAngleWithRate."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredAngleWithRate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredAngleWithRate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredAngleWithRate, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredAngleWithRate._metadata, IAgCrdnConfiguredAngleWithRate._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredAngleWithRate._metadata, IAgCrdnConfiguredAngleWithRate._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the Angle and its rate at the given time returned as an array representing angle, angeRate. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredAngleWithRate._metadata, IAgCrdnConfiguredAngleWithRate._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the Angle (rad) and its rate (rad/sec) at the interface's current time."""
        return self._intf.invoke(IAgCrdnConfiguredAngleWithRate._metadata, IAgCrdnConfiguredAngleWithRate._CurrentValue_Array_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5437987855487766412, 16871935197380962207), IAgCrdnConfiguredAngleWithRate)
agcls.AgTypeNameMap["IAgCrdnConfiguredAngleWithRate"] = IAgCrdnConfiguredAngleWithRate

class IAgCrdnConfiguredPoint(object):
    """Crdn Point object interface which computes its components."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _metadata = {
        "iid_data" : (4765586521097804574, 7637938578698362528),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredPoint."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredPoint)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredPoint)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredPoint, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredPoint._metadata, IAgCrdnConfiguredPoint._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredPoint._metadata, IAgCrdnConfiguredPoint._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the Point (in internal units) at the given time returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredPoint._metadata, IAgCrdnConfiguredPoint._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the Point (in internal units) at the interface's current time, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredPoint._metadata, IAgCrdnConfiguredPoint._CurrentValue_Array_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((4765586521097804574, 7637938578698362528), IAgCrdnConfiguredPoint)
agcls.AgTypeNameMap["IAgCrdnConfiguredPoint"] = IAgCrdnConfiguredPoint

class IAgCrdnConfiguredPointWithRate(object):
    """Crdn Point object interface which computes its components and rates."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _metadata = {
        "iid_data" : (5267427379014823958, 3695271346111975102),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredPointWithRate."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredPointWithRate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredPointWithRate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredPointWithRate, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredPointWithRate._metadata, IAgCrdnConfiguredPointWithRate._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredPointWithRate._metadata, IAgCrdnConfiguredPointWithRate._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the Point and its rate (in internal units) at the given time returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredPointWithRate._metadata, IAgCrdnConfiguredPointWithRate._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the Point and its rate (in internal units) at the interface's current time, returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredPointWithRate._metadata, IAgCrdnConfiguredPointWithRate._CurrentValue_Array_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5267427379014823958, 3695271346111975102), IAgCrdnConfiguredPointWithRate)
agcls.AgTypeNameMap["IAgCrdnConfiguredPointWithRate"] = IAgCrdnConfiguredPointWithRate

class IAgCrdnConfiguredSystem(object):
    """Crdn System object interface which computes its components."""

    _num_methods = 10
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _TransformComponents_method_offset = 7
    _TransformComponents_Array_method_offset = 8
    _TransformComponentsAtEpoch_method_offset = 9
    _TransformComponentsAtEpoch_Array_method_offset = 10
    _metadata = {
        "iid_data" : (5122132905836163130, 3239110519666057129),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredSystem."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredSystem)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredSystem)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredSystem, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredSystem._metadata, IAgCrdnConfiguredSystem._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredSystem._metadata, IAgCrdnConfiguredSystem._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the System position (in internal units) and quaternion at the given time returned as an array representing x, y, z, q1, q2, q3, q4. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredSystem._metadata, IAgCrdnConfiguredSystem._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the System position (in internal units) and quaternion at the interface's current time, returned as an array representing x, y, z, q1, q2, q3, q4. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredSystem._metadata, IAgCrdnConfiguredSystem._CurrentValue_Array_metadata, dispInterface, OutArg())

    _TransformComponents_Array_metadata = { "offset" : _TransformComponents_Array_method_offset,
            "arg_types" : (agcom.PVOID, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponents_Array(self, dispInterface:"IDispatch", x:float, y:float, z:float) -> list:
        """Transforms vector components given wrt System into those wrt RefSystem at the interface's current time, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredSystem._metadata, IAgCrdnConfiguredSystem._TransformComponents_Array_metadata, dispInterface, x, y, z, OutArg())

    _TransformComponentsAtEpoch_Array_metadata = { "offset" : _TransformComponentsAtEpoch_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponentsAtEpoch_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float, x:float, y:float, z:float) -> list:
        """Transforms vector components given wrt System into those wrt RefSystem at the given time, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredSystem._metadata, IAgCrdnConfiguredSystem._TransformComponentsAtEpoch_Array_metadata, scale, wholeDays, secsIntoDay, x, y, z, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5122132905836163130, 3239110519666057129), IAgCrdnConfiguredSystem)
agcls.AgTypeNameMap["IAgCrdnConfiguredSystem"] = IAgCrdnConfiguredSystem

class IAgCrdnConfiguredSystemWithRate(object):
    """Crdn System object interface which computes its components and rates."""

    _num_methods = 10
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _TransformComponents_method_offset = 7
    _TransformComponents_Array_method_offset = 8
    _TransformComponentsAtEpoch_method_offset = 9
    _TransformComponentsAtEpoch_Array_method_offset = 10
    _metadata = {
        "iid_data" : (5475557791706951362, 3872092882533115065),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredSystemWithRate."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredSystemWithRate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredSystemWithRate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredSystemWithRate, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredSystemWithRate._metadata, IAgCrdnConfiguredSystemWithRate._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredSystemWithRate._metadata, IAgCrdnConfiguredSystemWithRate._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the System position and velocity, quaternion, and angular rate in reference components (in internal units) at the given time returned as an array representing x, y, z, vx, vy, vz, q1, q2, q3, q4, wx, wy, wz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredSystemWithRate._metadata, IAgCrdnConfiguredSystemWithRate._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the System position and velocity, quaternion, and angular rate in reference components (in internal units) at the interface's current time, returned as an array representing x, y, z, vx, vy, vz, q1, q2, q3, q4, wx, wy, wz."""
        return self._intf.invoke(IAgCrdnConfiguredSystemWithRate._metadata, IAgCrdnConfiguredSystemWithRate._CurrentValue_Array_metadata, dispInterface, OutArg())

    _TransformComponents_Array_metadata = { "offset" : _TransformComponents_Array_method_offset,
            "arg_types" : (agcom.PVOID, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponents_Array(self, dispInterface:"IDispatch", x:float, y:float, z:float, vx:float, vy:float, vz:float) -> list:
        """Transforms vector components given wrt System into those wrt RefSystem at the interface's current time, returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredSystemWithRate._metadata, IAgCrdnConfiguredSystemWithRate._TransformComponents_Array_metadata, dispInterface, x, y, z, vx, vy, vz, OutArg())

    _TransformComponentsAtEpoch_Array_metadata = { "offset" : _TransformComponentsAtEpoch_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformComponentsAtEpoch_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float, x:float, y:float, z:float, vx:float, vy:float, vz:float) -> list:
        """Transforms vector components given wrt System into those wrt RefSystem at the given time, returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredSystemWithRate._metadata, IAgCrdnConfiguredSystemWithRate._TransformComponentsAtEpoch_Array_metadata, scale, wholeDays, secsIntoDay, x, y, z, vx, vy, vz, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5475557791706951362, 3872092882533115065), IAgCrdnConfiguredSystemWithRate)
agcls.AgTypeNameMap["IAgCrdnConfiguredSystemWithRate"] = IAgCrdnConfiguredSystemWithRate

class IAgCrdnConfiguredCalcScalar(object):
    """Crdn Calc Scalar object interface."""

    _num_methods = 9
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _get_Dimension_method_offset = 7
    _get_UnitAbbrv_method_offset = 8
    _SetUnits_method_offset = 9
    _metadata = {
        "iid_data" : (5076017211297625084, 11298287263042250416),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredCalcScalar."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredCalcScalar)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredCalcScalar)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredCalcScalar, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalar._metadata, IAgCrdnConfiguredCalcScalar._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalar._metadata, IAgCrdnConfiguredCalcScalar._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the Scalar value in internal units at the given time, returned as an array representing value, errFlag. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredCalcScalar._metadata, IAgCrdnConfiguredCalcScalar._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the Scalar value in internal units at the interface's current time, returned as an array representing value, errFlag. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredCalcScalar._metadata, IAgCrdnConfiguredCalcScalar._CurrentValue_Array_metadata, dispInterface, OutArg())

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """Name of the dimension of this calc scalar."""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalar._metadata, IAgCrdnConfiguredCalcScalar._get_Dimension_metadata)

    _get_UnitAbbrv_metadata = { "offset" : _get_UnitAbbrv_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def UnitAbbrv(self) -> str:
        """Unit abbreviation for the current units used in the Evaluate and CurrentValue methods."""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalar._metadata, IAgCrdnConfiguredCalcScalar._get_UnitAbbrv_metadata)

    _SetUnits_metadata = { "offset" : _SetUnits_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetUnits(self, unitAbbrv:str) -> bool:
        """Sets the current units. Returns true for valid units, else returns false."""
        return self._intf.invoke(IAgCrdnConfiguredCalcScalar._metadata, IAgCrdnConfiguredCalcScalar._SetUnits_metadata, unitAbbrv, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"
    _property_names[Dimension] = "Dimension"
    _property_names[UnitAbbrv] = "UnitAbbrv"


agcls.AgClassCatalog.add_catalog_entry((5076017211297625084, 11298287263042250416), IAgCrdnConfiguredCalcScalar)
agcls.AgTypeNameMap["IAgCrdnConfiguredCalcScalar"] = IAgCrdnConfiguredCalcScalar

class IAgCrdnConfiguredCalcScalarWithRate(object):
    """Crdn Calc ScalarWithRate object interface."""

    _num_methods = 9
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_method_offset = 3
    _Evaluate_Array_method_offset = 4
    _CurrentValue_method_offset = 5
    _CurrentValue_Array_method_offset = 6
    _get_Dimension_method_offset = 7
    _get_UnitAbbrv_method_offset = 8
    _SetUnits_method_offset = 9
    _metadata = {
        "iid_data" : (5479568650793035816, 13695872143575736968),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredCalcScalarWithRate."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredCalcScalarWithRate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredCalcScalarWithRate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredCalcScalarWithRate, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalarWithRate._metadata, IAgCrdnConfiguredCalcScalarWithRate._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalarWithRate._metadata, IAgCrdnConfiguredCalcScalarWithRate._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the Scalar value and rate in internal units at the given time, returned as an array representing value, rate, errFlag. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredCalcScalarWithRate._metadata, IAgCrdnConfiguredCalcScalarWithRate._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the Scalar value and rate in internal units at the interface's current time, returned as an array representing value, rate, errFlag. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnConfiguredCalcScalarWithRate._metadata, IAgCrdnConfiguredCalcScalarWithRate._CurrentValue_Array_metadata, dispInterface, OutArg())

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """Name of the dimension of this calc scalar."""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalarWithRate._metadata, IAgCrdnConfiguredCalcScalarWithRate._get_Dimension_metadata)

    _get_UnitAbbrv_metadata = { "offset" : _get_UnitAbbrv_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def UnitAbbrv(self) -> str:
        """Unit abbreviation for the current units used in the Evaluate and CurrentValue methods."""
        return self._intf.get_property(IAgCrdnConfiguredCalcScalarWithRate._metadata, IAgCrdnConfiguredCalcScalarWithRate._get_UnitAbbrv_metadata)

    _SetUnits_metadata = { "offset" : _SetUnits_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetUnits(self, unitAbbrv:str) -> bool:
        """Sets the current units. Returns true for valid units, else returns false. Rates are given in the current units per sec"""
        return self._intf.invoke(IAgCrdnConfiguredCalcScalarWithRate._metadata, IAgCrdnConfiguredCalcScalarWithRate._SetUnits_metadata, unitAbbrv, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"
    _property_names[Dimension] = "Dimension"
    _property_names[UnitAbbrv] = "UnitAbbrv"


agcls.AgClassCatalog.add_catalog_entry((5479568650793035816, 13695872143575736968), IAgCrdnConfiguredCalcScalarWithRate)
agcls.AgTypeNameMap["IAgCrdnConfiguredCalcScalarWithRate"] = IAgCrdnConfiguredCalcScalarWithRate

class IAgCrdnConfiguredCalcParameterSet(object):
    """Crdn Calc ParameterSet object interface."""

    _num_methods = 4
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_Array_method_offset = 3
    _CurrentValue_Array_method_offset = 4
    _metadata = {
        "iid_data" : (5416678741906141296, 3643307016121749692),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredCalcParameterSet."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredCalcParameterSet)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredCalcParameterSet)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredCalcParameterSet, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredCalcParameterSet._metadata, IAgCrdnConfiguredCalcParameterSet._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredCalcParameterSet._metadata, IAgCrdnConfiguredCalcParameterSet._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the set of parameters at the given time, returned as an array. The last element of the array is an error flag indicator."""
        return self._intf.invoke(IAgCrdnConfiguredCalcParameterSet._metadata, IAgCrdnConfiguredCalcParameterSet._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the set of parameters at the interface's current time, returned as an array. The last element of the array is an error flag indicator."""
        return self._intf.invoke(IAgCrdnConfiguredCalcParameterSet._metadata, IAgCrdnConfiguredCalcParameterSet._CurrentValue_Array_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5416678741906141296, 3643307016121749692), IAgCrdnConfiguredCalcParameterSet)
agcls.AgTypeNameMap["IAgCrdnConfiguredCalcParameterSet"] = IAgCrdnConfiguredCalcParameterSet

class IAgCrdnConfiguredCalcParameterSetWithRate(object):
    """Crdn Calc ParameterSetWithRate object interface."""

    _num_methods = 4
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsConfigured_method_offset = 1
    _get_ErrorText_method_offset = 2
    _Evaluate_Array_method_offset = 3
    _CurrentValue_Array_method_offset = 4
    _metadata = {
        "iid_data" : (5623639984810585056, 1789061729146100372),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnConfiguredCalcParameterSetWithRate."""
        initialize_from_source_object(self, sourceObject, IAgCrdnConfiguredCalcParameterSetWithRate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnConfiguredCalcParameterSetWithRate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnConfiguredCalcParameterSetWithRate, None)
    
    _get_IsConfigured_metadata = { "offset" : _get_IsConfigured_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsConfigured(self) -> bool:
        """Flag indicating whether object is configured properly for use."""
        return self._intf.get_property(IAgCrdnConfiguredCalcParameterSetWithRate._metadata, IAgCrdnConfiguredCalcParameterSetWithRate._get_IsConfigured_metadata)

    _get_ErrorText_metadata = { "offset" : _get_ErrorText_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ErrorText(self) -> str:
        """Text explaining configuration errors, if any"""
        return self._intf.get_property(IAgCrdnConfiguredCalcParameterSetWithRate._metadata, IAgCrdnConfiguredCalcParameterSetWithRate._get_ErrorText_metadata)

    _Evaluate_Array_metadata = { "offset" : _Evaluate_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Evaluate_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Computes the set of parameters and their rates at the given time, returned as an array. The last element of the array is an error flag indicator."""
        return self._intf.invoke(IAgCrdnConfiguredCalcParameterSetWithRate._metadata, IAgCrdnConfiguredCalcParameterSetWithRate._Evaluate_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _CurrentValue_Array_metadata = { "offset" : _CurrentValue_Array_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.LPSAFEARRAY_arg,) }
    def CurrentValue_Array(self, dispInterface:"IDispatch") -> list:
        """Computes the set of parameters and their rates at the interface's current time, returned as an array. The last element of the array is an error flag indicator."""
        return self._intf.invoke(IAgCrdnConfiguredCalcParameterSetWithRate._metadata, IAgCrdnConfiguredCalcParameterSetWithRate._CurrentValue_Array_metadata, dispInterface, OutArg())

    _property_names[IsConfigured] = "IsConfigured"
    _property_names[ErrorText] = "ErrorText"


agcls.AgClassCatalog.add_catalog_entry((5623639984810585056, 1789061729146100372), IAgCrdnConfiguredCalcParameterSetWithRate)
agcls.AgTypeNameMap["IAgCrdnConfiguredCalcParameterSetWithRate"] = IAgCrdnConfiguredCalcParameterSetWithRate

class IAgCrdnPluginProvider(object):
    """Vector Tool plugin provider interface."""

    _num_methods = 11
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_SourceNameDefault_method_offset = 1
    _ConfigureVector_method_offset = 2
    _ConfigureVectorWithRate_method_offset = 3
    _ConfigureAxes_method_offset = 4
    _ConfigureAxesWithRate_method_offset = 5
    _ConfigureAngle_method_offset = 6
    _ConfigureAngleWithRate_method_offset = 7
    _ConfigurePoint_method_offset = 8
    _ConfigurePointWithRate_method_offset = 9
    _ConfigureSystem_method_offset = 10
    _ConfigureSystemWithRate_method_offset = 11
    _metadata = {
        "iid_data" : (5236396295714192594, 4888220534805993905),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnPluginProvider."""
        initialize_from_source_object(self, sourceObject, IAgCrdnPluginProvider)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnPluginProvider)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnPluginProvider, None)
    
    _get_SourceNameDefault_metadata = { "offset" : _get_SourceNameDefault_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def SourceNameDefault(self) -> str:
        """Name of the instance path used by default for sourceName and refSourceName when creating IAgCrdn interfaces. Used when the input sourceName, refSourceName are input as null strings."""
        return self._intf.get_property(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._get_SourceNameDefault_metadata)

    _ConfigureVector_metadata = { "offset" : _ConfigureVector_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureVector(self, vectorName:str, sourceName:str, refAxesName:str, refAxesSourceName:str) -> "IAgCrdnConfiguredVector":
        """Creates an IAgCrdnConfiguredVector object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureVector_metadata, vectorName, sourceName, refAxesName, refAxesSourceName, OutArg())

    _ConfigureVectorWithRate_metadata = { "offset" : _ConfigureVectorWithRate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureVectorWithRate(self, vectorName:str, sourceName:str, refAxesName:str, refAxesSourceName:str) -> "IAgCrdnConfiguredVectorWithRate":
        """Creates an IAgCrdnConfiguredVectorWithRate object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureVectorWithRate_metadata, vectorName, sourceName, refAxesName, refAxesSourceName, OutArg())

    _ConfigureAxes_metadata = { "offset" : _ConfigureAxes_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureAxes(self, axesName:str, sourceName:str, refAxesName:str, refAxesSourceName:str) -> "IAgCrdnConfiguredAxes":
        """Creates an IAgCrdnConfiguredAxes object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureAxes_metadata, axesName, sourceName, refAxesName, refAxesSourceName, OutArg())

    _ConfigureAxesWithRate_metadata = { "offset" : _ConfigureAxesWithRate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureAxesWithRate(self, axesName:str, sourceName:str, refAxesName:str, refAxesSourceName:str) -> "IAgCrdnConfiguredAxesWithRate":
        """Creates an IAgCrdnConfiguredAxesWithRate object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureAxesWithRate_metadata, axesName, sourceName, refAxesName, refAxesSourceName, OutArg())

    _ConfigureAngle_metadata = { "offset" : _ConfigureAngle_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureAngle(self, angleName:str, sourceName:str) -> "IAgCrdnConfiguredAngle":
        """Creates an IAgCrdnConfiguredAngle object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureAngle_metadata, angleName, sourceName, OutArg())

    _ConfigureAngleWithRate_metadata = { "offset" : _ConfigureAngleWithRate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureAngleWithRate(self, angleName:str, sourceName:str) -> "IAgCrdnConfiguredAngleWithRate":
        """Creates an IAgCrdnConfiguredAngleWithRate object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureAngleWithRate_metadata, angleName, sourceName, OutArg())

    _ConfigurePoint_metadata = { "offset" : _ConfigurePoint_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigurePoint(self, pointName:str, sourceName:str, refSystemName:str, refSystemSourceName:str) -> "IAgCrdnConfiguredPoint":
        """Creates an IAgCrdnConfiguredPoint object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigurePoint_metadata, pointName, sourceName, refSystemName, refSystemSourceName, OutArg())

    _ConfigurePointWithRate_metadata = { "offset" : _ConfigurePointWithRate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigurePointWithRate(self, pointName:str, sourceName:str, refSystemName:str, refSystemSourceName:str) -> "IAgCrdnConfiguredPointWithRate":
        """Creates an IAgCrdnConfiguredPointWithRate object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigurePointWithRate_metadata, pointName, sourceName, refSystemName, refSystemSourceName, OutArg())

    _ConfigureSystem_metadata = { "offset" : _ConfigureSystem_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureSystem(self, systemName:str, sourceName:str, refSystemName:str, refSystemSourceName:str) -> "IAgCrdnConfiguredSystem":
        """Creates an IAgCrdnConfiguredSystem object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureSystem_metadata, systemName, sourceName, refSystemName, refSystemSourceName, OutArg())

    _ConfigureSystemWithRate_metadata = { "offset" : _ConfigureSystemWithRate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureSystemWithRate(self, systemName:str, sourceName:str, refSystemName:str, refSystemSourceName:str) -> "IAgCrdnConfiguredSystemWithRate":
        """Creates an IAgCrdnConfiguredSystemWithRate object from the given inputs."""
        return self._intf.invoke(IAgCrdnPluginProvider._metadata, IAgCrdnPluginProvider._ConfigureSystemWithRate_metadata, systemName, sourceName, refSystemName, refSystemSourceName, OutArg())

    _property_names[SourceNameDefault] = "SourceNameDefault"


agcls.AgClassCatalog.add_catalog_entry((5236396295714192594, 4888220534805993905), IAgCrdnPluginProvider)
agcls.AgTypeNameMap["IAgCrdnPluginProvider"] = IAgCrdnPluginProvider

class IAgCrdnPluginCalcProvider(object):
    """Vector Tool plugin provider interface."""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_SourceNameDefault_method_offset = 1
    _GetCalcScalar_method_offset = 2
    _GetCalcScalarWithRate_method_offset = 3
    _GetCalcParameterSet_method_offset = 4
    _GetCalcParameterSetWithRate_method_offset = 5
    _metadata = {
        "iid_data" : (5516093103064870894, 6532368084831526067),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnPluginCalcProvider."""
        initialize_from_source_object(self, sourceObject, IAgCrdnPluginCalcProvider)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnPluginCalcProvider)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnPluginCalcProvider, None)
    
    _get_SourceNameDefault_metadata = { "offset" : _get_SourceNameDefault_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def SourceNameDefault(self) -> str:
        """Name of the instance path used by default for sourceName and refSourceName when creating IAgCrdn interfaces. Used when the input sourceName, refSourceName are input as null strings."""
        return self._intf.get_property(IAgCrdnPluginCalcProvider._metadata, IAgCrdnPluginCalcProvider._get_SourceNameDefault_metadata)

    _GetCalcScalar_metadata = { "offset" : _GetCalcScalar_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetCalcScalar(self, name:str, sourceName:str) -> "IAgCrdnConfiguredCalcScalar":
        """Creates an IAgCrdnConfiguredCalcScalar handle to the named Calc Scalar."""
        return self._intf.invoke(IAgCrdnPluginCalcProvider._metadata, IAgCrdnPluginCalcProvider._GetCalcScalar_metadata, name, sourceName, OutArg())

    _GetCalcScalarWithRate_metadata = { "offset" : _GetCalcScalarWithRate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetCalcScalarWithRate(self, name:str, sourceName:str) -> "IAgCrdnConfiguredCalcScalarWithRate":
        """Creates an IAgCrdnConfiguredCalcScalarWithRate handle to the named Calc Scalar."""
        return self._intf.invoke(IAgCrdnPluginCalcProvider._metadata, IAgCrdnPluginCalcProvider._GetCalcScalarWithRate_metadata, name, sourceName, OutArg())

    _GetCalcParameterSet_metadata = { "offset" : _GetCalcParameterSet_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetCalcParameterSet(self, name:str, sourceName:str) -> "IAgCrdnConfiguredCalcParameterSet":
        """Creates an IAgCrdnConfiguredCalcParameterSet handle to the named Calc ParameterSet."""
        return self._intf.invoke(IAgCrdnPluginCalcProvider._metadata, IAgCrdnPluginCalcProvider._GetCalcParameterSet_metadata, name, sourceName, OutArg())

    _GetCalcParameterSetWithRate_metadata = { "offset" : _GetCalcParameterSetWithRate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetCalcParameterSetWithRate(self, name:str, sourceName:str) -> "IAgCrdnConfiguredCalcParameterSetWithRate":
        """Creates an IAgCrdnConfiguredCalcParameterSetWithRate handle to the named Calc ParameterSet."""
        return self._intf.invoke(IAgCrdnPluginCalcProvider._metadata, IAgCrdnPluginCalcProvider._GetCalcParameterSetWithRate_metadata, name, sourceName, OutArg())

    _property_names[SourceNameDefault] = "SourceNameDefault"


agcls.AgClassCatalog.add_catalog_entry((5516093103064870894, 6532368084831526067), IAgCrdnPluginCalcProvider)
agcls.AgTypeNameMap["IAgCrdnPluginCalcProvider"] = IAgCrdnPluginCalcProvider

class IAgCrdnVectorPluginResultReg(object):
    """COM Plugin Result interface for the Register method of IAgCrdnVectorPlugin."""

    _num_methods = 13
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_ObjectPath_method_offset = 1
    _get_ParentPath_method_offset = 2
    _get_GrandParentPath_method_offset = 3
    _get_ShortDescription_method_offset = 4
    _set_ShortDescription_method_offset = 5
    _get_LongDescription_method_offset = 6
    _set_LongDescription_method_offset = 7
    _set_Dimension_method_offset = 8
    _SetRefAxes_method_offset = 9
    _ClearAvailability_method_offset = 10
    _AddAvailabilityInterval_method_offset = 11
    _ClearSpecialTimes_method_offset = 12
    _AddSpecialTime_method_offset = 13
    _metadata = {
        "iid_data" : (5031332653451930878, 6249932084687772859),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnVectorPluginResultReg."""
        initialize_from_source_object(self, sourceObject, IAgCrdnVectorPluginResultReg)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnVectorPluginResultReg)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnVectorPluginResultReg, None)
    
    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._set_LongDescription_metadata, newDescription)

    _get_Dimension_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def Dimension(self) -> None:
        """Dimension is a write-only property."""
        raise RuntimeError("Dimension is a write-only property.")


    _set_Dimension_metadata = { "offset" : _set_Dimension_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Dimension.setter
    def Dimension(self, dimension:str) -> None:
        """Sets the dimension of the vector."""
        return self._intf.set_property(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._set_Dimension_metadata, dimension)

    _SetRefAxes_metadata = { "offset" : _SetRefAxes_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetRefAxes(self, name:str, sourcePath:str) -> None:
        """Sets the reference axes of the vector."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._SetRefAxes_metadata, name, sourcePath)

    _ClearAvailability_metadata = { "offset" : _ClearAvailability_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearAvailability(self) -> None:
        """Clears any availability intervals that may have been set. Vector is considered available at all times."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._ClearAvailability_metadata, )

    _AddAvailabilityInterval_metadata = { "offset" : _AddAvailabilityInterval_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddAvailabilityInterval(self, dateAbbrv:str, startDate:str, stopDate:str) -> None:
        """Adds an availability interval. The Vector is available at a given time only if the time is within one of the vector's availability intervals."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._AddAvailabilityInterval_metadata, dateAbbrv, startDate, stopDate)

    _ClearSpecialTimes_metadata = { "offset" : _ClearSpecialTimes_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearSpecialTimes(self) -> None:
        """Clears any special times that may have been set."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._ClearSpecialTimes_metadata, )

    _AddSpecialTime_metadata = { "offset" : _AddSpecialTime_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddSpecialTime(self, dateAbbrv:str, specialTime:str) -> None:
        """Adds a special time that will be incorporated during sampling of the vector's value."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReg._metadata, IAgCrdnVectorPluginResultReg._AddSpecialTime_metadata, dateAbbrv, specialTime)

    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"
    _property_names[Dimension] = "Dimension"


agcls.AgClassCatalog.add_catalog_entry((5031332653451930878, 6249932084687772859), IAgCrdnVectorPluginResultReg)
agcls.AgTypeNameMap["IAgCrdnVectorPluginResultReg"] = IAgCrdnVectorPluginResultReg

class IAgCrdnVectorPluginResultReset(object):
    """COM Plugin Result interface for the Reset method of IAgCrdnVectorPlugin."""

    _num_methods = 14
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _DayCount_method_offset = 10
    _DayCount_Array_method_offset = 11
    _DateElements_method_offset = 12
    _DateElements_Array_method_offset = 13
    _DateString_method_offset = 14
    _metadata = {
        "iid_data" : (5046726763690955604, 12279091517906714813),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnVectorPluginResultReset."""
        initialize_from_source_object(self, sourceObject, IAgCrdnVectorPluginResultReset)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnVectorPluginResultReset)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnVectorPluginResultReset, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._set_LongDescription_metadata, newDescription)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnVectorPluginResultReset._metadata, IAgCrdnVectorPluginResultReset._DateString_metadata, dateAbbrv, OutArg())

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((5046726763690955604, 12279091517906714813), IAgCrdnVectorPluginResultReset)
agcls.AgTypeNameMap["IAgCrdnVectorPluginResultReset"] = IAgCrdnVectorPluginResultReset

class IAgCrdnVectorPluginResultEval(object):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnVectorPlugin."""

    _num_methods = 16
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _SetVectorComponents_method_offset = 10
    _SetVectorRateComponents_method_offset = 11
    _DayCount_method_offset = 12
    _DayCount_Array_method_offset = 13
    _DateElements_method_offset = 14
    _DateElements_Array_method_offset = 15
    _DateString_method_offset = 16
    _metadata = {
        "iid_data" : (5302951651076984393, 15684970414857663389),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnVectorPluginResultEval."""
        initialize_from_source_object(self, sourceObject, IAgCrdnVectorPluginResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnVectorPluginResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnVectorPluginResultEval, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._set_LongDescription_metadata, newDescription)

    _SetVectorComponents_metadata = { "offset" : _SetVectorComponents_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetVectorComponents(self, x:float, y:float, z:float) -> None:
        """Set the vector components in internal units."""
        return self._intf.invoke(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._SetVectorComponents_metadata, x, y, z)

    _SetVectorRateComponents_metadata = { "offset" : _SetVectorRateComponents_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetVectorRateComponents(self, x:float, y:float, z:float) -> None:
        """Set the vector rate components in internal units."""
        return self._intf.invoke(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._SetVectorRateComponents_metadata, x, y, z)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnVectorPluginResultEval._metadata, IAgCrdnVectorPluginResultEval._DateString_metadata, dateAbbrv, OutArg())

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((5302951651076984393, 15684970414857663389), IAgCrdnVectorPluginResultEval)
agcls.AgTypeNameMap["IAgCrdnVectorPluginResultEval"] = IAgCrdnVectorPluginResultEval

class IAgCrdnPointPluginResultReg(object):
    """COM Plugin Result interface for the Register method of IAgCrdnPointPlugin."""

    _num_methods = 12
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_ObjectPath_method_offset = 1
    _get_ParentPath_method_offset = 2
    _get_GrandParentPath_method_offset = 3
    _get_ShortDescription_method_offset = 4
    _set_ShortDescription_method_offset = 5
    _get_LongDescription_method_offset = 6
    _set_LongDescription_method_offset = 7
    _SetRefSystem_method_offset = 8
    _ClearAvailability_method_offset = 9
    _AddAvailabilityInterval_method_offset = 10
    _ClearSpecialTimes_method_offset = 11
    _AddSpecialTime_method_offset = 12
    _metadata = {
        "iid_data" : (5157032795674596793, 3178833031857161368),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnPointPluginResultReg."""
        initialize_from_source_object(self, sourceObject, IAgCrdnPointPluginResultReg)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnPointPluginResultReg)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnPointPluginResultReg, None)
    
    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._set_LongDescription_metadata, newDescription)

    _SetRefSystem_metadata = { "offset" : _SetRefSystem_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetRefSystem(self, name:str, sourcePath:str) -> None:
        """Sets the reference system for the point."""
        return self._intf.invoke(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._SetRefSystem_metadata, name, sourcePath)

    _ClearAvailability_metadata = { "offset" : _ClearAvailability_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearAvailability(self) -> None:
        """Clears any availability intervals that may have been set. Point is considered available at all times."""
        return self._intf.invoke(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._ClearAvailability_metadata, )

    _AddAvailabilityInterval_metadata = { "offset" : _AddAvailabilityInterval_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddAvailabilityInterval(self, dateAbbrv:str, startDate:str, stopDate:str) -> None:
        """Adds an availability interval. The Point is available at a given time only if the time is within one of the point's availability intervals."""
        return self._intf.invoke(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._AddAvailabilityInterval_metadata, dateAbbrv, startDate, stopDate)

    _ClearSpecialTimes_metadata = { "offset" : _ClearSpecialTimes_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearSpecialTimes(self) -> None:
        """Clears any special times that may have been set."""
        return self._intf.invoke(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._ClearSpecialTimes_metadata, )

    _AddSpecialTime_metadata = { "offset" : _AddSpecialTime_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddSpecialTime(self, dateAbbrv:str, specialTime:str) -> None:
        """Adds a special time that will be incorporated during sampling of the point's location."""
        return self._intf.invoke(IAgCrdnPointPluginResultReg._metadata, IAgCrdnPointPluginResultReg._AddSpecialTime_metadata, dateAbbrv, specialTime)

    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((5157032795674596793, 3178833031857161368), IAgCrdnPointPluginResultReg)
agcls.AgTypeNameMap["IAgCrdnPointPluginResultReg"] = IAgCrdnPointPluginResultReg

class IAgCrdnPointPluginResultReset(object):
    """COM Plugin Result interface for the Reset method of IAgCrdnPointPlugin."""

    _num_methods = 14
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _DayCount_method_offset = 10
    _DayCount_Array_method_offset = 11
    _DateElements_method_offset = 12
    _DateElements_Array_method_offset = 13
    _DateString_method_offset = 14
    _metadata = {
        "iid_data" : (5099103406003327315, 9643272195559671168),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnPointPluginResultReset."""
        initialize_from_source_object(self, sourceObject, IAgCrdnPointPluginResultReset)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnPointPluginResultReset)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnPointPluginResultReset, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._set_LongDescription_metadata, newDescription)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnPointPluginResultReset._metadata, IAgCrdnPointPluginResultReset._DateString_metadata, dateAbbrv, OutArg())

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((5099103406003327315, 9643272195559671168), IAgCrdnPointPluginResultReset)
agcls.AgTypeNameMap["IAgCrdnPointPluginResultReset"] = IAgCrdnPointPluginResultReset

class IAgCrdnPointPluginResultEval(object):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnPointPlugin."""

    _num_methods = 16
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _SetPosition_method_offset = 10
    _SetVelocity_method_offset = 11
    _DayCount_method_offset = 12
    _DayCount_Array_method_offset = 13
    _DateElements_method_offset = 14
    _DateElements_Array_method_offset = 15
    _DateString_method_offset = 16
    _metadata = {
        "iid_data" : (5374856891979150058, 3682083549642659748),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnPointPluginResultEval."""
        initialize_from_source_object(self, sourceObject, IAgCrdnPointPluginResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnPointPluginResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnPointPluginResultEval, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._set_LongDescription_metadata, newDescription)

    _SetPosition_metadata = { "offset" : _SetPosition_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetPosition(self, x:float, y:float, z:float) -> None:
        """Set the position components in meters."""
        return self._intf.invoke(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._SetPosition_metadata, x, y, z)

    _SetVelocity_metadata = { "offset" : _SetVelocity_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetVelocity(self, x:float, y:float, z:float) -> None:
        """Set the velocity components in meters/sec."""
        return self._intf.invoke(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._SetVelocity_metadata, x, y, z)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnPointPluginResultEval._metadata, IAgCrdnPointPluginResultEval._DateString_metadata, dateAbbrv, OutArg())

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((5374856891979150058, 3682083549642659748), IAgCrdnPointPluginResultEval)
agcls.AgTypeNameMap["IAgCrdnPointPluginResultEval"] = IAgCrdnPointPluginResultEval

class IAgCrdnAxesPluginResultReg(object):
    """COM Plugin Result interface for the Register method of IAgCrdnAxesPlugin."""

    _num_methods = 12
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_ObjectPath_method_offset = 1
    _get_ParentPath_method_offset = 2
    _get_GrandParentPath_method_offset = 3
    _get_ShortDescription_method_offset = 4
    _set_ShortDescription_method_offset = 5
    _get_LongDescription_method_offset = 6
    _set_LongDescription_method_offset = 7
    _SetRefAxes_method_offset = 8
    _ClearAvailability_method_offset = 9
    _AddAvailabilityInterval_method_offset = 10
    _ClearSpecialTimes_method_offset = 11
    _AddSpecialTime_method_offset = 12
    _metadata = {
        "iid_data" : (5633457277252784325, 7623930531112591546),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnAxesPluginResultReg."""
        initialize_from_source_object(self, sourceObject, IAgCrdnAxesPluginResultReg)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnAxesPluginResultReg)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnAxesPluginResultReg, None)
    
    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._set_LongDescription_metadata, newDescription)

    _SetRefAxes_metadata = { "offset" : _SetRefAxes_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetRefAxes(self, name:str, sourcePath:str) -> None:
        """Sets the reference axes of the vector."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._SetRefAxes_metadata, name, sourcePath)

    _ClearAvailability_metadata = { "offset" : _ClearAvailability_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearAvailability(self) -> None:
        """Clears any availability intervals that may have been set. Axes is considered available at all times."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._ClearAvailability_metadata, )

    _AddAvailabilityInterval_metadata = { "offset" : _AddAvailabilityInterval_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddAvailabilityInterval(self, dateAbbrv:str, startDate:str, stopDate:str) -> None:
        """Adds an availability interval. The Axes is available at a given time only if the time is within one of the vector's availability intervals."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._AddAvailabilityInterval_metadata, dateAbbrv, startDate, stopDate)

    _ClearSpecialTimes_metadata = { "offset" : _ClearSpecialTimes_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearSpecialTimes(self) -> None:
        """Clears any special times that may have been set."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._ClearSpecialTimes_metadata, )

    _AddSpecialTime_metadata = { "offset" : _AddSpecialTime_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddSpecialTime(self, dateAbbrv:str, specialTime:str) -> None:
        """Adds a special time that will be incorporated during sampling of the vector's value."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReg._metadata, IAgCrdnAxesPluginResultReg._AddSpecialTime_metadata, dateAbbrv, specialTime)

    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((5633457277252784325, 7623930531112591546), IAgCrdnAxesPluginResultReg)
agcls.AgTypeNameMap["IAgCrdnAxesPluginResultReg"] = IAgCrdnAxesPluginResultReg

class IAgCrdnAxesPluginResultReset(object):
    """COM Plugin Result interface for the Reset method of IAgCrdnAxesPlugin."""

    _num_methods = 14
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _DayCount_method_offset = 10
    _DayCount_Array_method_offset = 11
    _DateElements_method_offset = 12
    _DateElements_Array_method_offset = 13
    _DateString_method_offset = 14
    _metadata = {
        "iid_data" : (4758641436252222514, 11630416938870231216),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnAxesPluginResultReset."""
        initialize_from_source_object(self, sourceObject, IAgCrdnAxesPluginResultReset)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnAxesPluginResultReset)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnAxesPluginResultReset, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._set_LongDescription_metadata, newDescription)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnAxesPluginResultReset._metadata, IAgCrdnAxesPluginResultReset._DateString_metadata, dateAbbrv, OutArg())

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((4758641436252222514, 11630416938870231216), IAgCrdnAxesPluginResultReset)
agcls.AgTypeNameMap["IAgCrdnAxesPluginResultReset"] = IAgCrdnAxesPluginResultReset

class IAgCrdnAxesPluginResultEval(object):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnAxesPlugin."""

    _num_methods = 19
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _DayCount_method_offset = 10
    _DayCount_Array_method_offset = 11
    _DateElements_method_offset = 12
    _DateElements_Array_method_offset = 13
    _DateString_method_offset = 14
    _SetQuaternion_method_offset = 15
    _EulerRotate_method_offset = 16
    _SetDCM_method_offset = 17
    _SetAngularVelocity_method_offset = 18
    _SetAngularVelocityUsingRefAxes_method_offset = 19
    _metadata = {
        "iid_data" : (4675268739584785629, 1997124521342418351),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnAxesPluginResultEval."""
        initialize_from_source_object(self, sourceObject, IAgCrdnAxesPluginResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnAxesPluginResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnAxesPluginResultEval, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._set_LongDescription_metadata, newDescription)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._DateString_metadata, dateAbbrv, OutArg())

    _SetQuaternion_metadata = { "offset" : _SetQuaternion_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetQuaternion(self, q1:float, q2:float, q3:float, q4:float) -> None:
        """Set the orientation using a quaternion representing the rotation to these axes from the references axes. (q1,q2,q3) is the vector part; q4 is the scalar part."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._SetQuaternion_metadata, q1, q2, q3, q4)

    _EulerRotate_metadata = { "offset" : _EulerRotate_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECrdnEulerSequence), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def EulerRotate(self, sequence:"AgECrdnEulerSequence", first:float, second:float, third:float) -> None:
        """Sets the orientation using a sequence of euler rotations."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._EulerRotate_metadata, sequence, first, second, third)

    _SetDCM_metadata = { "offset" : _SetDCM_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetDCM(self, xx:float, xy:float, xz:float, yx:float, yy:float, yz:float, zx:float, zy:float, zz:float) -> None:
        """Sets the orientation using a direction cosine matrix representing the rotation to these axes from the references axes."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._SetDCM_metadata, xx, xy, xz, yx, yy, yz, zx, zy, zz)

    _SetAngularVelocity_metadata = { "offset" : _SetAngularVelocity_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetAngularVelocity(self, wx:float, wy:float, wz:float) -> None:
        """Set the angular velocity in rad/sec. The components are to be specified with respect to this Axes object."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._SetAngularVelocity_metadata, wx, wy, wz)

    _SetAngularVelocityUsingRefAxes_metadata = { "offset" : _SetAngularVelocityUsingRefAxes_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetAngularVelocityUsingRefAxes(self, wx:float, wy:float, wz:float) -> None:
        """Set the angular velocity in rad/sec. The components are to be specified with respect to the RefAxes."""
        return self._intf.invoke(IAgCrdnAxesPluginResultEval._metadata, IAgCrdnAxesPluginResultEval._SetAngularVelocityUsingRefAxes_metadata, wx, wy, wz)

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"


agcls.AgClassCatalog.add_catalog_entry((4675268739584785629, 1997124521342418351), IAgCrdnAxesPluginResultEval)
agcls.AgTypeNameMap["IAgCrdnAxesPluginResultEval"] = IAgCrdnAxesPluginResultEval

class IAgCrdnCalcScalarPluginResultReg(object):
    """COM Plugin Result interface for the Register method of IAgCrdnCalcScalarPlugin."""

    _num_methods = 15
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_ObjectPath_method_offset = 1
    _get_ParentPath_method_offset = 2
    _get_GrandParentPath_method_offset = 3
    _get_ShortDescription_method_offset = 4
    _set_ShortDescription_method_offset = 5
    _get_LongDescription_method_offset = 6
    _set_LongDescription_method_offset = 7
    _ClearAvailability_method_offset = 8
    _AddAvailabilityInterval_method_offset = 9
    _ClearSpecialTimes_method_offset = 10
    _AddSpecialTime_method_offset = 11
    _set_Dimension_method_offset = 12
    _get_Dimension_method_offset = 13
    _get_UnitAbbrv_method_offset = 14
    _SetUnits_method_offset = 15
    _metadata = {
        "iid_data" : (5639868515319338284, 15835748382135218840),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnCalcScalarPluginResultReg."""
        initialize_from_source_object(self, sourceObject, IAgCrdnCalcScalarPluginResultReg)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnCalcScalarPluginResultReg)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnCalcScalarPluginResultReg, None)
    
    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Not supported by central bodies."""
        return self._intf.set_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._set_LongDescription_metadata, newDescription)

    _ClearAvailability_metadata = { "offset" : _ClearAvailability_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearAvailability(self) -> None:
        """Clears any availability intervals that may have been set. Point is considered available at all times."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._ClearAvailability_metadata, )

    _AddAvailabilityInterval_metadata = { "offset" : _AddAvailabilityInterval_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddAvailabilityInterval(self, dateAbbrv:str, startDate:str, stopDate:str) -> None:
        """Adds an availability interval. The Point is available at a given time only if the time is within one of the point's availability intervals."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._AddAvailabilityInterval_metadata, dateAbbrv, startDate, stopDate)

    _ClearSpecialTimes_metadata = { "offset" : _ClearSpecialTimes_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearSpecialTimes(self) -> None:
        """Clears any special times that may have been set."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._ClearSpecialTimes_metadata, )

    _AddSpecialTime_metadata = { "offset" : _AddSpecialTime_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def AddSpecialTime(self, dateAbbrv:str, specialTime:str) -> None:
        """Adds a special time that will be incorporated during sampling of the point's location."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._AddSpecialTime_metadata, dateAbbrv, specialTime)

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """Name of the dimension."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._get_Dimension_metadata)

    _set_Dimension_metadata = { "offset" : _set_Dimension_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Dimension.setter
    def Dimension(self, dimension:str) -> None:
        """Name of the dimension."""
        return self._intf.set_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._set_Dimension_metadata, dimension)

    _get_UnitAbbrv_metadata = { "offset" : _get_UnitAbbrv_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def UnitAbbrv(self) -> str:
        """Unit abbreviation for the current units."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._get_UnitAbbrv_metadata)

    _SetUnits_metadata = { "offset" : _SetUnits_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetUnits(self, unitAbbrv:str) -> bool:
        """Sets the current units."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReg._metadata, IAgCrdnCalcScalarPluginResultReg._SetUnits_metadata, unitAbbrv, OutArg())

    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"
    _property_names[Dimension] = "Dimension"
    _property_names[UnitAbbrv] = "UnitAbbrv"


agcls.AgClassCatalog.add_catalog_entry((5639868515319338284, 15835748382135218840), IAgCrdnCalcScalarPluginResultReg)
agcls.AgTypeNameMap["IAgCrdnCalcScalarPluginResultReg"] = IAgCrdnCalcScalarPluginResultReg

class IAgCrdnCalcScalarPluginResultReset(object):
    """COM Plugin Result interface for the Reset method of IAgCrdnCalcScalarPlugin."""

    _num_methods = 17
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _DayCount_method_offset = 10
    _DayCount_Array_method_offset = 11
    _DateElements_method_offset = 12
    _DateElements_Array_method_offset = 13
    _DateString_method_offset = 14
    _get_Dimension_method_offset = 15
    _get_UnitAbbrv_method_offset = 16
    _SetUnits_method_offset = 17
    _metadata = {
        "iid_data" : (5017418714708135115, 14411931180496256660),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnCalcScalarPluginResultReset."""
        initialize_from_source_object(self, sourceObject, IAgCrdnCalcScalarPluginResultReset)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnCalcScalarPluginResultReset)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnCalcScalarPluginResultReset, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._set_LongDescription_metadata, newDescription)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._DateString_metadata, dateAbbrv, OutArg())

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """Name of the dimension."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_Dimension_metadata)

    _get_UnitAbbrv_metadata = { "offset" : _get_UnitAbbrv_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def UnitAbbrv(self) -> str:
        """Unit abbreviation for the current units."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._get_UnitAbbrv_metadata)

    _SetUnits_metadata = { "offset" : _SetUnits_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetUnits(self, unitAbbrv:str) -> bool:
        """Sets the current units."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultReset._metadata, IAgCrdnCalcScalarPluginResultReset._SetUnits_metadata, unitAbbrv, OutArg())

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"
    _property_names[Dimension] = "Dimension"
    _property_names[UnitAbbrv] = "UnitAbbrv"


agcls.AgClassCatalog.add_catalog_entry((5017418714708135115, 14411931180496256660), IAgCrdnCalcScalarPluginResultReset)
agcls.AgTypeNameMap["IAgCrdnCalcScalarPluginResultReset"] = IAgCrdnCalcScalarPluginResultReset

class IAgCrdnCalcScalarPluginResultEval(object):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnCalcScalarPlugin."""

    _num_methods = 19
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_CalcToolProvider_method_offset = 2
    _get_ObjectPath_method_offset = 3
    _get_ParentPath_method_offset = 4
    _get_GrandParentPath_method_offset = 5
    _get_ShortDescription_method_offset = 6
    _set_ShortDescription_method_offset = 7
    _get_LongDescription_method_offset = 8
    _set_LongDescription_method_offset = 9
    _DayCount_method_offset = 10
    _DayCount_Array_method_offset = 11
    _DateElements_method_offset = 12
    _DateElements_Array_method_offset = 13
    _DateString_method_offset = 14
    _get_Dimension_method_offset = 15
    _get_UnitAbbrv_method_offset = 16
    _SetUnits_method_offset = 17
    _SetValue_method_offset = 18
    _SetValueAndRate_method_offset = 19
    _metadata = {
        "iid_data" : (5526840046973688058, 4004024197764275104),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCrdnCalcScalarPluginResultEval."""
        initialize_from_source_object(self, sourceObject, IAgCrdnCalcScalarPluginResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCrdnCalcScalarPluginResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCrdnCalcScalarPluginResultEval, None)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_VectorToolProvider_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_CalcToolProvider_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The object path of the object."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_ObjectPath_metadata)

    _get_ParentPath_metadata = { "offset" : _get_ParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ParentPath(self) -> str:
        """The object path of the parent of the object. Returns 'No Object Available' if the parent is the scenario."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_ParentPath_metadata)

    _get_GrandParentPath_metadata = { "offset" : _get_GrandParentPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def GrandParentPath(self) -> str:
        """The object path of the parent of the parent of the object. Returns 'No Object Available' if the grandparent is or above the scenario."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_GrandParentPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object. Cannot be set for central bodies."""
        return self._intf.set_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._set_LongDescription_metadata, newDescription)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._DateString_metadata, dateAbbrv, OutArg())

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """Name of the dimension."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_Dimension_metadata)

    _get_UnitAbbrv_metadata = { "offset" : _get_UnitAbbrv_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def UnitAbbrv(self) -> str:
        """Unit abbreviation for the current units."""
        return self._intf.get_property(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._get_UnitAbbrv_metadata)

    _SetUnits_metadata = { "offset" : _SetUnits_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetUnits(self, unitAbbrv:str) -> bool:
        """Sets the current units."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._SetUnits_metadata, unitAbbrv, OutArg())

    _SetValue_metadata = { "offset" : _SetValue_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetValue(self, value:float) -> None:
        """Sets the value in the current units."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._SetValue_metadata, value)

    _SetValueAndRate_metadata = { "offset" : _SetValueAndRate_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetValueAndRate(self, value:float, valueRate:float) -> None:
        """Sets the value and valueRate in current units and current units per sec."""
        return self._intf.invoke(IAgCrdnCalcScalarPluginResultEval._metadata, IAgCrdnCalcScalarPluginResultEval._SetValueAndRate_metadata, value, valueRate)

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[CalcToolProvider] = "CalcToolProvider"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ParentPath] = "ParentPath"
    _property_names[GrandParentPath] = "GrandParentPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"
    _property_names[Dimension] = "Dimension"
    _property_names[UnitAbbrv] = "UnitAbbrv"


agcls.AgClassCatalog.add_catalog_entry((5526840046973688058, 4004024197764275104), IAgCrdnCalcScalarPluginResultEval)
agcls.AgTypeNameMap["IAgCrdnCalcScalarPluginResultEval"] = IAgCrdnCalcScalarPluginResultEval


class IAgCrdnVectorPlugin(object):
    """
    COM Plugin interface for a Crdn Vector.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered just before the first computational event trigger."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Register(self, result:"IAgCrdnVectorPluginResultReg") -> None:
        """Triggered after Init() to allow setting for Dimension and Reference Axes."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Reset(self, result:"IAgCrdnVectorPluginResultReset") -> bool:
        """Triggered on a Reset event."""
        raise STKPluginMethodNotImplementedError("Reset was not implemented.")

    def Evaluate(self, result:"IAgCrdnVectorPluginResultEval") -> bool:
        """Triggered when the plugin is evaluated for the vector components"""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is destroyed."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")


class IAgCrdnPointPlugin(object):
    """
    COM Plugin interface for a Crdn Point.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered just before the first computational event trigger."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Register(self, result:"IAgCrdnPointPluginResultReg") -> None:
        """Triggered after Init() to allow setting of Reference System."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Reset(self, result:"IAgCrdnPointPluginResultReset") -> bool:
        """Triggered on a Reset event."""
        raise STKPluginMethodNotImplementedError("Reset was not implemented.")

    def Evaluate(self, result:"IAgCrdnPointPluginResultEval") -> bool:
        """Triggered when the plugin is evaluated for the position (and velocity) components"""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is destroyed."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")


class IAgCrdnAxesPlugin(object):
    """
    COM Plugin interface for a Crdn Axes.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered just before the first computational event trigger."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Register(self, result:"IAgCrdnAxesPluginResultReg") -> None:
        """Triggered after Init() to allow setting of Reference Axes."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Reset(self, result:"IAgCrdnAxesPluginResultReset") -> bool:
        """Triggered on a Reset event."""
        raise STKPluginMethodNotImplementedError("Reset was not implemented.")

    def Evaluate(self, result:"IAgCrdnAxesPluginResultEval") -> bool:
        """Triggered when the plugin is evaluated for the axes orientation"""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is destroyed."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")


class IAgCrdnCalcScalarPlugin(object):
    """
    COM Plugin interface for a Crdn CalcScalar.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered just before the first computational event trigger."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Register(self, result:"IAgCrdnCalcScalarPluginResultReg") -> None:
        """Triggered after Init() to allow setting of any registration information."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Reset(self, result:"IAgCrdnCalcScalarPluginResultReset") -> bool:
        """Triggered on a Reset event."""
        raise STKPluginMethodNotImplementedError("Reset was not implemented.")

    def Evaluate(self, result:"IAgCrdnCalcScalarPluginResultEval") -> bool:
        """Triggered when the plugin is evaluated for the value and valueRate"""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is destroyed."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")




class AgCrdnConfiguredVector(IAgCrdnConfiguredVector, SupportsDeleteCallback):
    """Crdn Vector object which computes its components"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredVector."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredVector.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredVector._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredVector, [IAgCrdnConfiguredVector])

agcls.AgClassCatalog.add_catalog_entry((4909242749793136085, 5966423390811996045), AgCrdnConfiguredVector)
agcls.AgTypeNameMap["AgCrdnConfiguredVector"] = AgCrdnConfiguredVector

class AgCrdnConfiguredVectorWithRate(IAgCrdnConfiguredVectorWithRate, SupportsDeleteCallback):
    """Crdn Vector object which computes its components and rate"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredVectorWithRate."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredVectorWithRate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredVectorWithRate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredVectorWithRate, [IAgCrdnConfiguredVectorWithRate])

agcls.AgClassCatalog.add_catalog_entry((5528565023275168784, 485316668328551857), AgCrdnConfiguredVectorWithRate)
agcls.AgTypeNameMap["AgCrdnConfiguredVectorWithRate"] = AgCrdnConfiguredVectorWithRate

class AgCrdnConfiguredAxes(IAgCrdnConfiguredAxes, SupportsDeleteCallback):
    """Crdn Axes object which computes its quaternion"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredAxes."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredAxes.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredAxes._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredAxes, [IAgCrdnConfiguredAxes])

agcls.AgClassCatalog.add_catalog_entry((5651460593382138285, 15721440336700285079), AgCrdnConfiguredAxes)
agcls.AgTypeNameMap["AgCrdnConfiguredAxes"] = AgCrdnConfiguredAxes

class AgCrdnConfiguredAxesWithRate(IAgCrdnConfiguredAxesWithRate, SupportsDeleteCallback):
    """Crdn Axes object which computes its quaternion and angular velocity"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredAxesWithRate."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredAxesWithRate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredAxesWithRate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredAxesWithRate, [IAgCrdnConfiguredAxesWithRate])

agcls.AgClassCatalog.add_catalog_entry((4733634185532977537, 16641755601208973973), AgCrdnConfiguredAxesWithRate)
agcls.AgTypeNameMap["AgCrdnConfiguredAxesWithRate"] = AgCrdnConfiguredAxesWithRate

class AgCrdnConfiguredAngle(IAgCrdnConfiguredAngle, SupportsDeleteCallback):
    """Crdn Angle object which computes its angle."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredAngle."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredAngle.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredAngle._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredAngle, [IAgCrdnConfiguredAngle])

agcls.AgClassCatalog.add_catalog_entry((4922223439274107918, 6584714316101768882), AgCrdnConfiguredAngle)
agcls.AgTypeNameMap["AgCrdnConfiguredAngle"] = AgCrdnConfiguredAngle

class AgCrdnConfiguredAngleWithRate(IAgCrdnConfiguredAngleWithRate, SupportsDeleteCallback):
    """Crdn Angle object which computes its angle and rate."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredAngleWithRate."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredAngleWithRate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredAngleWithRate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredAngleWithRate, [IAgCrdnConfiguredAngleWithRate])

agcls.AgClassCatalog.add_catalog_entry((4835127390517455175, 18253684874935875744), AgCrdnConfiguredAngleWithRate)
agcls.AgTypeNameMap["AgCrdnConfiguredAngleWithRate"] = AgCrdnConfiguredAngleWithRate

class AgCrdnConfiguredPoint(IAgCrdnConfiguredPoint, SupportsDeleteCallback):
    """Crdn Point object which computes its components"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredPoint."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredPoint.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredPoint._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredPoint, [IAgCrdnConfiguredPoint])

agcls.AgClassCatalog.add_catalog_entry((5455243240674485463, 1978124539836202685), AgCrdnConfiguredPoint)
agcls.AgTypeNameMap["AgCrdnConfiguredPoint"] = AgCrdnConfiguredPoint

class AgCrdnConfiguredPointWithRate(IAgCrdnConfiguredPointWithRate, SupportsDeleteCallback):
    """Crdn Point object which computes its components and rate"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredPointWithRate."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredPointWithRate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredPointWithRate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredPointWithRate, [IAgCrdnConfiguredPointWithRate])

agcls.AgClassCatalog.add_catalog_entry((4962464274421250242, 17275467357548584073), AgCrdnConfiguredPointWithRate)
agcls.AgTypeNameMap["AgCrdnConfiguredPointWithRate"] = AgCrdnConfiguredPointWithRate

class AgCrdnConfiguredSystem(IAgCrdnConfiguredSystem, SupportsDeleteCallback):
    """Crdn System object which computes its components"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredSystem."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredSystem.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredSystem._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredSystem, [IAgCrdnConfiguredSystem])

agcls.AgClassCatalog.add_catalog_entry((4632198800248192082, 13661439920429562243), AgCrdnConfiguredSystem)
agcls.AgTypeNameMap["AgCrdnConfiguredSystem"] = AgCrdnConfiguredSystem

class AgCrdnConfiguredSystemWithRate(IAgCrdnConfiguredSystemWithRate, SupportsDeleteCallback):
    """Crdn System object which computes its components and rate"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredSystemWithRate."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredSystemWithRate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredSystemWithRate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredSystemWithRate, [IAgCrdnConfiguredSystemWithRate])

agcls.AgClassCatalog.add_catalog_entry((5685940957861160090, 14101479822484353721), AgCrdnConfiguredSystemWithRate)
agcls.AgTypeNameMap["AgCrdnConfiguredSystemWithRate"] = AgCrdnConfiguredSystemWithRate

class AgCrdnPluginProvider(IAgCrdnPluginProvider, SupportsDeleteCallback):
    """Vector Tool plugin provider."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnPluginProvider."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnPluginProvider.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnPluginProvider._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnPluginProvider, [IAgCrdnPluginProvider])

agcls.AgClassCatalog.add_catalog_entry((5606491010355030881, 5067824799259069870), AgCrdnPluginProvider)
agcls.AgTypeNameMap["AgCrdnPluginProvider"] = AgCrdnPluginProvider

class AgCrdnConfiguredCalcScalar(IAgCrdnConfiguredCalcScalar, SupportsDeleteCallback):
    """Crdn Calc Scalar object which computes its value"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredCalcScalar."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredCalcScalar.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredCalcScalar._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredCalcScalar, [IAgCrdnConfiguredCalcScalar])

agcls.AgClassCatalog.add_catalog_entry((4680204567670858881, 2912121486285317820), AgCrdnConfiguredCalcScalar)
agcls.AgTypeNameMap["AgCrdnConfiguredCalcScalar"] = AgCrdnConfiguredCalcScalar

class AgCrdnConfiguredCalcScalarWithRate(IAgCrdnConfiguredCalcScalarWithRate, SupportsDeleteCallback):
    """Crdn Calc Scalar object which computes its value and rate"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredCalcScalarWithRate."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredCalcScalarWithRate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredCalcScalarWithRate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredCalcScalarWithRate, [IAgCrdnConfiguredCalcScalarWithRate])

agcls.AgClassCatalog.add_catalog_entry((4657261089292950785, 2896465021905261195), AgCrdnConfiguredCalcScalarWithRate)
agcls.AgTypeNameMap["AgCrdnConfiguredCalcScalarWithRate"] = AgCrdnConfiguredCalcScalarWithRate

class AgCrdnConfiguredCalcParameterSet(IAgCrdnConfiguredCalcParameterSet, SupportsDeleteCallback):
    """Crdn Calc ParameterSet object which computes a set of scalar parameters"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredCalcParameterSet."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredCalcParameterSet.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredCalcParameterSet._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredCalcParameterSet, [IAgCrdnConfiguredCalcParameterSet])

agcls.AgClassCatalog.add_catalog_entry((5485865158666290443, 14094182224507707561), AgCrdnConfiguredCalcParameterSet)
agcls.AgTypeNameMap["AgCrdnConfiguredCalcParameterSet"] = AgCrdnConfiguredCalcParameterSet

class AgCrdnConfiguredCalcParameterSetWithRate(IAgCrdnConfiguredCalcParameterSetWithRate, SupportsDeleteCallback):
    """Crdn Calc ParameterSet object which computes a set of scalar parameters and their rates"""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnConfiguredCalcParameterSetWithRate."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnConfiguredCalcParameterSetWithRate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnConfiguredCalcParameterSetWithRate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnConfiguredCalcParameterSetWithRate, [IAgCrdnConfiguredCalcParameterSetWithRate])

agcls.AgClassCatalog.add_catalog_entry((5050920867911111837, 2663285152729024928), AgCrdnConfiguredCalcParameterSetWithRate)
agcls.AgTypeNameMap["AgCrdnConfiguredCalcParameterSetWithRate"] = AgCrdnConfiguredCalcParameterSetWithRate

class AgCrdnPluginCalcProvider(IAgCrdnPluginCalcProvider, SupportsDeleteCallback):
    """Calc Tool plugin provider."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnPluginCalcProvider."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnPluginCalcProvider.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnPluginCalcProvider._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnPluginCalcProvider, [IAgCrdnPluginCalcProvider])

agcls.AgClassCatalog.add_catalog_entry((5067922828712055389, 4948847799822168504), AgCrdnPluginCalcProvider)
agcls.AgTypeNameMap["AgCrdnPluginCalcProvider"] = AgCrdnPluginCalcProvider

class AgCrdnVectorPluginResultReg(IAgCrdnVectorPluginResultReg, SupportsDeleteCallback):
    """COM Plugin Result interface for the Register method of IAgCrdnVectorPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnVectorPluginResultReg."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnVectorPluginResultReg.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnVectorPluginResultReg._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnVectorPluginResultReg, [IAgCrdnVectorPluginResultReg])

agcls.AgClassCatalog.add_catalog_entry((5650071450446376734, 14786061453105319351), AgCrdnVectorPluginResultReg)
agcls.AgTypeNameMap["AgCrdnVectorPluginResultReg"] = AgCrdnVectorPluginResultReg

class AgCrdnVectorPluginResultReset(IAgCrdnVectorPluginResultReset, SupportsDeleteCallback):
    """COM Plugin Result interface for the Reset method of IAgCrdnVectorPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnVectorPluginResultReset."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnVectorPluginResultReset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnVectorPluginResultReset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnVectorPluginResultReset, [IAgCrdnVectorPluginResultReset])

agcls.AgClassCatalog.add_catalog_entry((4824894824342801043, 7861280001878584253), AgCrdnVectorPluginResultReset)
agcls.AgTypeNameMap["AgCrdnVectorPluginResultReset"] = AgCrdnVectorPluginResultReset

class AgCrdnVectorPluginResultEval(IAgCrdnVectorPluginResultEval, SupportsDeleteCallback):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnVectorPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnVectorPluginResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnVectorPluginResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnVectorPluginResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnVectorPluginResultEval, [IAgCrdnVectorPluginResultEval])

agcls.AgClassCatalog.add_catalog_entry((4789133188736219860, 5123222537265938861), AgCrdnVectorPluginResultEval)
agcls.AgTypeNameMap["AgCrdnVectorPluginResultEval"] = AgCrdnVectorPluginResultEval

class AgCrdnPointPluginResultReg(IAgCrdnPointPluginResultReg, SupportsDeleteCallback):
    """COM Plugin Result interface for the Register method of IAgCrdnPointPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnPointPluginResultReg."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnPointPluginResultReg.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnPointPluginResultReg._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnPointPluginResultReg, [IAgCrdnPointPluginResultReg])

agcls.AgClassCatalog.add_catalog_entry((5087321103643215701, 15995894885496600202), AgCrdnPointPluginResultReg)
agcls.AgTypeNameMap["AgCrdnPointPluginResultReg"] = AgCrdnPointPluginResultReg

class AgCrdnPointPluginResultReset(IAgCrdnPointPluginResultReset, SupportsDeleteCallback):
    """COM Plugin Result interface for the Reset method of IAgCrdnPointPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnPointPluginResultReset."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnPointPluginResultReset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnPointPluginResultReset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnPointPluginResultReset, [IAgCrdnPointPluginResultReset])

agcls.AgClassCatalog.add_catalog_entry((5053960752330888430, 6481343620023801986), AgCrdnPointPluginResultReset)
agcls.AgTypeNameMap["AgCrdnPointPluginResultReset"] = AgCrdnPointPluginResultReset

class AgCrdnPointPluginResultEval(IAgCrdnPointPluginResultEval, SupportsDeleteCallback):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnPointPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnPointPluginResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnPointPluginResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnPointPluginResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnPointPluginResultEval, [IAgCrdnPointPluginResultEval])

agcls.AgClassCatalog.add_catalog_entry((5238685082833516250, 10720769422293944511), AgCrdnPointPluginResultEval)
agcls.AgTypeNameMap["AgCrdnPointPluginResultEval"] = AgCrdnPointPluginResultEval

class AgCrdnAxesPluginResultReg(IAgCrdnAxesPluginResultReg, SupportsDeleteCallback):
    """COM Plugin Result interface for the Register method of IAgCrdnAxesPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnAxesPluginResultReg."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnAxesPluginResultReg.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnAxesPluginResultReg._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnAxesPluginResultReg, [IAgCrdnAxesPluginResultReg])

agcls.AgClassCatalog.add_catalog_entry((5222137985996570128, 8341977476926642361), AgCrdnAxesPluginResultReg)
agcls.AgTypeNameMap["AgCrdnAxesPluginResultReg"] = AgCrdnAxesPluginResultReg

class AgCrdnAxesPluginResultReset(IAgCrdnAxesPluginResultReset, SupportsDeleteCallback):
    """COM Plugin Result interface for the Reset method of IAgCrdnAxesPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnAxesPluginResultReset."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnAxesPluginResultReset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnAxesPluginResultReset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnAxesPluginResultReset, [IAgCrdnAxesPluginResultReset])

agcls.AgClassCatalog.add_catalog_entry((4649768375127071953, 16894216478875912632), AgCrdnAxesPluginResultReset)
agcls.AgTypeNameMap["AgCrdnAxesPluginResultReset"] = AgCrdnAxesPluginResultReset

class AgCrdnAxesPluginResultEval(IAgCrdnAxesPluginResultEval, SupportsDeleteCallback):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnAxesPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnAxesPluginResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnAxesPluginResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnAxesPluginResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnAxesPluginResultEval, [IAgCrdnAxesPluginResultEval])

agcls.AgClassCatalog.add_catalog_entry((5745408051193610534, 10214274020808527798), AgCrdnAxesPluginResultEval)
agcls.AgTypeNameMap["AgCrdnAxesPluginResultEval"] = AgCrdnAxesPluginResultEval

class AgCrdnCalcScalarPluginResultReg(IAgCrdnCalcScalarPluginResultReg, SupportsDeleteCallback):
    """COM Plugin Result interface for the Register method of IAgCrdnCalcScalarPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnCalcScalarPluginResultReg."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnCalcScalarPluginResultReg.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnCalcScalarPluginResultReg._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnCalcScalarPluginResultReg, [IAgCrdnCalcScalarPluginResultReg])

agcls.AgClassCatalog.add_catalog_entry((5515845056528902009, 10430806618654795916), AgCrdnCalcScalarPluginResultReg)
agcls.AgTypeNameMap["AgCrdnCalcScalarPluginResultReg"] = AgCrdnCalcScalarPluginResultReg

class AgCrdnCalcScalarPluginResultReset(IAgCrdnCalcScalarPluginResultReset, SupportsDeleteCallback):
    """COM Plugin Result interface for the Reset method of IAgCrdnCalcScalarPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnCalcScalarPluginResultReset."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnCalcScalarPluginResultReset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnCalcScalarPluginResultReset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnCalcScalarPluginResultReset, [IAgCrdnCalcScalarPluginResultReset])

agcls.AgClassCatalog.add_catalog_entry((5286103234837555369, 16525601056066191765), AgCrdnCalcScalarPluginResultReset)
agcls.AgTypeNameMap["AgCrdnCalcScalarPluginResultReset"] = AgCrdnCalcScalarPluginResultReset

class AgCrdnCalcScalarPluginResultEval(IAgCrdnCalcScalarPluginResultEval, SupportsDeleteCallback):
    """COM Plugin Result interface for the Evaluate method of IAgCrdnCalcScalarPlugin."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgCrdnCalcScalarPluginResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgCrdnCalcScalarPluginResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCrdnCalcScalarPluginResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCrdnCalcScalarPluginResultEval, [IAgCrdnCalcScalarPluginResultEval])

agcls.AgClassCatalog.add_catalog_entry((5535623028472172125, 11586805675348350339), AgCrdnCalcScalarPluginResultEval)
agcls.AgTypeNameMap["AgCrdnCalcScalarPluginResultEval"] = AgCrdnCalcScalarPluginResultEval


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
