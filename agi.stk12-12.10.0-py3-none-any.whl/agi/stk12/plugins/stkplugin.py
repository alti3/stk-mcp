################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgGatorPluginSite", "AgStkPluginSite", "IAgGatorPluginSite", "IAgStkPluginSite"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.attrautomation import *
from ..plugins.utplugin import *
from ..plugins.crdnplugin import *
from ..plugins.gatorplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class IAgStkPluginSite(IAgUtPluginSite):
    """STK application plugin site"""

    _num_methods = 6
    _vtable_offset = IAgUtPluginSite._vtable_offset + IAgUtPluginSite._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_ScenarioDirectory_method_offset = 2
    _get_InstallDirectory_method_offset = 3
    _get_ConfigDirectory_method_offset = 4
    _get_StkRootObject_method_offset = 5
    _get_CalcToolProvider_method_offset = 6
    _metadata = {
        "iid_data" : (5732841613962665616, 13620704852926484107),
        "vtable_reference" : IAgUtPluginSite._vtable_offset + IAgUtPluginSite._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkPluginSite."""
        initialize_from_source_object(self, sourceObject, IAgStkPluginSite)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUtPluginSite._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkPluginSite)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkPluginSite, IAgUtPluginSite)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgStkPluginSite._metadata, IAgStkPluginSite._get_VectorToolProvider_metadata)

    _get_ScenarioDirectory_metadata = { "offset" : _get_ScenarioDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ScenarioDirectory(self) -> str:
        """The directory path of the current scenario."""
        return self._intf.get_property(IAgStkPluginSite._metadata, IAgStkPluginSite._get_ScenarioDirectory_metadata)

    _get_InstallDirectory_metadata = { "offset" : _get_InstallDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InstallDirectory(self) -> str:
        """The directory path of the installation of the application."""
        return self._intf.get_property(IAgStkPluginSite._metadata, IAgStkPluginSite._get_InstallDirectory_metadata)

    _get_ConfigDirectory_metadata = { "offset" : _get_ConfigDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ConfigDirectory(self) -> str:
        """The directory path of the user configuration area."""
        return self._intf.get_property(IAgStkPluginSite._metadata, IAgStkPluginSite._get_ConfigDirectory_metadata)

    _get_StkRootObject_metadata = { "offset" : _get_StkRootObject_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def StkRootObject(self) -> typing.Any:
        """Returns an instance of the STK Object Model Root Object"""
        return self._intf.get_property(IAgStkPluginSite._metadata, IAgStkPluginSite._get_StkRootObject_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgStkPluginSite._metadata, IAgStkPluginSite._get_CalcToolProvider_metadata)

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[ScenarioDirectory] = "ScenarioDirectory"
    _property_names[InstallDirectory] = "InstallDirectory"
    _property_names[ConfigDirectory] = "ConfigDirectory"
    _property_names[StkRootObject] = "StkRootObject"
    _property_names[CalcToolProvider] = "CalcToolProvider"


agcls.AgClassCatalog.add_catalog_entry((5732841613962665616, 13620704852926484107), IAgStkPluginSite)
agcls.AgTypeNameMap["IAgStkPluginSite"] = IAgStkPluginSite

class IAgGatorPluginSite(IAgUtPluginSite):
    """Astrogator plugin site interface."""

    _num_methods = 8
    _vtable_offset = IAgUtPluginSite._vtable_offset + IAgUtPluginSite._num_methods
    _get_VectorToolProvider_method_offset = 1
    _get_GatorProvider_method_offset = 2
    _get_ScenarioDirectory_method_offset = 3
    _get_InstallDirectory_method_offset = 4
    _get_ConfigDirectory_method_offset = 5
    _get_StkRootObject_method_offset = 6
    _GetDisplayUnit_method_offset = 7
    _get_CalcToolProvider_method_offset = 8
    _metadata = {
        "iid_data" : (5555506316035568656, 13663752667195587502),
        "vtable_reference" : IAgUtPluginSite._vtable_offset + IAgUtPluginSite._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGatorPluginSite."""
        initialize_from_source_object(self, sourceObject, IAgGatorPluginSite)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUtPluginSite._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGatorPluginSite)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGatorPluginSite, IAgUtPluginSite)
    
    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgGatorPluginSite._metadata, IAgGatorPluginSite._get_VectorToolProvider_metadata)

    _get_GatorProvider_metadata = { "offset" : _get_GatorProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def GatorProvider(self) -> "IAgGatorPluginProvider":
        """Creates an IAgGatorPluginProvider object."""
        return self._intf.get_property(IAgGatorPluginSite._metadata, IAgGatorPluginSite._get_GatorProvider_metadata)

    _get_ScenarioDirectory_metadata = { "offset" : _get_ScenarioDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ScenarioDirectory(self) -> str:
        """The directory path of the current scenario."""
        return self._intf.get_property(IAgGatorPluginSite._metadata, IAgGatorPluginSite._get_ScenarioDirectory_metadata)

    _get_InstallDirectory_metadata = { "offset" : _get_InstallDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InstallDirectory(self) -> str:
        """The directory path of the installation of the application."""
        return self._intf.get_property(IAgGatorPluginSite._metadata, IAgGatorPluginSite._get_InstallDirectory_metadata)

    _get_ConfigDirectory_metadata = { "offset" : _get_ConfigDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ConfigDirectory(self) -> str:
        """The directory path of the user configuration area."""
        return self._intf.get_property(IAgGatorPluginSite._metadata, IAgGatorPluginSite._get_ConfigDirectory_metadata)

    _get_StkRootObject_metadata = { "offset" : _get_StkRootObject_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def StkRootObject(self) -> typing.Any:
        """Returns an instance of the STK Object Model Root Object"""
        return self._intf.get_property(IAgGatorPluginSite._metadata, IAgGatorPluginSite._get_StkRootObject_metadata)

    _GetDisplayUnit_metadata = { "offset" : _GetDisplayUnit_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def GetDisplayUnit(self, dimension:str) -> str:
        """Gets the display unit (scenario unit) for the given dimension."""
        return self._intf.invoke(IAgGatorPluginSite._metadata, IAgGatorPluginSite._GetDisplayUnit_metadata, dimension, OutArg())

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginCalcProvider object."""
        return self._intf.get_property(IAgGatorPluginSite._metadata, IAgGatorPluginSite._get_CalcToolProvider_metadata)

    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[GatorProvider] = "GatorProvider"
    _property_names[ScenarioDirectory] = "ScenarioDirectory"
    _property_names[InstallDirectory] = "InstallDirectory"
    _property_names[ConfigDirectory] = "ConfigDirectory"
    _property_names[StkRootObject] = "StkRootObject"
    _property_names[CalcToolProvider] = "CalcToolProvider"


agcls.AgClassCatalog.add_catalog_entry((5555506316035568656, 13663752667195587502), IAgGatorPluginSite)
agcls.AgTypeNameMap["IAgGatorPluginSite"] = IAgGatorPluginSite



class AgStkPluginSite(IAgStkPluginSite, SupportsDeleteCallback):
    """STK plugin site."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkPluginSite."""
        SupportsDeleteCallback.__init__(self)
        IAgStkPluginSite.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkPluginSite._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkPluginSite, [IAgStkPluginSite])

agcls.AgClassCatalog.add_catalog_entry((4664440071662183906, 4863533699890488995), AgStkPluginSite)
agcls.AgTypeNameMap["AgStkPluginSite"] = AgStkPluginSite

class AgGatorPluginSite(IAgStkPluginSite, IAgGatorPluginSite, SupportsDeleteCallback):
    """Astrogator plugin site."""
    def __init__(self, sourceObject=None):
        """Construct an object of type AgGatorPluginSite."""
        SupportsDeleteCallback.__init__(self)
        IAgStkPluginSite.__init__(self, sourceObject)
        IAgGatorPluginSite.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkPluginSite._private_init(self, intf)
        IAgGatorPluginSite._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGatorPluginSite, [IAgStkPluginSite, IAgGatorPluginSite])

agcls.AgClassCatalog.add_catalog_entry((5126245587670349959, 15800364906555377327), AgGatorPluginSite)
agcls.AgTypeNameMap["AgGatorPluginSite"] = AgGatorPluginSite


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
